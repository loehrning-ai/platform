# Prognose prüfen: Kit zu Workshop 1

Du prüfst eine Wochenprognose an ihren eigenen alten Fehlern, bevor danach geplant
wird. Eine Spalte, Ist minus Prognose, beantwortet vier Fragen:

1. Messlatte: Sind die Fehler kleiner als die von „wie letzte Woche“?
2. Spanne: Lag das Ist so oft in der 80-%-Spanne, wie sie verspricht?
3. Planzahl: Welche Menge folgt aus den Kosten für ein fehlendes und ein übriges Stück?
4. Regel: Welche Woche läuft die Prognose allein, welche entscheidet eine Person?

Die Firma ist erfunden: Suppenwerk Feldmark kocht montags Linsensuppe (500 ml, frisch)
für Bio-Läden. Die Zahlen sind erfunden. Die Fehler in der Datei sind die, die echte
Exporte haben: eine Zeile doppelt, eine Woche ohne gespeicherte Prognose, zwei Wochen
ausverkauft.

## Reihenfolge (55 Minuten)

1. Die Demo einmal durchspielen: loehrning.ai/demos/ki-prognosen-einschaetzen (5 Minuten).
2. daten/ ansehen (5 Minuten).
3. uebung.md, Aufgaben 1 bis 4 (30 Minuten).
4. Mit loesungen.md vergleichen (5 Minuten).
5. Deine eigene Reihe in vorlage/meine-daten.csv, pruefregel.md ausfüllen (10 Minuten).

## Drei Wege, dieselben Zahlen

- Browser: loehrning.ai/demos/ki-prognosen-einschaetzen. Im Schritt „Meine Daten“ mit
  deiner Datei. Nichts verlässt das Gerät.
- Claude: loehrning.ai/skills/prognose-pruefen.zip als Skill hochladen (Schritte unten;
  derselbe Skill liegt entpackt in claude/prognose-pruefen/). Dann die
  CSV in den Chat legen und schreiben: „Prüf diese Prognose. Fehlendes Glas 1,50 €,
  übriges Glas 0,40 €.“ Ohne Skill: claude/projekt-anweisung.md in die Anweisungen
  eines Projekts.
- Ohne Claude, mit Python 3 und ohne weitere Pakete:
  `python3 pruefen.py daten/linsensuppe-woechentlich.csv --fehlmenge 1,50 --rest 0,40`

Alle drei Wege rechnen mit demselben Code und kommen auf dieselben Zahlen wie
loesungen.md.

## Die Spalten

    woche;ist;prognose;hinweis

- woche: Montag der Woche, 2025-04-07 oder 07.04.2025.
- ist: verkaufte Menge. Leer in der Woche, die du planst.
- prognose: die Zahl, die damals im System stand. Nie nachträglich neu rechnen.
- hinweis: frei. Steht dort „ausverkauft“, zählt die Woche nicht. Eine Spalte
  bestand_ende mit 0 wirkt genauso.

## Was das Kit nicht kann

- Es baut keine Prognose. Es prüft eine, die es schon gibt.
- Ohne gespeicherte alte Prognosen gibt es keine Prüfung 1. Ab heute ablegen.
- Ein neues Produkt hat keine Fehlerliste. Dort entscheidet eine Person.
- Die Planzahl gilt für Ware, die nach der Woche an Wert verliert.

## So kommt der Skill in deinen Claude

### claude.ai und Desktop-App

1. Unter „Settings“, „Capabilities“ den Schalter „Code execution and file creation“ einschalten (im neuen Layout „Create and edit files“).
2. claude.ai/customize/skills öffnen.
3. „+“, dann „Create skill“, dann „Upload a skill“ und die ZIP-Datei wählen.
4. Den Skill einschalten.

Auf Team und Enterprise kann dein Admin eigene Skills abschalten.

### Claude Code

Für alle Projekte: `unzip prognose-pruefen.zip -d ~/.claude/skills/`

Nur für dieses Repository: `unzip prognose-pruefen.zip -d .claude/skills/`

Danach liegt SKILL.md in skills/prognose-pruefen/, global oder im Repository. Tippe /prognose-pruefen oder frag einfach.

Mit demselben claude.ai-Login lädt Claude Code (ab v2.1.273) deine in claude.ai eingeschalteten Skills selbst; dort nicht ein zweites Mal entpacken. Mit API-Key oder Bedrock: per unzip.

### Projektanweisungen

1. claude.ai/projects öffnen, „New Project“ wählen.
2. Rechts „Set project instructions“ öffnen, den Text einfügen, „Save instructions“.
3. Die Kit-Dateien über „+“ ins Projektwissen laden.

Projekte gibt es auf jedem Plan, auf Free bis zu fünf.
