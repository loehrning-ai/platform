Erfundenes Übungsmaterial, für die Übung erfunden. Keine Rechtsberatung.

# Monatlicher Check des Registers

Einmal im Monat, an einem festen Tag, macht das eine benannte Person. Das Register ist eine Arbeitsdatei und ersetzt nie ein Papier.

Nimm das Skript check.py aus Schritt 4 und diesen Prompt:

    Führe check.py auf register.csv mit dem heutigen Datum aus. Gib drei Listen aus: abgelaufen, läuft in den nächsten 60 Tagen ab, fehlt. Entwirf dann eine kurze Nachricht pro zuständiger Rolle. Nur ein Entwurf.

Eine benannte Person liest die Listen, verschickt die Nachrichten und schreibt für jede Lücke ein neues datiertes Papier. Ändere nie eine alte Zeile, um eine Lücke zu verstecken.

Damit das nach dem Workshop weiterläuft, siehe bereit-bleiben/: eine wöchentliche geplante Aufgabe in bezahlten Plänen, derselbe Check von Hand im Gratis-Plan.

## Weitere Orte für dasselbe Register

Dasselbe Register funktioniert in einer Tabelle (eine Formel wie „Datum vor heute“ markiert abgelaufene Zeilen), in einer Microsoft-Liste oder in einer kleinen Datenbank wie SQLite. Die Spalten und die drei Listen bleiben gleich. Nur Daten, keine Gesundheitsinhalte.
