Erfundenes Übungsmaterial, für die Übung erfunden. Keine Rechtsberatung.

# Änderungen

## 2026-11-09

An das Deck angeglichen: Die Startdatei nennt jeden Schritt wie das Deck, die Minuten im Raum für Schritt 3 und 4 sind die 8 und 11 des Decks, die Codeausführung gibt es in jedem Tarif (die Startdatei fragt nur, ob sie ausgeschaltet ist), und im Free-Tarif müssen die Projektdateien ins Kontextfenster passen. Die Anweisungen des Registerprojekts schreiben NICHT IN DATEIEN wie die übrigen Dateien, und die Beobachtungsliste nennt das Amtsblatt auch mit seinem kyrillischen Namen. 41 Dateien.

## 2026-11-08

Neu: Schritt 4, das Register bauen: eine Registervorlage, ein Monatscheck, eine Zeile in den Projektanweisungen, der Abschnitt über den Rhythmus auf Feldkarte A und die letzte Inspektion im Ordner-Index. Schritt 2 verlangt eine Summenzeile, Schritt 3 nennt die Regel für den Status und lässt das Datum der Papiere offen, Schritt 4 nennt die Firmenzeile FIRM, und Feldkarte A sagt „auf dem Papier“ dazu, wie oft eine Inspektion kommt. Neu ist bereit-bleiben/, um nach dem Besuch bereit zu bleiben: ein Wochenprompt für eine geplante Aufgabe, derselbe Prompt monatlich von Hand, Anweisungen für ein Registerprojekt, eine Beobachtungsliste amtlicher Quellen und eine Sicherheitskarte auf einer Seite. 41 Dateien. Die Firma und alles darin ist erfunden.

## 2026-11-07

Neu aufgebaut für Workshop 5: neuer Fall (Gradba-Pro, Arbeitsinspektion), 34 Dateien, 13 Fragen der Prüfliste, neuer Lösungsschlüssel aus den Dateien gerechnet, altes Kit abgelöst. Die Firma und alles darin ist erfunden.
