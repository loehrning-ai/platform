# Entwurf: Werbeaussagen für den Herbststart
Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden.

Von: Marketing. Für Etiketten und Regalkarten in Deutschland und für unsere Website.

| Nr | Aussage | Wo |
|---|---|---|
| 1 | „Klimaneutraler Wein“ | Rückenetikett, alle Weine |
| 2 | „Umweltfreundliches Weingut“ | Website, Startseite |
| 3 | „Zertifizierte Bio-Weinberge“ | Regalkarte, alle Weine |
| 4 | „Solarbetriebenes Weingut“ | Website, Über uns |
| 5 | „2025 haben wir 12 % weniger Strom verbraucht“ | Website, Neuigkeiten |
| 6 | „Diese Flasche wiegt nur 395 g und besteht zu 60 % aus Recyclingglas“ | Rückenetikett, nur Vranec Tikveš 2024 |
| 7 | „2025 hat das ganze Weingut 4.630 m³ Wasser entnommen, gemessen auf 12 Monatsrechnungen“ | Website, Seite Nachhaltigkeit |
