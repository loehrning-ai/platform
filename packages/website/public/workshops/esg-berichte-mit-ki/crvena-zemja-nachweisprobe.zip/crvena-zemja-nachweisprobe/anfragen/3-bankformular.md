# Banka Povardarie AD Skopje
Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden.

## Formular zur Umwelt- und Sozialprüfung und zur grünen Förderfähigkeit

Kunde: Vinarija Crvena Zemja DOO. Kredit: 8.550.000 MKD für eine PV-Anlage mit 150 kWp auf dem Dach,
aus einer grünen Kreditlinie, wie sie die EBRD über Banken in Nordmazedonien finanziert (Bank und Formular erfunden).

Bitte füllen Sie jedes Feld aus. Kennzeichnen Sie jede Schätzung.

F1. Bußgelder wegen Umwelt, Arbeitsrecht und Arbeitsschutz, 2023 bis 2025
F2. Stromverbrauch 2025, ganzes Jahr, in MWh
F3. Erwarteter PV-Ertrag pro Jahr und sein Anteil am Verbrauch
F4. Einfache Amortisation in Jahren =
    Investition / (erwarteter Jahresertrag in kWh × aktueller Preis in MKD/kWh)
    Einfache Formel der Bank, keine Investitionsrechnung.
F5. Beschäftigte im Jahresdurchschnitt und Arbeitsunfälle 2025
F6. Gültige Zertifikate und Audits (Bewertung, Datum des nächsten Audits)

Hinweis zur Übung: 9,50 MKD/kWh auf den Rechnungen des Kunden ist ein erfundener Einheitstarif.
