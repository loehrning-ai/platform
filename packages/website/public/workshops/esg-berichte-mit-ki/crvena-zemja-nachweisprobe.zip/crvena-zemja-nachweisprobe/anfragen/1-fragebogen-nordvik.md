# Nachhaltigkeitsfragebogen für Lieferanten 2026
Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden.

Von: Nordvik Vin AB, Göteborg, Schweden (Weinimporteur). An: Vinarija Crvena Zemja DOO.
Wir beliefern Systembolaget und bereiten eine Ausschreibung von Vinmonopolet vor (Norwegen, EWR, nicht EU).
Nach dem Basismodul des freiwilligen EU-Nachhaltigkeitsstandards für KMU (VSME).
Berichtsjahr 2025. Rückgabe: 23.10.2026.

Bewertungsregeln:
- Antworten ohne Nachweis werden nicht gewertet.
- Zertifikate müssen am Tag der Abgabe gültig sein.
- Energiedaten müssen das ganze Berichtsjahr abdecken (95 % Abdeckung).

| Nr | VSME | Frage |
|---|---|---|
| Q1 | B3 | Stromverbrauch 2025 in MWh und Anteil erneuerbar (%) |
| Q2 | B3 | Scope 1 und standortbasierter Scope 2 2025 in tCO2e |
| Q3 | B8 | Beschäftigte im Jahresdurchschnitt 2025 nach Vertragsart und Geschlecht |
| Q4 | B9 | Meldepflichtige Arbeitsunfälle und Todesfälle 2025 |
| Q5 | B11 | Verurteilungen oder Bußgelder wegen Korruption oder Bestechung 2025 |
| Q6 | (keine) | Glasgewicht jedes 0,75-l-Stillweins, den Sie unter 250 NOK verkaufen wollen. Regel von Vinmonopolet seit 1.1.2026: Stillwein unter 250 NOK muss in Flaschen von höchstens 420 g je 0,75 l stehen (Schaumwein ausgenommen). Produkte, die das nicht erfüllen, werden ausgelistet. |
| Q7 | (keine) | Gültige Zertifikate und Audits, mit Ablaufdatum oder Datum des nächsten Audits |
| Q8 | B6 | Wasserentnahme 2025 in m³ |
