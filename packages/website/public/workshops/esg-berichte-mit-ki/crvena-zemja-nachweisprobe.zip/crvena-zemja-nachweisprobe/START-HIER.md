# Nachweisprobe: ESG-Antworten aus einem Ordner

Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden. Echt sind nur die
zitierten Gesetze, Standards und Regeln.

**Lernziel:** Jede Antwort, die die Firma verlässt, trägt ihren Nachweis: eine freigegebene Datei mit Zeile,
die Zeitraum und Umfang der Antwort deckt, oder den Namen des Dokuments, das fehlt.

## Der Fall
Vinarija Crvena Zemja DOO, ein Familienweingut in Kavadarci, Nordmazedonien: 42 Beschäftigte,
40 ha Weinberge, rund 550.000 Flaschen im Jahr, 74 % Export, davon 31 % nach Deutschland.
Stichtag der Übung: 16.10.2026. Lass ihn so stehen, auch wenn du später arbeitest; die Lösungen
hängen daran.

| Anfrage | Von | Was gefragt ist |
|---|---|---|
| `anfragen/1-fragebogen-nordvik.md` | Nordvik Vin AB, Weinimporteur in Schweden | 8 Fragen nach dem VSME-Basismodul. Antworten ohne Nachweis werden nicht gewertet; Energiedaten müssen 95 % des Jahres abdecken |
| `anfragen/2-werbeaussagen.md` | das eigene Marketing | 7 Umweltaussagen für Etiketten und Regalkarten in Deutschland und für die Website |
| `anfragen/3-bankformular.md` | Banka Povardarie | 6 Felder für einen Kredit über eine PV-Anlage |

## Was im Kit liegt
| Datei oder Ordner | Inhalt |
|---|---|
| `nachweisprobe.md` | die Probe auf einer Seite. Zuerst lesen, ausgedruckt neben den Bildschirm legen |
| `projektanweisungen.md` | Stichtag und drei Regeln für Claude |
| `ordner/` | 13 Dateien des Weinguts, so unordentlich wie eine echte Ablage |
| `anfragen/` | die drei Anfragen |
| `nachreichung/` | eine Rechnung für Schritt 5. Vorher nicht öffnen |
| `loesungen/LOESUNGEN.md` | Lösungen mit Datei und Zeile. Erst nach dem jeweiligen Schritt öffnen |
| `mitnehmen/` | Skill, Vorlagen und Checkliste für deine eigene Firma |

Dieselben Dateien als interaktive Demo: loehrning.ai/demos/esg-berichte-mit-ki

## Was du brauchst
- Claude auf claude.ai oder in der Desktop-App, mit eingeschalteter Codeausführung (Abschnitt
  „Claude einrichten“ unten).
- Einen Texteditor mit Zeilennummern. Öffne die .csv-Dateien nicht in Excel; Excel ändert Datumswerte
  und Dezimalzeichen. Die .csv-Dateien sind Buchhaltungsexporte: Punkt als Dezimalzeichen, Monate als 2025-01.
- Papier und Stift für die Vorhersagen.
- Etwa 90 Minuten beim ersten Durchgang. Im Workshop: Schritte 0 bis 3 live, 4 und 5 als Demo. Nach jedem Schritt kannst du aufhören; die Chats bleiben im Projekt.
- Kein Code, kein ESG-Vorwissen.

## Schritt 0: Durchsicht ohne Claude (10 Minuten)
Lies `nachweisprobe.md`, dann die 13 Dateien in `ordner/` und die drei Anfragen.
In den Dateien stecken 8 Mängel. Eine Datei sieht auffällig aus und ist in Ordnung.
Schreib zu jedem Mangel: Datei, Zeile, was nicht stimmt, und welche Prüfung scheitert
(Zeitraum, Umfang, Freigabe oder Verbotsliste). Schreib die saubere Datei dazu.
Vergleiche mit `loesungen/LOESUNGEN.md`, Abschnitt „Durchsicht“.

## Projekt anlegen (einmal, 10 Minuten)
1. Kit entpacken.
2. Ein neues Projekt „Crvena Zemja Nachweise“ anlegen (Schritte unter „Claude einrichten“, Projektanweisungen).
3. Den ganzen Text aus `projektanweisungen.md` als Projektanweisungen einfügen und speichern.
4. Die 13 Dateien aus `ordner/` ins Projekt laden. Die Anfragen nicht: Sie fragen, sie belegen
   nichts. Du hängst sie in jedem Schritt an die Nachricht.
5. Lässt sich eine .md-Datei nicht hochladen, benenne sie in .txt um.
6. Ohne Projekte: in jedem neuen Chat die 13 Dateien und die Anfrage anhängen und den Text aus
   `projektanweisungen.md` vor den Prompt setzen.
Schritte 1 bis 4 beginnen jeweils einen neuen Chat im Projekt. Schritt 5 läuft im Chat von Schritt 4.
Vor echten Firmendaten: in den Einstellungen den Datenschutz prüfen und klären, ob Firmendateien in Claude dürfen.

## Schritt 1: Fragebogen des Importeurs
Vorhersage auf Papier: Wie viele der 8 Fragen werden BELEGT?
Neuer Chat, `anfragen/1-fragebogen-nordvik.md` anhängen:
```
Beantworte den angehängten Fragebogen von Nordvik Vin AB.
Eine Tabelle, genau eine Zeile je Frage Q1 bis Q8: Nr | Frage | Antwort | Datei und Zeile | Status | Grund | Fehlendes Dokument.
Zähle vor jeder Jahressumme die eindeutigen Monate im Code.
```
Öffne den Code-Kasten: Wie viele Zeilen hat die Stromdatei, und wie viele Monate?
Prüfen: `LOESUNGEN.md`, Schritt 1.

## Schritt 2: Werbeaussagen
Vorhersage: Welche der 7 Aussagen dürfen raus?
Neuer Chat, `anfragen/2-werbeaussagen.md` anhängen:
```
Prüfe die sieben Aussagen in der angehängten Datei: zuerst gegen die Verbotsliste in regeln_werbeaussagen.md, dann mit der Nachweisprobe.
Eine Tabelle: Nr | Aussage | Verbotsliste (Nummer oder keine) | Status | Grund mit Datei und Zeile | Darf raus (ja/nein) | Sichere Fassung.
```
Prüfen: `LOESUNGEN.md`, Schritt 2.

## Schritt 3: Formular der Bank
Vorhersage: Rechne F4 mit dem Taschenrechner. Die Formel steht im Formular, die Zahlen stehen im Ordner.
Neuer Chat, `anfragen/3-bankformular.md` anhängen:
```
Fülle das angehängte Formular aus.
Eine Tabelle: Feld | Antwort | Datei und Zeile | Status | Grund | Fehlendes Dokument.
Rechne F4 im Code mit der Formel aus dem Formular. Kennzeichne jede Schätzung.
```
Welche Lücke aus Schritt 1 kommt zurück? Prüfen: `LOESUNGEN.md`, Schritt 3.

## Schritt 4: Nachweisregister
Die drei Anfragen fragen oft nach denselben Fakten. Das Register hält sie an einer Stelle.
Vorhersage: Wie viele der 21 Antworten sind BELEGT?
Neuer Chat, alle drei Anfragen anhängen:
```
Die drei angehängten Dateien sind unsere offenen Anfragen. Erstelle nachweisregister.xlsx mit drei Blättern:
1. Register: eine Zeile je Frage, Aussage und Feld. Spalten: Anfrage | Nr | Antwort | Datei und Zeile | Status | Grund | Fehlendes Dokument | Maßnahme | Geprüft von | Datum. Die letzten zwei bleiben leer.
2. VSME: B1 bis B11 aus vsme_basismodul.md, je Angabe die Datenpunkte mit Status, belegt x von y, Status der Angabe nach dem schwächsten Datenpunkt.
3. Anfordern: jedes fehlende Dokument einmal, mit allen Zeilen, die es nennen, sortiert nach Anzahl.
```
Prüfen: `LOESUNGEN.md`, Schritt 4.

## Schritt 5: Die nachgereichte Rechnung
Die Buchhaltung findet die Stromrechnung September 2025, als Foto. Der Stichtag bleibt.
Vorhersage: Wie viele Status im Register ändern sich?
Im Chat von Schritt 4 bleiben, `nachreichung/rechnung-EL-25-09.png` anhängen:
```
Angehängt ist die Stromrechnung September 2025. Lies sie zuerst und prüfe die kWh mit den beiden Zählerständen.
Prüfe dann jede Zeile im Register neu, die strom_2025.csv zitiert. Eine Tabelle: Wo | Vorher (Wert, Status) | Jetzt (Wert, Status) | Warum. Auch für Zeilen, die gleich bleiben.
Sag, was die Rechnung für strom_zusammenfassung_entwurf.txt bedeutet und wie weit 11 Monate × 12/11 vom ganzen Jahr entfernt liegen.
Aktualisiere nachweisregister.xlsx.
```
Prüfen: `LOESUNGEN.md`, Schritt 5.

## Für deine Firma
Der Skill liegt in `claude/`, alles andere in `mitnehmen/`:
- `claude/esg-nachweise/SKILL.md`: der Skill für dein Claude, ein Skill für Deutsch und Englisch.
  Als ZIP zum Hochladen: loehrning.ai/skills/esg-nachweise.zip. Installation unten.
  Die Projektanweisungen funktionieren auch ohne Skill.
- `projektanweisungen-vorlage.md`: für dein eigenes Projekt. Klammern füllen, Stichtag bei jeder Arbeitssitzung ändern.
- `ordner-checkliste.md`: welche Dokumente in deinen Ordner gehören und was du an jedem prüfst.
- `nachweisregister-vorlage.csv`: mit Semikolon für deutsches Excel. In Excel über „Daten“, „Aus Text/CSV“ öffnen, Dateiursprung UTF-8.
- `mail-fehlendes-dokument.md`: eine Mail für jede LÜCKE.
Mische nie echte Dateien mit diesen Übungsdateien. Ein Mensch prüft und unterschreibt jede Antwort.

## Claude einrichten

### claude.ai und Desktop-App

1. Unter „Settings“, „Capabilities“ den Schalter „Code execution and file creation“ einschalten (im neuen Layout „Create and edit files“).
2. claude.ai/customize/skills öffnen.
3. „+“, dann „Create skill“, dann „Upload a skill“ und die ZIP-Datei wählen.
4. Den Skill einschalten.

Auf Team und Enterprise kann dein Admin eigene Skills abschalten.

### Claude Code

Für alle Projekte: `unzip esg-nachweise.zip -d ~/.claude/skills/`

Nur für dieses Repository: `unzip esg-nachweise.zip -d .claude/skills/`

Danach liegt SKILL.md in skills/esg-nachweise/ (global oder im Repository). Tipp /esg-nachweise oder frag einfach.

Mit demselben claude.ai-Login lädt Claude Code (ab v2.1.273) deine in claude.ai eingeschalteten Skills selbst; dort nicht ein zweites Mal entpacken. Mit API-Key oder Bedrock: per unzip.

### Projektanweisungen

1. claude.ai/projects öffnen, „New Project“ wählen.
2. Rechts „Set project instructions“ öffnen, den Text einfügen, „Save instructions“.
3. Die Kit-Dateien über „+“ ins Projektwissen laden.

Projekte gibt es auf jedem Plan, auf Free bis zu fünf.
