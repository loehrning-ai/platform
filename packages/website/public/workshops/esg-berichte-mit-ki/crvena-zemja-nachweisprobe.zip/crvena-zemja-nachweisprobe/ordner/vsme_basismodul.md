# VSME-Basismodul: die 11 Angaben
Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden. Ausnahme: Diese Datei fasst einen echten EU-Standard zusammen.

Freiwilliger Nachhaltigkeitsstandard der EU für KMU (VSME). Seit dem 24.09.2026 legt ihn die Delegierte
Verordnung (EU) 2026/1560 der Kommission fest; sie ersetzt die Empfehlung (EU) 2025/1710. Freiwillig,
keine Prüfung durch Dritte nötig. Lernhilfe, nicht der amtliche Text.

| Nr | Angabe | Fragt, kurz gesagt |
|---|---|---|
| B1 | Grundlagen der Erstellung | gewähltes Modul, Einzel- oder Konzernbericht, Rechtsform, NACE, Bilanzsumme, Umsatz, Beschäftigte, Land, Lage und Geodaten der Standorte; Nachhaltigkeitszertifikate oder Siegel (Aussteller, Datum, Bewertung) |
| B2 | Praktiken, Richtlinien und künftige Initiativen für den Übergang zu einer nachhaltigeren Wirtschaft | Praktiken, Richtlinien (und ob sie veröffentlicht sind), künftige Initiativen, Ziele. „Nein“ ist eine gültige Antwort |
| B3 | Energie und Treibhausgasemissionen | Gesamtenergie in MWh, Strom und Brennstoffe (erneuerbar und nicht erneuerbar, wo verfügbar); Scope 1 und standortbasierter Scope 2 in tCO2e (Scope 2 = kWh × veröffentlichter Netz-Emissionsfaktor) |
| B4 | Verschmutzung von Luft, Wasser und Boden | nur wenn ein Gesetz (oder ein Umweltmanagementsystem) uns schon zur Meldung von Schadstoffemissionen verpflichtet: diese Emissionen. Sonst gilt B4 nicht; die Umweltgenehmigung zeigt, was gilt |
| B5 | Biodiversität | unsere Standorte in oder nahe (überlappend oder angrenzend) einem für die Biodiversität sensiblen Gebiet, mit dem Namen des Gebiets |
| B6 | Wasser | gesamte Wasserentnahme (Wasserverbrauch nur, wenn ein Prozess viel Wasser verbraucht) |
| B7 | Ressourcennutzung, Kreislaufwirtschaft und Abfall | Kreislaufpraktiken; Abfall gesamt, gefährlich und nicht gefährlich; Anteil zum Recycling oder zur Wiederverwendung; Masse wichtiger Materialien, wenn erheblich |
| B8 | Belegschaft, allgemeine Merkmale | Beschäftigte (Köpfe oder Vollzeitäquivalente) nach Vertragsart und Geschlecht; nach Land, wenn mehr als eines |
| B9 | Belegschaft, Gesundheit und Sicherheit | nur Beschäftigte: meldepflichtige Arbeitsunfälle (Tod oder mehr als 3 Tage Ausfall), Quote (Unfälle / geleistete Stunden × 200.000), Todesfälle |
| B10 | Belegschaft, Vergütung, Tarifverhandlungen und Schulung | Lohn auf oder über dem Mindestlohn (ja/nein), Anteil der Beschäftigten mit Tarifvertrag, durchschnittliche Schulungsstunden je Beschäftigtem; Lohnlücke zwischen Männern und Frauen nur, wenn ein Gesetz sie schon verlangt |
| B11 | Verurteilungen und Bußgelder wegen Korruption und Bestechung | Zahl der Verurteilungen und Summe der Bußgelder wegen Korruption und Bestechung |

Was sich 2026 gegenüber der Empfehlung von 2025 geändert hat:
- B3 fragt nicht mehr nach der Treibhausgasintensität.
- Die Fluktuationsquote ist von B8 ins umfassende Modul (C5) gewandert.
- B5 fragt nur noch, welche Standorte in oder nahe einem sensiblen Gebiet liegen, mit dem Namen des
  Gebiets. Flächenzahlen zur Landnutzung fragt B5 nicht mehr.
- B10 fragt nach der Lohnlücke nur, wenn ein Gesetz sie schon verlangt. Schulungsstunden werden nicht
  mehr nach Geschlecht getrennt.
- Regel „falls zutreffend“: Lässt du eine Angabe weg, lesen andere das als „gilt für uns nicht“. Lass
  eine echte Lücke also nie leer: Schreib, was fehlt.
Die kostenlose Excel-Vorlage der EFRAG, Version 1.3.0 (Juni 2026), folgt noch der Empfehlung von 2025.
Eine Fassung für die Verordnung (EU) 2026/1560 ist für das vierte Quartal 2026 angekündigt:
https://www.efrag.org/en/vsme-digital-template-and-xbrl-taxonomy

Begrenzung in der Wertschöpfungskette: Für Geschäftsjahre ab dem 1.1.2027 dürfen berichtspflichtige
Kunden von Firmen mit bis zu 1.000 Beschäftigten für ihren Nachhaltigkeitsbericht nur die Datenpunkte
aus Anhang II der Delegierten Verordnung (EU) 2026/1560 verlangen (Richtlinie (EU) 2026/470).
Anfragen nach anderen EU- oder nationalen Vorschriften (etwa Bankaufsicht, Sorgfaltspflichten) sind
nicht begrenzt. Für das Berichtsjahr 2025 gilt die Begrenzung noch nicht.
