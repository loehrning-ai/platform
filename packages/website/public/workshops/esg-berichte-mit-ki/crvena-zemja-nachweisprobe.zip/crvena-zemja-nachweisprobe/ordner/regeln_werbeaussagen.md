# Regeln für Umweltaussagen gegenüber Verbrauchern
Erfundene Übungsdaten. Ausnahme: Diese Datei fasst echtes EU-Recht zusammen. Lernhilfe, keine Rechtsberatung.

Die Richtlinie (EU) 2024/825 ändert die Richtlinie über unlautere Geschäftspraktiken (2005/29/EG).
Die Mitgliedstaaten wenden sie seit dem 27.09.2026 an, Deutschland über das Gesetz gegen den
unlauteren Wettbewerb (UWG). Sie gilt für Aussagen gegenüber Verbrauchern in der EU, auch für einen
Hersteller außerhalb der EU, dessen Etikett in einem deutschen Regal steht.

Immer verboten, mit oder ohne Nachweis (Anhang I der Richtlinie 2005/29/EG):
- Nr. 2a: ein Nachhaltigkeitssiegel, das weder auf einem Zertifizierungssystem beruht noch von einer
  Behörde festgelegt ist.
- Nr. 4a: eine allgemeine Umweltaussage wie „umweltfreundlich“ oder „grün“ ohne anerkannte hervorragende
  Umweltleistung, zum Beispiel das EU-Umweltzeichen.
- Nr. 4b: eine Umweltaussage über das ganze Produkt oder die ganze Firma, die nur für einen Teil stimmt.
- Nr. 4c: die Aussage, ein Produkt sei wegen Kompensation klimaneutral, klimareduziert oder klimapositiv.
- Nr. 10a: eine gesetzliche Pflicht als Besonderheit des eigenen Angebots darstellen.

Nicht auf der Liste, aber irreführend ohne Plan (Art. 6 Abs. 2 Buchst. d): Aussagen über künftige
Umweltleistung, etwa „ab 2027 mit Solarstrom“. Erlaubt nur mit klaren, öffentlich zugänglichen und
überprüfbaren Verpflichtungen in einem detaillierten, realistischen Umsetzungsplan mit messbaren,
befristeten Zielen, den unabhängige Sachverständige regelmäßig prüfen.

In Deutschland galt schon vorher: Wer mit „klimaneutral“ wirbt, muss in der Werbung selbst erklären,
ob Minderung oder Kompensation gemeint ist (BGH, Urteil vom 27.06.2024, I ZR 98/23).

So prüfst du eine Aussage:
1. Trifft ein Punkt der Verbotsliste zu, wird sie gestrichen.
2. Sonst die Nachweisprobe. Nur BELEGT für alles, woran die Aussage steht, darf raus.
Sichere Fassung: konkret, gemessen, mit Quelle und Datum, wahr für genau das, woran sie steht.
Trägt keine Datei eine sichere Fassung: „Streichen.“
