# Firmenprofil: Vinarija Crvena Zemja DOO
Erfundene Übungsdaten. Jede Firma, Person und jedes Dokument ist erfunden.

- Familienweingut in der Gemeinde Kavadarci, Nordmazedonien, im Weinbaugebiet Tikveš.
- NACE: 11.02 Herstellung von Traubenwein. Standorte: ein Keller mit Abfüllung in der Gemeinde Kavadarci (gerundet: 41,44 N, 22,02 O), dazu 40 ha eigene Weinberge in der Nähe, in einem Block (Mitte, gerundet: 41,42 N, 22,05 O).
- Produkte: Stillwein in Flaschen (Vranec, Kratošija, Smederevka), rund 550.000 Flaschen im Jahr.
- Weinberge: 40 ha in eigenem Besitz. 12 ha nach Bio-Regeln bewirtschaftet (siehe bio_zertifikat_weinberg.txt).
- Die Weinberge werden nicht bewässert. Wasser brauchen der Keller, die Abfüllung und das Spritzen im Weinberg: Die Spritzen werden am Kellerhahn gefüllt, dieses Wasser steht auf denselben Rechnungen des Wasserversorgers. Kein Brunnen, keine andere Quelle.
- Personal: 42 Beschäftigte im Jahresdurchschnitt 2025, dazu 18 Saisonkräfte zur Lese (keine Beschäftigten).
- Umsatz 2025: 95,0 Mio. MKD. Kleines Unternehmen.
- Bilanzsumme 31.12.2025: 162,0 Mio. MKD (Jahresabschluss 2025).
- Absatz 2025: Export 74 % des Umsatzes (Deutschland 31 %, Nordvik Vin AB in Schweden 22 %, Polen 17 %, Sonstige 4 %). Inland 26 %.
- Energie: Strom komplett aus dem Netz, Versorger Lumivolt Snabduvanje DOOEL. Noch keine PV. Keine eigene Erzeugung.
- Brennstoffe: Diesel für 4 Weinbergtraktoren und 1 Gabelstapler. Die Tankbelege hat der Weinbergleiter, sie liegen nicht in diesem Ordner.
- Jede Stromrechnung nutzt denselben erfundenen Einheitstarif von 9,50 MKD/kWh (keine echte Preisliste).
- Die Tankkühlung läuft im September und Oktober am stärksten.
- Eine Treibhausgasbilanz wurde nicht erstellt.
- Geplant: 150 kWp PV auf dem Dach, Kredit über 8.550.000 MKD bei der Banka Povardarie AD Skopje beantragt, eine grüne Kreditlinie nach Art der EBRD.
