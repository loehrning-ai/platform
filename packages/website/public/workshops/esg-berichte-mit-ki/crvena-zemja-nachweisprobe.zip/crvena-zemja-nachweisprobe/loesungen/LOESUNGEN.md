# Lösungen: Crvena Zemja
Erfundene Übungsdaten. Claude formuliert anders als wir: Vergleiche Status und Zahlen.
Zeilen zählen wie im Texteditor. Bei längeren Dateien liegt Claude manchmal eine Zeile daneben;
prüf, ob die Zeile sagt, was Claude behauptet.

## Durchsicht
| # | Mangel | Datei, Zeile | Prüfung |
|---|---|---|---|
| 1 | September 2025 fehlt: Auf August folgt Oktober. | strom_2025.csv 10, 11 | Zeitraum |
| 2 | EL-25-10 zweimal erfasst (E-Rechnung und Scan). 12 Zeilen sind 11 Monate. | strom_2025.csv 11, 12 | Zeitraum |
| 3 | Der Entwurf nennt 11 Monate „ganzes Jahr“ und gibt sie für die Bank frei. | strom_zusammenfassung_entwurf.txt 5 | Stand |
| 4 | Bio-Zertifikat seit 31.08.2026 abgelaufen, am Stichtag seit 46 Tagen. | bio_zertifikat_weinberg.txt 8 | Zeitraum |
| 5 | Es deckt 12 von 40 ha, nicht Keller und Weinbereitung. | bio_zertifikat_weinberg.txt 6, 10, 11 | Umfang |
| 6 | Kompensation mit Vermerk „für Klimaneutral-Label“. | kompensation_2025.txt 7 | Verbotsliste 4c |
| 7 | Angebot nicht unterschrieben; 180 MWh sind eine Schätzung des Installateurs. | pv_angebot_2026.txt 3, 8, 11 | Stand |
| 8 | Reserve 560 g bei 239 NOK; Grenze 420 g unter 250 NOK. | flaschen.csv 5 | belegt, Regel verletzt |
Saubere Datei: wasser_2025.csv, 12 von 12 Rechnungen, 4.630 m³. September (980 m³) ist die Lese.
Ebenfalls richtig: keine Rechnungen 2024; Strommix „nicht angegeben“; keine THG-Bilanz, keine
Dieselbelege; keine Arbeitsstunden für eine Unfallquote; amfori BSCI ist ein Audit, kein Zertifikat;
Saisonkräfte sind keine Beschäftigten.

*Stopp. Weiter erst nach Schritt 1.*








































## Schritt 1: Fragebogen
| Q | Status | Warum | Datei, Zeile |
|---|---|---|---|
| Q1 | LÜCKE | 11 von 12 Monaten (91,7 %, Regel 95 %), 279,7 MWh. EL-25-10 doppelt, zählt einmal; wer alle Zeilen addiert, kommt auf 318,4 MWh. Der Entwurf nennt es „ganzes Jahr“: Widerspruch. Strommix überall „nicht angegeben“. Fehlt: Rechnung September 2025, Strommix-Nachweis des Versorgers. | strom_2025.csv 3 bis 14; entwurf 5; fragebogen 12 |
| Q2 | LÜCKE | Keine THG-Bilanz, keine Dieselbelege, kein Netz-Emissionsfaktor. 120 t Kompensation sind keine eigenen Emissionen. Fehlt: Dieselbelege 2025, Rechnung September 2025, veröffentlichter Netz-Emissionsfaktor für Nordmazedonien. | firmenprofil 14, 17; kompensation 5; vsme_basismodul 12 |
| Q3 | BELEGT | 42: 36 unbefristet (20 M, 16 F), 6 befristet (4 M, 2 F). Saisonkräfte sind keine Beschäftigten. | personal 3 bis 6 |
| Q4 | BELEGT | 2 meldepflichtige Unfälle, 0 tödlich. | arbeitsschutz 4 bis 7 |
| Q5 | BELEGT | Keine; Erklärung der Geschäftsführung vom 15.01.2026. | richtlinien 13, 14 |
| Q6 | BELEGT | Vranec 395 g und Kratošija 410 g bestehen; Reserve 560 g bei 239 NOK liegt 140 g über 420 g. Maßnahme: Flasche bis 420 g, Preis ab 250 NOK oder Reserve nicht anbieten. | flaschen 3 bis 5; fragebogen 21 |
| Q7 | SCHWACH | Bio-Zertifikat am Abgabetag abgelaufen; Erneuerungsprüfung am 22.10. amfori BSCI: Audit 12.03.2026, Bewertung B, kein Zertifikat. Der schwächste Teil zählt. | bio 6 bis 9; richtlinien 8, 9; fragebogen 7, 11 |
| Q8 | BELEGT | 4.630 m³ aus 12 von 12 Rechnungen, Spritzwasser inklusive. | wasser 3 bis 14; firmenprofil 8 |
Summe: 5 BELEGT, 1 SCHWACH, 2 LÜCKE. Auch vertretbar: Q1 als SCHWACH, wenn September genannt ist.

*Stopp. Weiter erst nach Schritt 2.*








































## Schritt 2: Werbeaussagen
| # | Verbotsliste | Status | Darf raus | Grund | Sichere Fassung |
|---|---|---|---|---|---|
| 1 | 4c | LÜCKE | nein | Kompensation, keine THG-Bilanz (kompensation 7, firmenprofil 17) | Streichen. |
| 2 | 4a | LÜCKE | nein | allgemein, keine anerkannte hervorragende Umweltleistung | Streichen. Aussage 7 sagt Konkretes. |
| 3 | 4b | LÜCKE | nein | abgelaufen; 12 von 40 ha; Keller nicht; Karte an allen Weinen (bio 6, 8, 10, 11) | Nach der Erneuerung, nur Website: „12 unserer 40 ha Weinberge sind bio-zertifiziert (Kontrollstelle XX-BIO-000, gültig bis [Datum]).“ |
| 4 | keine | LÜCKE | nein | Strom komplett aus dem Netz (firmenprofil 13); Angebot nicht unterschrieben (pv_angebot 3, 11) | Streichen. Nach Inbetriebnahme nur gemessene Werte. |
| 5 | keine | LÜCKE | nein | keine Rechnungen 2024; 2025 unvollständig | Streichen, bis beide Jahre belegt sind. |
| 6 | keine | BELEGT | ja, umformuliert | Lieferantenerklärung Feb. 2026 (flaschen 3); „nur“ ist ein Vergleich ohne Nachweis | „Das Glas dieser Flasche wiegt 395 g und enthält 60 % Recyclingglas (Erklärung des Glaslieferanten, Feb. 2026).“ |
| 7 | keine | BELEGT | ja | 12 von 12 Rechnungen, keine andere Quelle (wasser 3 bis 14, firmenprofil 8) | wie gesendet |
Summe: 2 dürfen raus, 3 Verbotsliste, 2 ohne Nachweis.

*Stopp. Weiter erst nach Schritt 3.*








































## Schritt 3: Bankformular
| Feld | Status | Antwort und Grund |
|---|---|---|
| F1 | BELEGT | Keine Bußgelder 2023 bis 2025 (richtlinien 13, 14). |
| F2 | LÜCKE | 279,7 MWh sind 11 Monate. Fehlt: Rechnung September 2025. Dieselbe Lücke wie Q1. |
| F3 | LÜCKE | 180 MWh sind eine Schätzung (pv_angebot 8). Der Anteil braucht ein ganzes Jahr; 64,4 % beruht auf 11 Monaten. |
| F4 | SCHWACH | 5,0 Jahre = 8.550.000 / (180.000 × 9,50), im Code. Schätzung aus einem unsignierten Angebot (pv_angebot 6, 8, 9, 11). |
| F5 | BELEGT | 42 Beschäftigte, 2 Unfälle, 0 tödlich. |
| F6 | SCHWACH | wie Q7. |
Summe: 2 BELEGT, 2 SCHWACH, 2 LÜCKE.

*Stopp. Weiter erst nach Schritt 4.*








































## Schritt 4: Nachweisregister
Register: 21 Zeilen, 9 BELEGT, 3 SCHWACH, 9 LÜCKE.
| Angabe | Status | Belegt | Fehlendes Dokument |
|---|---|---|---|
| B1 | BELEGT | 8 von 8 | |
| B2 | BELEGT | 4 von 4 | („nicht veröffentlicht“, „keine Ziele“ sind gültige Antworten) |
| B3 | LÜCKE | 0 von 4 | Rechnung September 2025, Dieselbelege, Netz-Emissionsfaktor |
| B4 | LÜCKE | 0 von 1 | Umweltgenehmigung oder schriftliche Prüfung der Meldepflicht |
| B5 | LÜCKE | 0 von 1 | datierte Kartenprüfung der Standorte gegen Schutzgebiete |
| B6 | BELEGT | 1 von 1 | |
| B7 | LÜCKE | 1 von 4 | Abfall gesamt, gefährlich, Anteil verwertet |
| B8 | BELEGT | 2 von 2 | |
| B9 | LÜCKE | 2 von 3 | Arbeitsstunden 2025 (für die Unfallquote) |
| B10 | LÜCKE | 1 von 3 | Erklärung Mindestlohn, Anteil Tarifbindung |
| B11 | BELEGT | 1 von 1 | |
Summe: 5 BELEGT, 6 LÜCKE. Auch vertretbar: B3 als SCHWACH mit Hinweis auf September; nach Regel 3 ist ein
fehlender Datenpunkt LÜCKE.
Anfordern, oben: Rechnung September 2025 (Q1, Q2, C5, F2, F3, B3).

*Stopp. Weiter erst nach Schritt 5.*








































## Schritt 5: Die nachgereichte Rechnung
EL-25-09: 41.200 kWh (Zählerstände 1.325.550 minus 1.284.350), 9,50 MKD/kWh, 391.400 MKD, Strommix „nicht angegeben“.
| Wo | Vorher | Jetzt | Warum |
|---|---|---|---|
| F2 | 279,7 MWh, LÜCKE | 320,9 MWh, BELEGT | 12 von 12 Monaten. Der Entwurf ist widerlegt. |
| F3 | LÜCKE | 56,1 %, SCHWACH | Anteil jetzt rechenbar, 180 MWh bleiben eine Schätzung. |
| Q1 | LÜCKE | 320,9 MWh, LÜCKE | Strommix fehlt weiter. |
| Q2 | LÜCKE | LÜCKE | Emissionsfaktor und Dieselbelege fehlen weiter. |
| C5 | nein | nein | Rechnungen 2024 fehlen weiter. |
| F4 | 5,0 Jahre, SCHWACH | unverändert | Die Formel nutzt Ertrag und Tarif, nicht den Verbrauch. |
| B3 | 0 von 4, LÜCKE | 1 von 4, LÜCKE | Strom belegt, Brennstoffe und Scope 1 und 2 fehlen. |
| Entwurf | „ganzes Jahr 279,7“ | falsch | 41,2 MWh zu niedrig. Korrigieren, nicht schicken. |
| 11 Monate × 12/11 | 305,1 MWh | 15,8 MWh zu niedrig | September ist der Monat der Tankkühlung (firmenprofil 16). |
| Alle Zeilen addiert | 318,4 MWh | 2,5 MWh zu niedrig | nah dran, aus dem falschen Grund. |
Es ändern sich zwei Status: F2 und F3. Register danach: 10 BELEGT, 4 SCHWACH, 7 LÜCKE.

## Warum Claudes Antwort abweichen kann
Im Code gerechnete Zahlen müssen genau stimmen: 279,7, 318,4, 320,9, 305,1, 15,8 und 41,2 MWh,
64,4 % und 56,1 %, 5,0 Jahre, 4.630 m³. Weicht eine ab, lass Claude im Code neu rechnen und den Code
zeigen. Bei Grenzfällen sagt ein Lauf SCHWACH, wo ein anderer LÜCKE sagt; entscheide mit `nachweisprobe.md`.
