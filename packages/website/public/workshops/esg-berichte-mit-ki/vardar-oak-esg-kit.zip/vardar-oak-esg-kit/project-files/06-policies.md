# Policies

> Fictional teaching documents.

## 1. Environmental policy (adopted 3 March 2022, signed by the managing director)

Vardar Oak Furniture commits to use timber from responsible sources, to reduce waste and to
use energy carefully. We sell all wood offcuts for reuse and we keep hazardous waste away from
landfill. Since 2024 all tables are finished with water-based lacquer. Chairs and benches still
use a solvent-based lacquer; we plan to switch them when a suitable product is approved.

The policy does not set numerical targets.

## 2. Code of conduct (adopted 10 May 2023)

Applies to all employees. Sections: respect at work, health and safety, no discrimination,
confidential information, and **anti-bribery**: no employee may offer, give or accept gifts,
payments or favours to win or keep business. Breaches can be reported to the managing director
or anonymously by letter.

The code of conduct covers our own employees. It does not cover our suppliers.

## 3. Not in place

- No human rights policy.
- No supplier code of conduct.
- No greenhouse gas reduction target.
