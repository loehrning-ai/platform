# Emission factors used by Vardar Oak

> Teaching values for this workshop. For a real report, use the current official factor for your
> country and fuel (for example from your national energy agency, the IEA or the UK DESNZ
> conversion factors) and write down which source and year you used.

| What | Factor | Unit | Scope |
|---|---|---|---|
| Grid electricity, North Macedonia | 0.75 | kg CO₂e per kWh | Scope 2 (location-based) |
| Diesel (trucks, forklifts) | 2.68 | kg CO₂e per litre | Scope 1 |
| Diesel energy content | 10.0 | kWh per litre | for total energy use |

How to calculate:

- Scope 1 (t CO₂e) = litres of diesel × 2.68 ÷ 1,000
- Scope 2 (t CO₂e) = kWh of electricity × 0.75 ÷ 1,000
- Total energy (MWh) = (kWh of electricity + litres of diesel × 10.0) ÷ 1,000

The company has no green tariff and no guarantees of origin, so a market-based Scope 2 figure
would use the same grid value here.
