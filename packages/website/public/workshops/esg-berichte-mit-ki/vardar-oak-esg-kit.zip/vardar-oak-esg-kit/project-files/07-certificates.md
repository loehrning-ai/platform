# Certificates

> Fictional teaching documents. Certificate codes are invented and do not exist.

## FSC Chain of Custody certificate

| Field | Value |
|---|---|
| Certificate code | TEACH-COC-004217 (fictional) |
| Scope | Purchase of FSC-certified oak, manufacture of solid oak furniture |
| Valid from | 1 September 2021 |
| Valid until | **31 August 2026** |
| Status note | The re-certification audit was postponed by the certification body. New audit date: 18 November 2026. |

FSC-certified share of oak purchased in 2025: **78 %** of the volume (the Croatian supplier).
The other 22 % came from the North Macedonian supplier and is not certified.

## ISO 9001 (quality management)

| Field | Value |
|---|---|
| Certificate code | TEACH-QMS-88120 (fictional) |
| Valid until | 14 March 2027 |

ISO 9001 is about quality management. It is not an environmental certificate.
