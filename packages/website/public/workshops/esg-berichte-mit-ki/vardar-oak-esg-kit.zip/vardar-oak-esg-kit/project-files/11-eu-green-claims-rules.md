# EU rules on environmental claims: what changed on 27 September 2026

> Teaching summary, not legal advice. Source: Directive (EU) 2024/825 ("Empowering Consumers for
> the Green Transition"), which amends the Unfair Commercial Practices Directive. Full text:
> https://eur-lex.europa.eu/eli/dir/2024/825/oj
>
> It applies to claims made to consumers in the EU, from 27 September 2026. A supplier outside the
> EU is affected as soon as its claims appear in an EU shop, catalogue or product page.

## Banned in all cases

1. **Generic environmental claims** such as "eco-friendly", "green", "environmentally friendly",
   "natural" or "climate friendly", unless the company can show recognised excellent environmental
   performance relevant to the claim (for example the EU Ecolabel).
2. **Sustainability labels** that are not based on a certification scheme or set up by a public
   authority.
3. **Claims about the whole product or the whole company** when the benefit only concerns one part
   of it.
4. **"Climate neutral", "CO₂-neutral" or "reduced CO₂" claims based on offsetting** emissions
   elsewhere.
5. Presenting something that the **law requires anyway** as if it were a special feature of the
   offer.

## Allowed, if you can prove it

- **Specific, verifiable claims**: "412 tonnes of wood offcuts reused in 2025", "tables finished
  with water-based lacquer since 2024".
- **Future claims** ("net zero by 2035") only with a detailed, realistic plan, measurable targets
  and regular checks by an independent expert.

## The test for every claim

Is it specific? Is it true for the whole product it is attached to? Is it true **today**? Can we
show the document that proves it?
