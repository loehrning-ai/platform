# VSME Basic module: the eleven headings

> Simplified teaching summary of the Basic module of the EU Voluntary Sustainability Reporting
> Standard for non-listed SMEs (VSME, Commission Recommendation (EU) 2025/1710). A Delegated
> Regulation adopted in July 2026 and published in September 2026 turns it into the "Voluntary Standard"
> (VS); the B1 to B11 structure stays the same. For
> a real report, use the official text and EFRAG's free digital template:
> https://www.efrag.org/en/vsme-digital-template-and-xbrl-taxonomy

| # | Heading | What it asks for, in short |
|---|---|---|
| B1 | Basis for preparation | Which module is used, legal form, activity (NACE), country, sites, turnover, number of employees, sustainability certificates or labels |
| B2 | Practices, policies and future initiatives | Whether the company has practices, policies or plans on climate, pollution, water, biodiversity, circular economy, own workforce, workers in the value chain, communities, consumers and business conduct |
| B3 | Energy and greenhouse gas emissions | Total energy use in MWh (renewable and non-renewable), Scope 1 and Scope 2 emissions in t CO₂e |
| B4 | Pollution of air, water and soil | Pollutant emissions, where the company already has to report them by law |
| B5 | Biodiversity | Sites in or near biodiversity-sensitive areas, and their size |
| B6 | Water | Total water withdrawal, and withdrawal at sites in areas of high water stress |
| B7 | Resource use, circular economy and waste | Circular practices, total waste (hazardous and non-hazardous) and how much goes to recycling or reuse |
| B8 | Workforce: general characteristics | Employees by contract type and gender, country, turnover rate |
| B9 | Workforce: health and safety | Recordable work accidents, accident rate, fatalities |
| B10 | Workforce: pay, collective bargaining and training | Pay at or above minimum wage, gender pay gap, collective bargaining coverage, average training hours by gender |
| B11 | Convictions and fines for corruption and bribery | Number of convictions and total fines |
