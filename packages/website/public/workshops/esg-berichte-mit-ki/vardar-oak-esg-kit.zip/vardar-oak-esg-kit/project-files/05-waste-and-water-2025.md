# Waste and water 2025

> Fictional teaching data. Source: waste transfer notes and water bills, filed by the plant manager.

## Waste 2025

| Waste stream | Tonnes | Hazardous? | What happened to it |
|---|---|---|---|
| Wood offcuts and sawdust | 412.0 | No | Sold to a pellet producer in Kavadarci, who turns it into wood pellets (recycled) |
| Packaging (cardboard, film) | 18.4 | No | Collected by a licensed recycler (recycled) |
| Mixed general waste | 9.6 | No | Municipal collection (landfill) |
| Lacquer and solvent residues | 3.8 | Yes | Handed to a licensed hazardous waste collector (incineration) |

## Water 2025

- Water source: municipal supply only. No own well.
- Water withdrawal 2025: 2,950 m³ (sum of the four quarterly water bills).
- Water is used for sanitary facilities and for cleaning the paint line.

## Not measured

- Air emissions from the paint line (volatile organic compounds) were not measured in 2025.
- Nobody has checked whether the site is near a protected nature area.
