# Vardar Oak Furniture DOOEL: company profile

> Fictional teaching company. Every name, number and document in this kit is invented.

| Field | Value |
|---|---|
| Legal name | Vardar Oak Furniture DOOEL |
| Legal form | DOOEL (single-member limited liability company) |
| Country | North Macedonia |
| Site | One site: factory, warehouse and showroom, Industriska zona bb, Veles |
| Site area | 1.8 ha, municipal industrial zone |
| Founded | 2009 |
| Activity | Manufacture of solid oak dining tables, chairs and benches (NACE C31.09, manufacture of other furniture) |
| Reporting year | Calendar year 2025 (1 January to 31 December) |
| Turnover 2025 | EUR 6.4 million |
| Export share 2025 | 72 % of turnover, all to the EU |
| Largest customer | Hausfeld Wohnen GmbH (online and store furniture retailer, Germany), 41 % of turnover 2025 |
| Managing director | the owner (named in the court register; not needed for ESG answers) |

## How the factory runs

- Heating: electric heat pumps. Their use is included in the electricity bills.
- Machines, lighting, dust extraction and the paint line run on grid electricity.
- The grid electricity contract is a standard tariff. There is no green tariff and no guarantee of origin.
- No own power generation in 2025. A 250 kWp rooftop solar plant is planned (see 09-solar-quote.md).
- Two delivery trucks and two forklifts run on diesel (see 04-fuel-log-2025.csv).
- Oak is bought as sawn timber from two suppliers: one in Croatia (FSC-certified), one in North Macedonia (not certified).
- Warranty: 10 years on all tables, 5 years on chairs and benches (standard sales terms, version 2024). The legal minimum guarantee for consumers in the EU is 2 years.

## Compliance notes (confirmed by the managing director, 15 January 2026)

- No convictions and no fines for corruption or bribery in 2025.
- No environmental fines in 2025.
- Environmental permit: the factory holds a B-integrated environmental permit from the Municipality of Veles, issued 2019, no expiry date.
