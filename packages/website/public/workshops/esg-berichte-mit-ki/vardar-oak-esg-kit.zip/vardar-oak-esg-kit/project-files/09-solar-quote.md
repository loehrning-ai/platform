# Rooftop solar: supplier quote (received 2 September 2026)

> Fictional teaching document.

| Item | Value |
|---|---|
| System | 250 kWp rooftop photovoltaic plant on the factory hall |
| Expected yield | 320,000 kWh per year (supplier estimate, year 1) |
| Expected self-use | 100 % (the factory uses more than the plant produces in every month) |
| Price | EUR 215,000 including installation |
| Planned start of operation | April 2027, if financing is approved |
| Financing | Loan request to Northbridge Bank AD Skopje, EUR 180,000 |

The quote is an estimate by the installer. It is not a guarantee.
