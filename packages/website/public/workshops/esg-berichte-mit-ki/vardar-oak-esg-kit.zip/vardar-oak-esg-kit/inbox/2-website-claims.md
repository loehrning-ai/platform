# Draft claims for the Hausfeld online shop

> From: Vardar Oak marketing. To go live on the product pages of our solid oak tables and chairs in
> Hausfeld's German online shop. Fictional teaching document.

1. "Eco-friendly furniture, made in North Macedonia."
2. "100 % FSC-certified oak."
3. "Climate-neutral production."
4. "Made with green energy."
5. "In 2025, 412 tonnes of our wood offcuts and sawdust were turned into wood pellets."
6. "Finished with water-based lacquer."
7. "10-year warranty on every table."
