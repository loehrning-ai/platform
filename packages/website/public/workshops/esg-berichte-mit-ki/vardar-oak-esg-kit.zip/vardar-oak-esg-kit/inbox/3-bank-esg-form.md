# Northbridge Bank AD Skopje: ESG questions for business loans

> Fictional teaching document. Loan request: EUR 180,000 for a 250 kWp rooftop solar plant.

Please answer each question. If information is not available, say so.

1. Main business activity and number of employees.
2. Total electricity consumption in the last full year (MWh).
3. Greenhouse gas emissions in the last full year, Scope 1 and Scope 2 (t CO₂e).
4. How much electricity will the financed project produce per year, and what share of your current consumption is that?
5. How many tonnes of CO₂e per year will the project avoid, and how did you calculate it?
6. Do you hold a valid environmental permit? Any environmental fines in the last three years?
7. Do you have a written environmental policy and any emission reduction target?
8. Which sustainability reporting standard do you follow, if any?
