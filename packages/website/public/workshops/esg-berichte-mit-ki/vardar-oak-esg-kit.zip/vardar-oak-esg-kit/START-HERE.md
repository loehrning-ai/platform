# Answer ESG by Friday: the Vardar Oak kit

Vardar Oak Furniture is a fictional furniture maker in Veles, North Macedonia: 86 employees, solid oak
tables, most of them sold in the EU. On Monday three ESG requests arrive: a customer questionnaire, a
marketing question about green claims, and a bank form. You answer all three with Claude, from one set
of facts, and you claim nothing the files cannot prove.

Every company, person, number and certificate in this kit is invented.

**You need:** the Claude desktop app or claude.ai (any plan), with *Code execution and file creation*
switched on in Settings. No code, no API key. About 45 minutes.

| In this kit | What it is |
|---|---|
| `project-files/` | The company's facts (11 files). Upload all of them to a Claude Project. The files are a little messy, like real ones. |
| `inbox/` | The three requests. Attach each one at its step. |
| `project-instructions.md` | Three rules for Claude. Paste them into the Project instructions. |

---

## Step 0 · Set up the Project (once)

1. In Claude, create a **Project** called `Vardar Oak ESG`.
2. Paste the text of `project-instructions.md` into the Project instructions.
3. Add all files from `project-files/` to the Project.

## Step 1 · The customer's questionnaire

New chat in the Project. Attach `inbox/1-customer-questionnaire.csv`, then send:

```
Our biggest customer, Hausfeld, sent this supplier questionnaire and wants it back by Friday.
Fill in every row from our project files: the Answer, Source and Status columns.
Status is ANSWERED, NEEDS CHECK or NOT FOUND.
Give me the completed Excel file to download.
Then tell me in five lines or fewer: how many rows have each status, and what I must fix before Friday.
```

## Step 2 · Check before you send

Same chat. Send:

```
Before I send this, prove two answers to me.
1. Electricity and Scope 2: list the monthly rows you used, the total, and the factor. Is any month missing or counted twice?
2. FSC: was our oak certified during 2025, and is the certificate valid today? How much of our oak was certified?
Then list every answer that is still open, one line each: what is missing and which document would close it.
```

## Step 3 · Marketing wants green claims

New chat in the Project. Attach `inbox/2-website-claims.md`, then send:

```
Our marketing team wants these claims on Hausfeld's German online shop.
Check each claim against our project files and the EU rules in 11-eu-green-claims-rules.md.
Make a table: claim, verdict (red, amber or green), the reason with its source, and a rewrite we can prove today.
Put the red ones first.
```

## Step 4 · Build the ESG passport

New chat in the Project. Send:

```
Turn everything we know into a short "ESG passport" for Vardar Oak, at most two pages, using the eleven headings in 10-vsme-basic-headings.md.
Under each heading: our facts with numbers and sources.
Where we have no data, write "Not reported yet" and what we need to collect.
Finish with a short list: "Open points before our next report".
Create it as a Word document I can download.
```

## Step 5 · The bank asks too

Same chat as step 4. Attach `inbox/3-bank-esg-form.md`, then send:

```
Our bank needs this form for the solar loan. Answer it from the passport and our project files, same rules.
For questions 4 and 5, show the calculation.
```

---

## What good looks like

- Step 1: most rows ANSWERED, a few NEEDS CHECK. Read those first: they are the point.
- Step 2: Claude shows its sums and names what is missing, instead of rounding it away.
- Step 3: most claims fail. Every rewrite points to a file that proves it.
- Steps 4 and 5: the second asker takes a minute, because the facts are already collected.

## Use it on your own company

Replace the files in `project-files/` with your own, keep `project-instructions.md`, and run the same
five steps on the next questionnaire you receive.
