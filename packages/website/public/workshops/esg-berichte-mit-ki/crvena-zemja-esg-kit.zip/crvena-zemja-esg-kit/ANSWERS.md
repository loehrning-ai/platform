# Answer key: the Crvena Zemja kit

**Open this only after you've run a step.** Claude's wording will differ from ours, so compare the
statuses and the numbers.

Fictional training data. Every company, person and document is invented.

How to use this key:
- Each section ends with a stop line, followed by empty space. Don't scroll past a stop line
  before you've run the next step.
- Line numbers count every line of a file, as a text editor does. Claude's line numbers can be off
  by one or two in the longer text files, so check that the line says what Claude claims.
- All files named here are in `project-files/`, unless the name starts with `inbox/`.

---

## Trap hunt (warm-up)

| # | What's wrong | Where (file, lines) | Also counts if you found it in a request |
|---|---|---|---|
| 1 | The September 2025 electricity bill is missing. There are 11 bills, and the list jumps from August to October. | `energy_bills_2025.csv`, lines 10-11 | |
| 2 | The draft note calls 11 months a "full year" and says "OK to send to bank". | `energy_summary_2025_draft.txt`, line 5 | |
| 3 | The organic certificate expired on 31.08.2026, and today is 16.10.2026. | `organic_certificate_vineyard.txt`, line 8 | Claim 3, "Certified organic" (`inbox/2-marketing-claims.md`, line 10), or Q7, "valid certificates" (`inbox/1-nordvik-questionnaire.md`, line 22) |
| 4 | The certificate covers only 12 of 40 ha, and not the cellar or the winemaking. | `organic_certificate_vineyard.txt`, lines 6, 10-11 | Claim 3, "Certified organic" on all wines (`inbox/2-marketing-claims.md`, line 10) |
| 5 | The carbon offsets are marked "use for climate-neutral label". | `carbon_offsets_2025.txt`, line 7 | Claim 1, "Climate-neutral wine" (`inbox/2-marketing-claims.md`, line 8) |
| 6 | The solar offer isn't signed, and 180 MWh a year is only the installer's estimate. | `solar_offer_2026.txt`, lines 3, 8, 11 | Claim 4, "Solar-powered winery" (`inbox/2-marketing-claims.md`, line 11) |
| 7 | The 560 g Reserve bottle sells at NOK 239. That's under NOK 250, so Norway's 420 g rule applies, and the bottle fails it. | `packaging_bottles.csv`, line 5 | Q6, the 420 g rule (`inbox/1-nordvik-questionnaire.md`, line 21) |

**The clean file** is `water_bills_2025.csv`. It has 12 of 12 bills, 4,630 m3 in total. The peak in
September (980 m3, line 11) comes from the harvest, so it isn't an error.

How to score:
- You get 2 points for each trap in the table. A trap counts if you found the problem in either
  place: in the project file, or in the request that uses it (last column). Each trap counts once.
- Traps 3 and 4 are two problems in one file. If you wrote both in one line, you still get 2 points
  for each.
- You get plus 1 if you named `water_bills_2025.csv` as the clean file, and minus 1 if you flagged
  it as a trap.
- The maximum is 15. You also get a bonus of plus 1 for each item you found from the list of extra
  problems below. Write the bonus points next to your score.

Score bands:
- 12 to 15: very good. You'd make a good auditor.
- 8 to 11: good. Claude will show you the rest.
- 7 or less: that's normal for a first look. It's the reason we work with one folder, the three
  rules and Claude.

Extra problems (bonus points):
- Claim 5, "We cut our electricity use by 12% in 2025": there are no 2024 bills to compare with
  (`inbox/2-marketing-claims.md`, line 12).
- Every electricity bill says the supply mix is "not specified", so no renewable share can be proven
  (`energy_bills_2025.csv`, lines 3-13).
- There's no greenhouse gas inventory (`company_profile.md`, line 17), and the diesel receipts
  aren't in the files (line 14).
- The safety register has no hours worked, so no accident rate can be calculated
  (`health_safety_2025.txt`, lines 3-8).
- amfori BSCI is an audit, so it doesn't count as a certificate, and its name never goes on a label
  (`policies_and_compliance.txt`, lines 9-12).
- The 18 seasonal day workers aren't employees (`hr_headcount_2025.csv`, line 6).

*Stop here until you've run Step 1. The Step 1 answers are further down.*














































---

## Step 1: the supplier questionnaire

| Q | Status | Why | Where (file, lines) |
|---|---|---|---|
| Q1 Electricity 2025 and renewable share | NOT FOUND | There are only 11 of 12 monthly bills, with 279.7 MWh for January to August and October to December. September is missing. 11 of 12 months is 91.7%, which is below Nordvik's 95% rule. The draft note calls 279.7 MWh a "full year", so the files conflict. Every bill says the supply mix is "not specified", so there's no renewable share either. Missing: the September 2025 bill and the supplier's statement of its supply mix. | `energy_bills_2025.csv` 3-13; `energy_summary_2025_draft.txt` 5; `inbox/1-nordvik-questionnaire.md` 12 |
| Q2 Scope 1 and Scope 2 | NOT FOUND | There's no greenhouse gas inventory. The diesel receipts aren't in the files, and no file gives a grid emission factor. The 120 tCO2e of offsets are credits we bought, so they aren't our emissions. The documents that would close it are the diesel receipts 2025 (Scope 1), and the September 2025 bill plus a published grid emission factor for North Macedonia (Scope 2 = kWh of the full year × the factor). With these, the inventory can be built. | `company_profile.md` 14, 17; `carbon_offsets_2025.txt` 5; `vsme_basic_headings.md` 12 |
| Q3 Headcount | OK | 42 employees on average: 36 permanent (20 men, 16 women) and 6 fixed-term (4 men, 2 women), so 24 men and 18 women in total. The 18 seasonal day workers aren't employees. | `hr_headcount_2025.csv` 3-6 |
| Q4 Accidents | OK | 2 recordable accidents among employees (both at harvest, cellar staff), 0 among seasonal day workers, 0 fatalities. | `health_safety_2025.txt` 4-7 |
| Q5 Corruption | OK | The director's declaration of 15 January 2026 says there were no convictions or fines for corruption or bribery in 2023, 2024 or 2025. | `policies_and_compliance.txt` 13-14 |
| Q6 Glass weight | OK, plus an action | `packaging_bottles.csv` gives all three weights, taken from the glass supplier declaration (February 2026). Vranec Tikveš 2024 (395 g) and Kratošija Tikveš 2024 (410 g) pass. Reserve Vranec 2021 is 560 g at NOK 239, so it fails the 420 g limit by 140 g. The status is OK because the file proves the weight, even though the result is bad. Before the tender, the winery needs to do one of three things: use a bottle of 420 g or less, set a price of NOK 250 or more (the rule covers only wine under NOK 250), or leave the Reserve out of the tender. | `packaging_bottles.csv` 3-5; `inbox/1-nordvik-questionnaire.md` 21 |
| Q7 Certificates and audits | NEEDS CHECK | The organic certificate (12 of 40 ha, vineyard only) expired on 31.08.2026, so it isn't valid on the submission date. The renewal inspection on 22.10 is one day before Nordvik's 23.10 deadline, so the new certificate may not be ready in time. amfori BSCI had an audit on 12 March 2026 with rating B, and the next full audit is in March 2028. It's an audit, so it doesn't count as a certificate. The weakest part sets the status. | `organic_certificate_vineyard.txt` 6-9; `policies_and_compliance.txt` 8-9; `inbox/1-nordvik-questionnaire.md` 7, 11 |
| Q8 Water | OK | 4,630 m3 from 12 of 12 municipal bills. This includes the spray water for the vineyards, because the sprayers are filled at the cellar tap. This is the clean file, so there's nothing to flag. | `water_bills_2025.csv` 3-14; `company_profile.md` 8 |

**Total: 5 OK, 1 NEEDS CHECK, 2 NOT FOUND.** In `nordvik-answers.xlsx`, OK should be green,
NEEDS CHECK amber and NOT FOUND red.

**Prediction check:** 5 of the 8 questions come back OK.

Notes:
- If your Claude gave Q1 as NEEDS CHECK and named September, **that counts as a pass**, because it
  found the problem. Strictly, though, rule 3 says a missing document plus a conflicting file is
  NOT FOUND. The renewable share has no document at all, so the weakest part is NOT FOUND.
- Claude may also say that the original glass supplier declaration isn't in the folder, only the
  CSV that names it. That's true and a good catch, so keep the original ready in case Nordvik asks.
  Q6 stays OK.
- Claude may say that Smederevka has no row in `packaging_bottles.csv` (`company_profile.md`,
  line 6). That's also true. If Smederevka is planned under NOK 250 in Norway, its weight is
  NOT FOUND.
- Claude may give the missing bill a number, EL-25-09, guessed from the other invoice numbers.
  That's fine if it says it's a guess, because no file names it until Step 5.

*Stop here until you've run Step 2. The Step 2 answers are further down.*














































---

## Step 2: the marketing claims

| # | Claim | Colour | Why | Safe rewrite |
|---|---|---|---|---|
| 1 | "Climate-neutral wine" | RED | It's based only on carbon offsets we bought, and the offsets invoice even says "use for climate-neutral label". Climate claims based on offsets are on the EU blacklist (item 2). There's no greenhouse gas inventory either. | Drop it. |
| 2 | "Eco-friendly winery" | RED | It's a generic claim, and the winery has no recognised excellent environmental performance, such as the EU Ecolabel (blacklist item 1). | Drop it. Use a specific, proven fact instead, such as claim 7. |
| 3 | "Certified organic vineyards" (shelf card, all wines) | RED | The certificate expired on 31.08.2026. It only covered 12 of 40 ha, and not the cellar or the winemaking, but the card goes on all wines. So the claim is true for one part only (blacklist item 4). | Drop it. After the renewal, you can use this on the website only: "12 of our 40 ha of vineyards are certified organic (control body XX-BIO-000, certificate valid until [date on the new certificate])." Never put it on wine labels or shelf cards. The cellar and the winemaking aren't certified, so the wine itself isn't organic. |
| 4 | "Solar-powered winery" | RED | All electricity comes from the grid. There are no solar panels yet, and the offer isn't signed. The claim is false today, so our files contradict it (RED). After installation, solar would cover only part of the electricity, so a whole-winery claim would still break blacklist item 4. | Drop it. Once the panels are running, use measured numbers only. |
| 5 | "We cut our electricity use by 12% in 2025" | AMBER | It may be true, but there are no 2024 bills to compare with, and the 2025 bills aren't complete. No file contradicts it, so it's AMBER and not RED. | Drop it until the 2024 bills and the missing 2025 bill are in the folder. |
| 6 | "This bottle weighs only 395 g and is made with 60% recycled glass" (Vranec Tikveš 2024 only) | GREEN | The claim is specific and measured. It names its source (glass supplier declaration, Feb 2026), and it only goes on the bottle it's true for. **Also accepted:** AMBER, if the reason is the word "only". | Best: "The glass of this bottle weighs 395 g and contains 60% recycled glass (glass supplier declaration, Feb 2026)." This version drops "only", because it's a comparison that no file proves. It also says "glass", because a full bottle weighs much more. |
| 7 | "In 2025 our whole winery used 4,630 m3 of water, measured on 12 monthly bills" | GREEN | 12 of 12 bills add up to 4,630 m3. There's no other water source, and the vineyard spray water is on the same bills, so "whole winery" is true. | Keep it. You can add the source if you like: "(12 municipal water bills, January to December 2025)". |

**Total: 4 RED, 1 AMBER, 2 GREEN.**

**Prediction check:** compare your colours with the table.

Sources: `eu_green_claims_rules.md` (blacklist lines 15-21, future claims lines 23-26, safe pattern
lines 28-29, legend lines 35-38), `carbon_offsets_2025.txt` 5-7, `organic_certificate_vineyard.txt`
6-11, `company_profile.md` 8, 13 and 17, `solar_offer_2026.txt` 3, 8 and 11, `energy_bills_2025.csv`
3-13, `packaging_bottles.csv` 3, `water_bills_2025.csv` 3-14, `inbox/2-marketing-claims.md` 8-14.

Notes:
- Claude may write NOT FOUND or NEEDS CHECK inside a reason. That's fine, because only the colour
  column counts.
- Claude may not name a blacklist item for claim 4. That's fine too, because "false today" alone
  makes it RED.
- A future claim such as "we will run on solar" is not on the blacklist, but it is misleading
  unless a detailed, realistic plan with targets backs it, regularly checked by an independent
  expert (`eu_green_claims_rules.md`, lines 23-26). The winery has no such plan.
- For claim 3, "Drop it for now" plus a wording for after the renewal is also fine, as long as it
  waits for the new certificate, names only the 12 ha and keeps it off labels and shelf cards.
- Bonus question: can claim 6 go on the Reserve bottle too? No. The Reserve bottle is 560 g, with
  20% recycled glass.

*Stop here until you've run Step 3. The Step 3 answers are further down.*














































---

## Step 3: the bank form

| Field | Status | Answer and why | Where (file, lines) |
|---|---|---|---|
| F1 Fines 2023-2025 | OK | None. The director's declaration of 15 January 2026 covers environmental, labour and health-and-safety fines. | `policies_and_compliance.txt` 13-14 |
| F2 Electricity 2025 | NOT FOUND | 279.7 MWh covers 11 months only. The September 2025 bill is missing, and the draft note's "full year" conflicts with the bills. It's the same gap as Q1 on Monday. | `energy_bills_2025.csv` 3-13; `energy_summary_2025_draft.txt` 5 |
| F3 PV output and share | NOT FOUND | The output, about 180 MWh a year, is the installer's estimate from an unsigned offer. That part is fine if it's marked as an estimate. But the share of consumption needs a full year, and September is missing. 180 ÷ 279.7 = 64.4% is a share of 11 months only, so it's too high. F3 depends on F2, and F2 is NOT FOUND, so the weakest part sets the status. | `solar_offer_2026.txt` 3, 8, 11; `energy_bills_2025.csv` 3-13 |
| F4 Payback | NEEDS CHECK | 5.0 years = 8,550,000 ÷ (180,000 × 9.50), calculated in code with the form's formula. It's NEEDS CHECK because it's based on an estimate (180 MWh) from an unsigned offer. The offer is valid for 60 days from 2 September 2026, so until about 1 November 2026. | `solar_offer_2026.txt` 3, 6, 8-9; `company_profile.md` 15; `inbox/3-bank-form.md` 13-14 |
| F5 Headcount and accidents | OK | 42 employees on average. 2 recordable accidents among employees, 0 fatalities. | `hr_headcount_2025.csv` 5; `health_safety_2025.txt` 4-7 |
| F6 Certificates and audits | NEEDS CHECK | The organic certificate (12 of 40 ha) expired on 31.08.2026, and the renewal inspection is on 22.10.2026. amfori BSCI had an audit on 12 March 2026 with rating B, and the next full audit is in March 2028. It's an audit, so it doesn't count as a certificate. | `organic_certificate_vineyard.txt` 6, 8-9; `policies_and_compliance.txt` 8-9 |

**Total: 2 OK, 2 NEEDS CHECK, 2 NOT FOUND.** The estimates to mark are the 180 MWh in F3, and
therefore F4.

**Prediction check:** F4 = 8,550,000 MKD ÷ (180,000 kWh × 9.50 MKD/kWh) = 8,550,000 ÷ 1,710,000 =
**5.0 years**. If your phone showed 5, you got the same result as Claude's code.

Notes:
- If your Claude gave F2 as NEEDS CHECK and named September, or F3 as NEEDS CHECK with "64.4% of
  11 months", **that counts as a pass**, because it found the problem. Strictly, though, rule 3
  says a missing document plus a conflicting file is NOT FOUND, and the weakest part sets the
  status. F3 has no full year behind it, so it's NOT FOUND too.
- Claude may put the offer's expiry date in a list under the table instead of in the F4 row.
  That's fine.

*Stop here until you've run Step 4. The Step 4 answers are further down.*














































---

## Step 4: the ESG Passport

| Heading | Status | What we have, and what is missing | Where (file, lines) |
|---|---|---|---|
| B1 Basis for preparation | OK | Legal form (DOO), NACE 11.02, balance sheet total 162.0 million MKD, turnover 95.0 million MKD, 42 employees, North Macedonia, sites with rounded locations, and the organic certificate (valid from 1 September 2025, so valid at the end of the reporting year). You choose and state the module (Basic) and the type of report (one company) yourself, so no file line is needed. | `company_profile.md` 1, 4-11; `organic_certificate_vineyard.txt` 3-11 |
| B2 Policies and future initiatives | OK | Environmental policy (March 2024: energy, water, waste and packaging; internal only; no targets yet), anti-corruption policy (January 2025, internal only), and planned rooftop solar (offer not signed). "Not published" and "no targets" are valid answers and don't count as gaps, because B2 accepts "No" as an answer. The amfori BSCI Code of Conduct was signed on 3 February 2026, after the reporting year, so it belongs in the open points as a change since 2025. **Also accepted:** PARTIAL, if the reason names a data point that no file answers. | `policies_and_compliance.txt` 4-7; `company_profile.md` 18; `solar_offer_2026.txt` 3, 11; `vsme_basic_headings.md` 11 |
| B3 Energy and greenhouse gas | PARTIAL | Have: electricity, 279.7 MWh for 11 months. Missing: the September 2025 bill, diesel use (fuel receipts), Scope 1 and Scope 2 in tCO2e (no inventory, no grid emission factor), and the renewable share (supply mix "not specified"). | `energy_bills_2025.csv` 3-13; `company_profile.md` 13-14, 17 |
| B4 Pollution | NOT FOUND | No file shows whether the law makes us report pollutant emissions. The document that would close it is the environmental permit, or a written check of our reporting duties. If there's no such duty, B4 doesn't apply, but no file says so yet. | (no file) |
| B5 Biodiversity | NOT FOUND | Nobody has checked our site locations against a map of protected and key biodiversity areas. The document that would close it is a dated map check. A real-world note for you, which isn't from our files (so Claude shouldn't say it): this check matters here, because the Tikveš area has a strict nature reserve and a key area for birds around Lake Tikveš. | `company_profile.md` 5 (locations only) |
| B6 Water | OK | 4,630 m3 withdrawn, from 12 of 12 municipal bills. | `water_bills_2025.csv` 3-14 |
| B7 Resources and waste | PARTIAL | Have: glass weight and recycled share for the three bottles in `packaging_bottles.csv` (Smederevka has no row). Missing: total waste, hazardous and not (grape pomace, the skins and seeds left after pressing, is the big one), the share sent to recycling, and a statement on circular practices. **Also accepted:** recycled glass counted as a circular practice. | `packaging_bottles.csv` 3-5 |
| B8 Workforce | OK | 42 employees by contract type and gender, all in one country. | `hr_headcount_2025.csv` 3-5 |
| B9 Health and safety | PARTIAL | Have: 2 recordable accidents among employees, 0 fatalities. Missing: the accident rate, which needs the hours worked by employees. | `health_safety_2025.txt` 4-7 |
| B10 Pay, collective bargaining, training | PARTIAL | Have: 7.4 training hours per employee (310 h ÷ 42). Missing: a statement that pay is at or above the minimum wage, and the share of employees covered by collective agreements. The gender pay gap is asked for only where the law already requires it (`vsme_basic_headings.md` line 19). No file says whether the law requires it here. Claude may write "no file says" or list a check of the legal duty as an open point. Both are fine, and neither changes the status. | `hr_headcount_2025.csv` 7-8; `vsme_basic_headings.md` 19 |
| B11 Corruption and bribery | OK | No convictions or fines (director's declaration, 15 January 2026). | `policies_and_compliance.txt` 13-14 |

**Total: 5 OK (B1, B2, B6, B8, B11), 4 PARTIAL (B3, B7, B9, B10), 2 NOT FOUND (B4, B5).**

**Prediction check:** a gap. The chart must show September as a visible gap ("no bill"), never as
an average, a zero bar or an error.

The dashboard should also show:
- September as a visible gap, never as an average. If there's no bill, there should be no bar. A
  hatched slot labelled "missing" or "no invoice" counts as a gap too.
- Seven claim lights: 4 red, 1 amber and 2 green.
- The Reserve bottle as an action and not as NEEDS CHECK, because the data is proven and the rule is
  broken.
- The expired organic certificate in the open points. It was valid at the end of 2025 (from
  1 September 2025), so it doesn't pull B1 down.
- Every open point with the document that would close it. The number of open points varies from
  run to run (between 15 and 22 in the October test runs), so check that each one names a document.

Notes:
- Claude may also answer the questionnaire and the bank form again inside the passport. That's fine.
- If your Claude gave B3 as NOT FOUND and named September, **that counts as a pass** until the
  September bill arrives. Strictly, though, the prompt says NOT FOUND only "when we have nothing",
  and 11 bills are proven data, so the status is PARTIAL.

*Stop here until you've run Step 5. The Step 5 answers are further down.*














































---

## Step 5: the September invoice

The photo shows invoice EL-25-09 for 1 to 30 September 2025: 41,200 kWh at 9.50 MKD/kWh, which
comes to 391,400 MKD. The photo writes "41.200", where the dot separates thousands. The meter
readings agree: 1,325,550 − 1,284,350 = 41,200 kWh. The supply mix is again "not specified".

| Where | Before | Now | Why |
|---|---|---|---|
| Q1 Nordvik, electricity | 279.7 MWh (11 months), NOT FOUND | 320.9 MWh, still NOT FOUND | There are 12 of 12 months now, but still no renewable share, because the new bill also says "not specified". |
| Q2 Nordvik, Scope 1 and 2 | NOT FOUND | Still NOT FOUND | Scope 2 now has a full year of kWh, but there's still no grid emission factor, and no diesel receipts for Scope 1. |
| F2 Bank, electricity | 279.7 MWh (11 months), NOT FOUND | 320.9 MWh, OK | 12 bills prove the full year. The draft note is now proven wrong, so it's an error to correct and doesn't count as a second valid file. **Also accepted:** NEEDS CHECK, if the reason is the wrong draft note. |
| F3 Bank, PV share | NOT FOUND (64.4% of 11 months only) | 56.1%, NEEDS CHECK | 180 ÷ 320.9 = 56.1%. The share can be calculated now, but 180 MWh is still an estimate. |
| B3 Passport, energy | PARTIAL | PARTIAL | Electricity is complete now. Fuels, greenhouse gas and the renewable share are still missing. |
| F4 Bank, payback | 5.0 years, NEEDS CHECK | 5.0 years, unchanged | The bank's formula uses the solar output and the price. Our consumption isn't part of it. |
| Claim 5, "cut by 12%" | AMBER | AMBER | There are still no 2024 bills. |
| Draft energy summary | "full year: 279.7 MWh" | Wrong | The draft note was 41.2 MWh short. Correct it, and don't send it. |
| 11-month average × 12 | 305.1 MWh | 15.8 MWh too low | September (41.2 MWh) is the peak month for tank cooling, and an average hides that peak. |

**Statuses that change:** F2 and F3. The others stay the same, and Claude should say why. In the
dashboard, September now has its bar.

**Prediction check:** higher. The real year is **320.9 MWh**. The 11-month average × 12 gives
**305.1 MWh**, which is 15.8 MWh too low, because September (41.2 MWh) is the peak month.

Notes:
- The last two rows (the draft and the average) may come as text above or below the table instead
  of as table rows. That's fine, because the prompt asks for one row per question or form field.
- Claude may leave out Q2 or claim 4 (still RED) because nothing changes for them. That's fine too.

---

## Why Claude's answer may differ

> - Numbers that Claude calculates in code should be stable. 279.7, 320.9, 305.1 and 15.8 MWh,
>   64.4% and 56.1%, 5.0 years and 4,630 m3 should match exactly. If a number differs, ask Claude
>   to calculate it again in code and to show the code.
> - Judgement calls can vary. On a borderline question, one run may say NEEDS CHECK where another
>   says NOT FOUND. The wording, column order and length vary too.
> - If you're not sure, re-read rule 3 in `project-instructions.md` and the status box in
>   `START-HERE.md`, then decide for yourself.
> - Claude does the preparation, but a person checks and signs every answer before it leaves the
>   company.
> - If you caught Claude breaking one of the three rules, well done. That's exactly the check a
>   person has to make.

Your score: trap hunt ___ of 15 (bonus ___). Predictions right: ___ of 5.
