# Answers: Crvena Zemja
Fictional training data. Claude words things differently from us: compare statuses and numbers.
Count lines as in a text editor. In longer files Claude is sometimes one line off;
check that the line says what Claude claims.

## Review
| # | Defect | File, line | Check |
|---|---|---|---|
| 1 | September 2025 is missing: October follows August. | electricity_2025.csv 10, 11 | Period |
| 2 | EL-25-10 booked twice (e-invoice and scan). 12 rows are 11 months. | electricity_2025.csv 11, 12 | Period |
| 3 | The draft calls 11 months "full year" and releases them for the bank. | electricity_summary_draft.txt 5 | Approval |
| 4 | Organic certificate expired on 31.08.2026, 46 days before the reference date. | organic_certificate_vineyard.txt 8 | Period |
| 5 | It covers 12 of 40 ha, not the cellar and winemaking. | organic_certificate_vineyard.txt 6, 10, 11 | Scope |
| 6 | Offsets with the note "for carbon neutral label". | carbon_offsets_2025.txt 7 | Ban list 4c |
| 7 | Offer not signed; 180 MWh is the installer's estimate. | solar_offer_2026.txt 3, 8, 11 | Approval |
| 8 | Reserve 560 g at 239 NOK; limit 420 g below 250 NOK. | bottles.csv 5 | covered, rule broken |
Clean file: water_2025.csv, 12 of 12 bills, 4,630 m³. September (980 m³) is the harvest.
Also right: no invoices for 2024; supply mix "not specified"; no GHG inventory, no
diesel receipts; no hours worked for an accident rate; amfori BSCI is an audit, not a certificate;
seasonal workers are not employees.

*Stop. Continue only after step 1.*








































## Step 1: Questionnaire
| Q | Status | Why | File, line |
|---|---|---|---|
| Q1 | GAP | 11 of 12 months (91.7 %, rule 95 %), 279.7 MWh. EL-25-10 twice, counts once; adding all rows gives 318.4 MWh. The draft calls it "full year": contradiction. Supply mix "not specified" everywhere. Missing: invoice September 2025, supply mix evidence from the supplier. | electricity_2025.csv 3 to 14; draft 5; questionnaire 12 |
| Q2 | GAP | No GHG inventory, no diesel receipts, no grid emission factor. 120 t of offsets are not own emissions. Missing: diesel receipts 2025, invoice September 2025, published grid emission factor for North Macedonia. | company_profile 14, 17; carbon_offsets 5; vsme_basic_module 12 |
| Q3 | COVERED | 42: 36 permanent (20 M, 16 F), 6 fixed-term (4 M, 2 F). Seasonal workers are not employees. | headcount 3 to 6 |
| Q4 | COVERED | 2 recordable accidents, 0 fatal. | health_safety 4 to 7 |
| Q5 | COVERED | None; director's declaration of 15.01.2026. | policies 13, 14 |
| Q6 | COVERED | Vranec 395 g and Kratošija 410 g pass; Reserve 560 g at 239 NOK is 140 g over 420 g. Action: bottle up to 420 g, price from 250 NOK or do not offer the Reserve. | bottles 3 to 5; questionnaire 21 |
| Q7 | WEAK | Organic certificate expired on the submission day; renewal inspection on 22.10. amfori BSCI: audit 12.03.2026, rating B, not a certificate. The weakest part counts. | organic 6 to 9; policies 8, 9; questionnaire 7, 11 |
| Q8 | COVERED | 4,630 m³ from 12 of 12 bills, spraying water included. | water 3 to 14; company_profile 8 |
Total: 5 COVERED, 1 WEAK, 2 GAP. Also defensible: Q1 as WEAK if September is named.

*Stop. Continue only after step 2.*








































## Step 2: Marketing claims
| # | Ban list | Status | Send | Reason | Safe wording |
|---|---|---|---|---|---|
| 1 | 4c | GAP | no | offsets, no GHG inventory (carbon_offsets 7, company_profile 17) | Drop. |
| 2 | 4a | GAP | no | generic, no recognised excellent environmental performance (green_claims_rules 12, 13) | Drop. Claim 7 says something specific. |
| 3 | 4b | GAP | no | expired; 12 of 40 ha; not the cellar; card on all wines (organic 6, 8, 10, 11) | After renewal, website only: "12 of our 40 ha of vineyards are certified organic (control body XX-BIO-000, valid until [date])." |
| 4 | none | GAP | no | all electricity from the grid (company_profile 13); offer not signed (solar_offer 3, 11) | Drop. After commissioning, measured values only. |
| 5 | none | GAP | no | no invoices for 2024; 2025 incomplete (electricity_2025.csv 3 to 14) | Drop until both years are covered. |
| 6 | none | COVERED | yes, reworded | supplier declaration Feb 2026 (bottles 3); "only" is a comparison without evidence | "The glass of this bottle weighs 395 g and contains 60 % recycled glass (glass supplier declaration, Feb 2026)." |
| 7 | none | COVERED | yes | 12 of 12 bills, no other source (water 3 to 14, company_profile 8) | as sent |
Total: 2 may be sent, 3 ban list, 2 without evidence.

*Stop. Continue only after step 3.*








































## Step 3: Bank form
| Field | Status | Answer and reason |
|---|---|---|
| F1 | COVERED | No fines 2023 to 2025 (policies 13, 14). |
| F2 | GAP | 279.7 MWh are 11 months (electricity_2025.csv 3 to 14; draft 5). Missing: invoice September 2025. The same gap as Q1. |
| F3 | GAP | 180 MWh is an estimate (solar_offer 8). The share needs a full year; 64.4 % rests on 11 months (electricity_2025.csv 3 to 14). |
| F4 | WEAK | 5.0 years = 8,550,000 / (180,000 × 9.50), in code. Estimate from an unsigned offer (solar_offer 6, 8, 9, 11). |
| F5 | COVERED | 42 employees, 2 accidents, 0 fatal (headcount 3 to 6; health_safety 4 to 7). |
| F6 | WEAK | as Q7 (organic 6 to 9; policies 8, 9). |
Total: 2 COVERED, 2 WEAK, 2 GAP.

*Stop. Continue only after step 4.*








































## Step 4: Evidence register
Register: 21 rows, 9 COVERED, 3 WEAK, 9 GAP.
| Disclosure | Status | Covered | Missing document |
|---|---|---|---|
| B1 | GAP | 8 of 10 | Choice of module and standalone or consolidated report; no file records either |
| B2 | COVERED | 4 of 4 | ("not published", "no targets" are valid answers) |
| B3 | GAP | 0 of 4 | invoice September 2025, diesel receipts, grid emission factor |
| B4 | GAP | 0 of 1 | environmental permit or a written check of the reporting duty |
| B5 | GAP | 0 of 1 | dated map check of the sites against protected areas |
| B6 | COVERED | 1 of 1 | |
| B7 | GAP | 1 of 4 | total waste, hazardous, share recovered |
| B8 | COVERED | 2 of 2 | |
| B9 | GAP | 2 of 3 | hours worked 2025 (for the accident rate) |
| B10 | GAP | 1 of 3 | minimum wage declaration, collective agreement coverage |
| B11 | COVERED | 1 of 1 | |
Total: 4 COVERED, 7 GAP. Also defensible: B3 as WEAK with a note on September; under rule 3 a
missing datapoint is GAP.
Request list, top: invoice September 2025 (Q1, Q2, C5, F2, F3, B3).

*Stop. Continue only after step 5.*








































## Step 5: The late invoice
EL-25-09: 41,200 kWh (meter readings 1,325,550 minus 1,284,350), 9.50 MKD/kWh, 391,400 MKD, supply mix "not specified".
| Where | Before | Now | Why |
|---|---|---|---|
| F2 | 279.7 MWh, GAP | 320.9 MWh, COVERED | 12 of 12 months. The draft is disproved. |
| F3 | GAP | 56.1 %, WEAK | The share can now be calculated; 180 MWh stays an estimate. |
| Q1 | GAP | 320.9 MWh, GAP | The supply mix is still missing. |
| Q2 | GAP | GAP | Emission factor and diesel receipts are still missing. |
| C5 | no | no | Invoices for 2024 are still missing. |
| F4 | 5.0 years, WEAK | unchanged | The formula uses yield and tariff, not consumption. |
| B3 | 0 of 4, GAP | 1 of 4, GAP | Electricity covered; fuels and Scope 1 and 2 missing. |
| Draft | "full year 279.7" | wrong | 41.2 MWh too low. Correct it, do not send it. |
| 11 months × 12/11 | 305.1 MWh | 15.8 MWh too low | September is the tank cooling month (company_profile 16). |
| All rows added | 318.4 MWh | 2.5 MWh too low | close, for the wrong reason. |
Two statuses change: F2 and F3. Register after: 10 COVERED, 4 WEAK, 7 GAP.

## Why Claude's answer can differ
Numbers calculated in code must match exactly: 279.7, 318.4, 320.9, 305.1, 15.8 and 41.2 MWh,
64.4 % and 56.1 %, 5.0 years, 4,630 m³. If one differs, ask Claude to recalculate in code and show
the code. In borderline cases one run says WEAK where another says GAP; decide with `evidence-check.md`.
