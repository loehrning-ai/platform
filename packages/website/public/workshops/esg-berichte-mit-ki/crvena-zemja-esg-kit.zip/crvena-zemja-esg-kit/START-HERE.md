# Evidence check: ESG answers from one folder

Fictional training data. Every company, person and document is invented. Only the laws,
standards and rules quoted are real.

**Learning objective:** Every answer that leaves the company carries its evidence: an approved file and line
that covers the period and scope of the answer, or the name of the document that is missing.

## The case
Vinarija Crvena Zemja DOO, a family winery in Kavadarci, North Macedonia: 42 employees,
40 ha of vineyards, about 550,000 bottles a year, 74 % exports, 31 % of revenue from Germany.
Reference date of the exercise: 16.10.2026. Keep it, even if you work later; the answers
depend on it.

Why this case: the three requests follow two real rules and one real loan. Since 27.09.2026 German
law bans claims such as "climate neutral" that rest on offsetting (Directive (EU) 2024/825, in
Germany through the UWG). Since 01.01.2026 Vinmonopolet in Norway dismisses still wine under NOK 250
in bottles over 420 g. In December 2025 the EBRD lent EUR 8 million to a bank in Skopje for green
SME loans for solar and energy efficiency. The winery, the importer and the bank are invented.

| Request | From | What is asked |
|---|---|---|
| `requests/1-nordvik-questionnaire.md` | Nordvik Vin AB, wine importer in Sweden | 8 questions based on the VSME Basic Module. Answers without evidence are not counted; energy data must cover 95 % of the year |
| `requests/2-marketing-claims.md` | the company's own marketing | 7 environmental claims for labels and shelf cards in Germany and for the website |
| `requests/3-bank-form.md` | Banka Povardarie | 6 fields for a loan for a PV system |

## What is in the kit
| File or folder | Content |
|---|---|
| `evidence-check.md` | the check on one page. Read it first, print it and keep it next to the screen |
| `project-instructions.md` | reference date and three rules for Claude |
| `files/` | 13 files of the winery, as messy as a real filing system |
| `requests/` | the three requests |
| `late-document/` | an invoice for step 5. Do not open it before |
| `answers/ANSWERS.md` | answers with file and line. Open only after the matching step |
| `take-home/` | skill, templates and checklist for your own company |

The same files as an interactive demo: loehrning.ai/en/demos/esg-berichte-mit-ki

## What you need
- Claude on claude.ai or in the desktop app, with code execution turned on (section
  "Set up Claude" below).
- A text editor with line numbers. Do not open the .csv files in Excel; Excel changes dates
  and decimal marks. The .csv files are accounting exports: point as decimal mark, months as 2025-01.
- Paper and pen for the predictions.
- About 90 minutes on the first run. In the workshop: steps 0 to 3 live, 4 and 5 as a demo. You can stop after any step; the chats stay in the project.
- No code, no ESG background.

## Step 0: Review without Claude (10 minutes)
Read `evidence-check.md`, then the 13 files in `files/` and the three requests.
The files contain 8 defects. One file looks odd and is fine.
For each defect, write: file, line, what is wrong, and which check fails
(period, scope, approval or ban list). Write down the clean file too.
Compare with `answers/ANSWERS.md`, section "Review".

## Create the project (once, 10 minutes)
1. Unzip the kit.
2. Create a new project "Crvena Zemja Evidence" (steps under "Set up Claude", Project instructions).
3. Paste the whole text of `project-instructions.md` as project instructions and save.
4. Add the 13 files from `files/` to the project. Not the requests: they ask, they prove
   nothing. You attach them to the message in each step.
5. If a .md file does not upload, rename it to .txt.
6. Without projects: in each new chat attach the 13 files and the request and put the text of
   `project-instructions.md` before the prompt.
Steps 1 to 4 each start a new chat in the project. Step 5 runs in the chat of step 4.
Before real company data: check the privacy settings and clarify whether company files may go into Claude.

## Step 1: The importer's questionnaire
Prediction on paper: how many of the 8 questions will be COVERED?
New chat, attach `requests/1-nordvik-questionnaire.md`:
```
Answer the attached questionnaire from Nordvik Vin AB.
One table, exactly one row per question Q1 to Q8: No | Question | Answer | File and line | Status | Reason | Missing document.
Before any annual total, count the distinct months in code.
```
Open the code box: how many rows does the electricity file have, and how many months?
Check: `ANSWERS.md`, Step 1.

## Step 2: Marketing claims
Prediction: which of the 7 claims may be sent?
New chat, attach `requests/2-marketing-claims.md`:
```
Check the seven claims in the attached file: first against the ban list in green_claims_rules.md, then with the evidence check.
One table: No | Claim | Ban list (number or none) | Status | Reason with file and line | Send (yes/no) | Safe wording.
```
Check: `ANSWERS.md`, Step 2.

## Step 3: The bank's form
Prediction: work out F4 with a calculator. The formula is in the form, the numbers are in the files.
New chat, attach `requests/3-bank-form.md`:
```
Complete the attached form.
One table: Field | Answer | File and line | Status | Reason | Missing document.
Calculate F4 in code with the formula from the form. Mark every estimate.
```
Which gap from step 1 comes back? Check: `ANSWERS.md`, Step 3.

## Step 4: Evidence register
The three requests often ask for the same facts. The register keeps them in one place.
Prediction: how many of the 21 answers are COVERED?
New chat, attach all three requests:
```
The three attached files are our open requests. Create evidence_register.xlsx with three sheets:
1. Register: one row per question, claim and field. Columns: Request | No | Answer | File and line | Status | Reason | Missing document | Action | Checked by | Date. Leave the last two empty.
2. VSME: B1 to B11 from vsme_basic_module.md, per disclosure the datapoints with status, covered x of y, status of the disclosure by its weakest datapoint.
3. Request: every missing document once, with all rows that name it, sorted by count.
```
Check: `ANSWERS.md`, Step 4.

## Step 5: The late invoice
Accounting finds the electricity invoice for September 2025, as a photo. The reference date stays.
Prediction: how many statuses in the register change?
Stay in the chat of step 4, attach `late-document/invoice-EL-25-09.png`:
```
Attached is the electricity invoice for September 2025. Read it first and check the kWh against the two meter readings.
Then check again every row in the register that cites electricity_2025.csv. One table: Where | Before (value, status) | Now (value, status) | Why. Also for rows that stay the same.
Say what the invoice means for electricity_summary_draft.txt and how far 11 months × 12/11 is from the full year.
Update evidence_register.xlsx.
```
Check: `ANSWERS.md`, Step 5.

## For your company
The skill sits in `claude/`, everything else in `take-home/`:
- `claude/esg-nachweise/SKILL.md`: the skill for your Claude, one skill for German and English.
  As a ZIP to upload: loehrning.ai/skills/esg-nachweise.zip. Installation below.
  The project instructions also work without the skill.
- `project-instructions-template.md`: for your own project. Fill the brackets, change the reference date in every working session.
- `folder-checklist.md`: which documents belong in your folder and what you check on each.
- `evidence-register-template.csv`: the register as a comma-separated file in UTF-8.
- `email-missing-document.md`: one email for every GAP.
Never mix real files with these training files. A person checks and signs every answer.

## Set up Claude

### claude.ai and the desktop app

1. In “Settings”, “Capabilities”, turn on “Code execution and file creation” (“Create and edit files” in the new layout).
2. Open claude.ai/customize/skills.
3. Choose “+”, then “Create skill”, then “Upload a skill”, and pick the zip file.
4. Turn the skill on.

On Team and Enterprise an admin can turn user skills off.

### Claude Code

For all projects: `unzip esg-nachweise.zip -d ~/.claude/skills/`

For this repository only: `unzip esg-nachweise.zip -d .claude/skills/`

SKILL.md then sits in skills/esg-nachweise/ (global or in the repository). Type /esg-nachweise or just ask.

With the same claude.ai login, Claude Code (v2.1.273 or later) loads the skills you turned on in claude.ai by itself; do not unzip them there a second time. With an API key or Bedrock: unzip.

### Project instructions

1. Open claude.ai/projects and choose “New Project”.
2. On the right, open “Set project instructions”, paste the text, choose “Save instructions”.
3. Add the kit files to the project knowledge with “+”.

Projects work on every plan, up to five on Free.
