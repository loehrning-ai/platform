# Answer ESG by Friday: the Crvena Zemja kit

Fictional training data. Every company, person and document is invented. Only the laws, standards
and rules quoted in the files are real.

Vinarija Crvena Zemja is a family winery in Kavadarci municipality, North Macedonia, in the Tikveš wine region:
42 employees, 40 ha of vineyards, about 550,000 bottles a year, 74% of revenue from exports. This
week three ESG requests arrive:

- **Monday:** Nordvik Vin AB, the Swedish importer, sends a supplier questionnaire.
- **Wednesday:** marketing wants seven green claims for the autumn launch in Germany and Poland.
- **Friday:** the bank sends a screening form for a solar loan.

You answer all three with Claude from one set of files, build an ESG Passport once, and then a late
invoice arrives. The rule all week: claim nothing the files cannot prove.

**You need:** claude.ai or the Claude desktop app, any plan, with *Code execution and file
creation* switched on in Settings. No code, no API key. About 45 minutes.

| In this kit | What it is |
|---|---|
| `project-instructions.md` | The date and three rules for Claude |
| `project-files/` | The winery's files (13 small files). A little messy, like real ones. |
| `inbox/` | This week's requests, attached one at a time, plus a late invoice (a photo) |

---

## Setup (once)

1. In Claude, create a **Project** called `Crvena Zemja ESG`.
2. Paste the text of `project-instructions.md` into the Project instructions. The first line sets
   today's date. The expected results below assume 16 October 2026. With your own files, change it
   to your date.
3. Add all 13 files from `project-files/` to the Project. Do not add the inbox files.
4. Before you ever upload real company files, check the model-training setting under
   Settings > Privacy.

## Step 1 · Monday: the customer questionnaire

New chat in the Project. Attach `inbox/1-nordvik-questionnaire.md`, then send:

```
Answer the Nordvik Vin AB questionnaire in the attached file.
Return one table with exactly one row per question, Q1 to Q8: # | Question | Answer | Source file and row | Status (OK, NEEDS CHECK or NOT FOUND).
Before any energy total, count the months in code.
Also save the table as nordvik-answers.xlsx, with the Status cells filled green, amber or red.
Then write a 3-line summary.
```

## Step 2 · Wednesday: the marketing claims

New chat in the Project. Attach `inbox/2-marketing-claims.md`, then send:

```
Check the seven claims in the attached file against our files and eu_green_claims_rules.md.
Return a table: Claim | RED, AMBER or GREEN | Reason | Source file | Safe rewrite.
Put the red ones first.
```

## Step 3 · Friday: the bank form

New chat in the Project. Attach `inbox/3-bank-form.md`, then send:

```
Fill in Banka Povardarie's form in the attached file, in Macedonian (Cyrillic).
Calculate F4 in code with the formula printed on the form. Mark every estimate.
Keep the status tags OK, NOT FOUND and NEEDS CHECK in English; write everything else, column heads included, in Macedonian.
```

The bank is Macedonian, so the answers go in Macedonian, written in Cyrillic, the official language of North Macedonia.

## Step 4 · Build the ESG Passport

New chat in the Project. Attach the three inbox files `1`, `2` and `3` again, then send:

```
The three attached files are this week's requests.
Build our ESG Passport: one row per VSME Basic heading B1 to B11 from vsme_basic_headings.md, with what we have, the source file, the status (OK; PARTIAL when some of the heading's data points are proven and others are missing, naming the missing ones; NOT FOUND when we have nothing), and which questions in the attached files it answers.
Deliver it two ways:
1. An interactive one-page dashboard as an artifact: status tiles B1 to B11 that open what we have and the source when clicked, a 12-month electricity bar chart in MWh that shows the missing month, a red, amber or green light for each of the seven claims, and the open points: every NOT FOUND, NEEDS CHECK and partial gap, each with the document that would close it. List a proven fail (data documented, rule broken) as an action, not as NEEDS CHECK. One self-contained file, no external data.
2. esg-passport.docx, ready to send.
```

## Step 5 · The September invoice arrives

Same chat as step 4. Attach `inbox/4-september-invoice.png`, then send:

```
I attached the September 2025 electricity invoice. Read it first.
Then recheck every answer from this week that depends on electricity.
Also say what the invoice means for the draft energy summary and for an 11-month average.
Return a table with one row per question or form field: Where | Before (value and status) | Now (value and status) | Why.
Then update the dashboard and esg-passport.docx.
```

---

## What good looks like

- **Step 1:** 5 OK, 1 NEEDS CHECK, 2 NOT FOUND. Claude counts 11 months of electricity, not 12.
  It gives 279.7 MWh only as "11 months, September missing" and flags the draft note that calls
  it a full year. Water shows 4,630 m3 for 12 of 12 months, with no flag. The 560 g Reserve
  bottle fails Vinmonopolet's 420 g rule. The organic certificate expired on 31.08.2026.
- **Step 2:** 4 RED, 1 AMBER, 2 GREEN. Every rewrite points to a file that proves it.
- **Step 3:** F4 = 8,550,000 MKD / (180,000 kWh x 9.50 MKD/kWh) = 5.0 years, worked out in code.
  The PV share of consumption cannot be final while September is missing.
- **Step 4:** about 5 headings OK, 4 partial, 2 NOT FOUND (B4 pollution, B5 biodiversity). Gaps
  are named, not filled.
- **Step 5:** the year is now 320.9 MWh. Averaging 11 months would have said 305.1 MWh, 15.8 MWh
  too low, because September (41.2 MWh) is the peak month. The PV share drops from 64% to 56%.
  The payback stays 5.0 years. Claim 5 stays AMBER: there are still no 2024 invoices.

## Use it on your own company

Replace the files in `project-files/` with your own, keep `project-instructions.md` with today's
date, and run the same steps on the next questionnaire you receive.
