# Answer ESG by Friday: the Crvena Zemja kit

Fictional training data. Every company, person and document is invented. Only the laws, standards
and rules quoted in the files are real.

Today is Friday 16 October 2026. This week, three ESG requests landed at Vinarija Crvena Zemja, a
family winery in Kavadarci, North Macedonia. You'll answer all of them with Claude, using one folder
of company files.

All week, one rule applies: don't claim anything that the files can't prove.

The winery has 42 employees and 40 ha of vineyards. It makes about 550,000 bottles a year, and 74%
of its sales are abroad. Here's your week:

- **Monday:** Nordvik Vin AB, the Swedish importer, sends a supplier questionnaire.
- **Wednesday:** marketing wants to use seven green claims for the autumn launch in Germany and Poland.
- **Friday:** the bank sends a screening form for a solar loan.
- **Friday afternoon:** you build one ESG Passport from all of it.
- **Next Monday:** there's one more surprise.

---

## What you need

- Claude on claude.ai or in the Claude desktop app. Any plan works, including Free.
- Code execution and file creation must be switched on (Settings > Capabilities). They're on by
  default. If Claude doesn't give you a file card (.xlsx or .docx), send
  `Show it as a table in the chat instead.` Then you can copy the table into Excel or Word.
- A computer, plus paper and a pen for the warm-up and your predictions.
- You don't need to write code, and you don't need an API key or any ESG knowledge.
- Time: about 2 hours the first time, or about 30 minutes once you know Claude. You can stop after
  any step and continue another day, because your chats stay in the Project.

On the Free plan you can only send a limited number of messages within a few hours, and Steps 4 and
5 use the most. It helps to do the warm-up and Steps 1 to 3 on one day, and Steps 4 and 5 on another
day. If you reach the limit, Claude shows the time when you can continue. Step 5 also has a lite
prompt for this.

## What's in this kit

| File or folder | What it is |
|---|---|
| `START-HERE.md` | This guide |
| `ANSWERS.md` | The answer key. Open it only after each step, and don't scroll past a stop line. |
| `project-instructions.md` | The date and the three rules for Claude |
| `project-files/` | The winery's files (13 small files). They're a little messy, like real files. |
| `inbox/` | This week's three requests (files 1, 2 and 3), plus one surprise for Step 5 (file 4) |

---

## Warm-up: the trap hunt (10 minutes, without Claude)

Before Claude reads the files, you read them yourself. Unzip the kit. Open the 13 files in
`project-files/` and the three requests in `inbox/` (files 1, 2 and 3). Keep file 4 closed until
Step 5.

Seven traps are hidden in these files. A trap is anything that would embarrass the winery in front
of the importer, the regulator or the bank. One more file looks suspicious, but it's clean. Can you
tell which one?

1. Set a timer for 10 minutes.
2. Write down each trap: the file, and one line on what's wrong. One file can hold two traps.
3. Write down the file you think is clean.
4. When the timer ends, score yourself with the "Trap hunt" section in `ANSWERS.md`. You get 2
   points per trap, plus 1 for the right clean file, and minus 1 if you flagged the clean file as a
   trap. A trap you found in one of the three requests counts too.

Tips:
- Today is 16 October 2026. Check every date against it.
- Read the three requests too, because they set the rules.
- Open the files in a text editor. On Windows, right-click the file > Open with > Notepad. On a Mac,
  use TextEdit. Don't open the .csv files in Excel, because it can change dates and decimals.
- Claude counts lines the way a text editor does, so every line counts, including the first one.
  Notepad shows the line number at the bottom (Ln 5). TextEdit doesn't show it, so count from the
  top.
- If you don't know a word, look in "Words you will meet" below.

## Words you will meet

| Word | Plain meaning |
|---|---|
| ESG | Environmental, Social, Governance: questions about your impact on nature, your people and how you run the company. |
| VSME | The EU's voluntary sustainability reporting standard for small firms. Its Basic Module has 11 headings, B1 to B11. Many questionnaires copy it. |
| Scope 1 | Greenhouse gas from fuel you burn yourself, for example diesel in tractors. |
| Scope 2 | Greenhouse gas from the electricity you buy: kWh × a published emission factor for the country's power grid. |
| tCO2e | Tonnes of CO2 equivalent, the unit for all greenhouse gases together. |
| GHG inventory | A count of all your greenhouse gas emissions (GHG) for one year. |
| MWh / kWh | Units of electricity. 1 MWh = 1,000 kWh. |
| NACE | The EU code for a type of business. Making wine is 11.02. |
| PV / kWp | PV means solar panels. kWp is their peak power. |
| Payback | The number of years until the savings pay back the investment: price ÷ savings per year. |
| amfori BSCI | A social audit programme for supply chains. You get an audit with a rating, so it doesn't count as a certificate. |
| Carbon offset | A credit you buy to balance emissions somewhere else. It doesn't cut your own emissions. |
| Coverage | How much of the year your bills cover. For example, 6 of 12 months = 50%. |
| Delisted | The shop takes the product off its list and stops selling it. |
| Recordable work accident | An accident at work that causes death or more than 3 days off work. |
| Tender | A competition where suppliers offer products and the buyer picks one. |
| MKD, NOK | Macedonian denar, Norwegian krone. |
| Systembolaget, Vinmonopolet | The state-owned alcohol shops of Sweden and Norway. |
| EBRD | European Bank for Reconstruction and Development. It lends money to local banks, for example for green loans. |
| Artifact | A panel next to the chat where Claude shows something it built. In this kit, it's an interactive dashboard. |
| "In code" | Claude writes and runs a small program to count and calculate. You see it in a box you can open. You never write code. |
| Project | A workspace in Claude with files and instructions. Every chat inside the Project can see them. |
| Project instructions | The text that every chat in the Project follows. In this kit, it holds the date and the three rules. |

## What the statuses mean

> The status tells you how well a file proves the answer. It doesn't tell you whether the answer is
> good news.
>
> - **OK** means a file proves it. That can still be bad news, because a file can prove a problem.
> - **NEEDS CHECK** means the file exists, but it's expired, an estimate or in conflict with another
>   file.
> - **NOT FOUND** means there's no file. Claude names the document that would prove it. If a file is
>   missing and another file conflicts, it's still NOT FOUND.
> - If a question has several parts, it gets the status of its weakest part.
> - **PARTIAL** (Step 4 only) means some data points are proven and others are missing.
>
> Step 2 rates marketing claims with colours instead: RED, AMBER or GREEN. The legend is at the end
> of `project-files/eu_green_claims_rules.md`.

---

## Setup (once, about 15 minutes)

1. Unzip the kit. (On Windows, right-click the ZIP file > Extract All.)
2. In claude.ai or the desktop app, open **Projects** in the left sidebar. Create a new Project
   called `Crvena Zemja ESG`.
3. On the Project page, find **Instructions** (usually on the right; it may say "Set project
   instructions") and click to edit them. Open `project-instructions.md` in a text editor, copy all
   of it, paste it into the box and save. It contains today's date and the three rules for Claude.
   **Keep the date 16 October 2026 for this kit, even if you run it later.** The answers in
   `ANSWERS.md` depend on it.
4. On the Project page, find **Files** (it may say "Project knowledge") and click **+**, then
   upload from your device. Select all 13 files from `project-files/` at once (Ctrl+A on Windows,
   Cmd+A on a Mac). **Don't add the inbox files.**
5. If a .md file won't upload, rename it to .txt and try again. Claude will still find it when a
   prompt names the .md file. This works for the inbox files too.
6. If your plan has no Projects option, start a normal chat instead. Attach the 13 project files and
   the inbox file for the step, and paste all of `project-instructions.md` at the top of your
   message, before the prompt. Do this again in every new chat.

**Steps 1 to 4 each start a new chat from inside the Project page.** To do that, type in the
message box at the top of the Project page. A chat started from the normal home page can't see the
files, and every answer comes back NOT FOUND. Step 5 is different: you carry on in the Step 4 chat.

To attach a file to a message, click **+** (or the paperclip) under the message box and choose the
file.

A note on privacy: before you upload real company files, open Settings > Privacy and find the
setting about model training ("Help improve Claude"). If it's on, your chats can be used to train
models, so turn it off for company data. Also ask your manager whether company files may go into
Claude at all.

---

## Step 1 (Monday): the supplier questionnaire

Nordvik Vin AB, the Swedish importer, sends its supplier questionnaire. It has eight questions and
is due on Friday 23 October.

**Predict first** (on paper, before you send): how many of the 8 questions will come back OK?

Start a new chat in the Project. Attach `inbox/1-nordvik-questionnaire.md`, then send:

```
Answer the Nordvik Vin AB questionnaire in the attached file.
Return one table with exactly one row per question, Q1 to Q8: # | Question | Answer | Source file and line | Status (OK, NEEDS CHECK or NOT FOUND).
Before any energy total, count the months in code.
Also save the table as nordvik-answers.xlsx, with the Status cells filled green, amber or red.
Then write a 3-line summary.
```

Claude should count the electricity bills in code before it adds anything up. How many months does
it find? Open the code box to see the count.

`nordvik-answers.xlsx` appears as a file card under Claude's answer. Click it to preview it, and
download it if you want to keep it. It isn't saved in the Project.

**Check:** `ANSWERS.md`, Step 1.

## Step 2 (Wednesday): the marketing claims

Marketing wants to use seven green claims for the autumn launch, on German and Polish shelves and on
the website.

**Predict first:** on paper, mark each of the seven claims RED, AMBER or GREEN. The legend is at
the end of `project-files/eu_green_claims_rules.md`.

Start a new chat in the Project. Attach `inbox/2-marketing-claims.md`, then send:

```
Check the seven claims in the attached file against our files and eu_green_claims_rules.md.
Return a table: Claim | RED, AMBER or GREEN | Reason | Source file | Safe rewrite.
Put the red ones first.
```

Every verdict should name a file. A claim can't be GREEN without one.

There's no file in this step. Claude answers with a table in the chat.

**Check:** `ANSWERS.md`, Step 2.

## Step 3 (Friday): the bank form

Banka Povardarie sends its screening form for the solar loan.

**Predict first:** work out F4 on your phone calculator before Claude does. The formula is on the
form, and the three numbers you need are in `project-files/`.

Start a new chat in the Project. Attach `inbox/3-bank-form.md`, then send:

```
Fill in Banka Povardarie's form in the attached file.
Return one table: Field | Answer | Source file and line | Status (OK, NEEDS CHECK or NOT FOUND).
Calculate F4 in code with the formula printed on the form. Mark every estimate.
```

Notice which answers Claude marks as estimates, and whether a gap from Monday comes back.

The table appears in the chat. If Claude also writes a file, you'll see it as a file card under the
answer.

**Check:** `ANSWERS.md`, Step 3.

## Step 4 (Friday afternoon): the ESG Passport

That's three requests in one week, and many of them ask for the same facts. Now you build one ESG
Passport that answers all of them and names every gap.

**Predict first:** what will the chart do with September: a gap, an average, a zero or an error?

Start a new chat in the Project. Attach the three inbox files `1`, `2` and `3` again. A new chat can
see the Project files, but not the files you attached in other chats. We keep the requests out of
the Project on purpose, because they ask questions and don't prove anything.

The prompt asks Claude for one row per VSME heading (B1 to B11), a clickable dashboard and a Word
file. The B1 to B11 rows use only OK, PARTIAL or NOT FOUND. The open points also list the
NEEDS CHECK answers from Steps 1 and 3. You don't need to understand every word of the prompt.

```
The three attached files are this week's requests.
Build our ESG Passport: one row per VSME Basic heading B1 to B11 from vsme_basic_headings.md, with what we have, the source file, the status (OK; PARTIAL when some of the heading's data points are proven and others are missing, naming the missing ones; NOT FOUND when we have nothing; judge each heading for reporting year 2025 and put anything that expired or changed since then in the open points), and which questions in the attached files it answers. Use only the statuses OK, PARTIAL and NOT FOUND.
Deliver it two ways:
1. An interactive one-page dashboard as an artifact: status tiles B1 to B11 that open what we have and the source when clicked, a 12-month electricity bar chart in MWh that shows the missing month, a red, amber or green light for each of the seven claims, and the open points: every NOT FOUND, NEEDS CHECK and partial gap, each with the document that would close it. List a proven fail (data documented, rule broken) as an action, not as NEEDS CHECK. One self-contained file, no external data.
2. esg-passport.docx, ready to send.
```

Look at what the chart does with the month that has no bill. Then click a tile. Does it show the
source file?

The dashboard opens in a panel next to the chat (an artifact), and you can click the tiles.
`esg-passport.docx` appears as a file card under the answer. Neither is saved in the Project. This
is the longest step, so allow 3 to 6 minutes.

If Claude stops in the middle and shows a **Continue** button or a message about length, click
Continue (or send `Continue`). Don't start again.

**Check:** `ANSWERS.md`, Step 4.

## Step 5 (next Monday): the September invoice

Accounting has found the September 2025 electricity bill that was never filed, but only as a photo.
Leave the date in the Project instructions as it is.

**Predict first:** will the real year be higher or lower than the 11-month average × 12?

Don't start a new chat. Stay in the Step 4 chat, because the dashboard and the Word file you want
to update are there. If you closed it, open the Project page, where your earlier chats are listed.
Attach `inbox/4-september-invoice.png`, then send:

```
I attached the September 2025 electricity invoice. Read it first.
Then recheck every answer from this week that depends on electricity.
Also say what the invoice means for the draft energy summary, and how wrong the year would have been if we had estimated it as the 11-month average × 12.
Return a table with one row per question or form field: Where | Before (value and status) | Now (value and status) | Why.
Then update the dashboard and esg-passport.docx.
```

Check that Claude reads the photo correctly by comparing its kWh with the two meter readings on the
invoice. Which answers change, and which stay the same?

The dashboard updates in its panel. The new `esg-passport.docx` comes as a new file card at the
bottom of the chat, and the old one stays higher up.

If you hit the usage limit, you can wait for the reset and send the normal prompt. Or you can start
a new chat in the Project. Attach `inbox/4-september-invoice.png` and the inbox files 1, 2 and 3.
Copy the B1 to B11 table from Claude's Step 4 answer in the chat (not from the dashboard), and paste
it under the lite prompt.

Prompt 5 lite:

```
I attached the September 2025 electricity invoice and this week's three requests. My ESG Passport table from Friday is pasted at the end. Read the invoice first.
Then recheck every answer from this week that depends on electricity.
Also say what the invoice means for the draft energy summary, and how wrong the year would have been if we had estimated it as the 11-month average × 12.
Return a table with one row per question or form field: Where | Before (value and status) | Now (value and status) | Why.
Do not rebuild the dashboard or the docx.
```

**Check:** `ANSWERS.md`, Step 5.

---

## Your Monday: the same method for your own company

Now that you've seen how it works, you can use it for your own company.

1. Collect one folder of files. Use the Crvena Zemja files as your model:
   - a one-page company profile, like `company_profile.md`: legal form, NACE code, turnover,
     balance sheet total, employees, sites, energy and fuel sources
   - 12 electricity bills (count them), and your supplier's statement of its supply mix
   - fuel receipts (litres of diesel, petrol or gas)
   - 12 water bills
   - every certificate and audit report, with its expiry or next-audit date
   - headcount totals by contract type and gender
   - the safety register summary, and the total hours worked
   - waste records: total, hazardous, and sent to recycling
   - a yes/no on minimum wage and collective agreements
   - your policies, and a signed declaration on fines

   Also copy `vsme_basic_headings.md` into your new Project. It summarises the real standard
   (October 2026). Delete its second line ("Fictional training data ...") first.
2. Make a new Project for your company. **Never mix your real files with the Crvena Zemja files.**
   Check Settings > Privacy first. Then paste the text below into the Project instructions and fill
   in the brackets. Don't copy the line "Fictional training data", because your files are real.

```
Today is [date, for example 9 November 2026]. Reporting year: [2025].

You are the ESG evidence assistant of [company name and legal form], a [type of business] in [country]. Answer in plain, short English unless I ask for another language.

Three rules:
1. Only our files. Never invent a number.
2. Cite the file and line for every fact (line numbers as in a text editor, counting every line). Do every calculation in code, with units.
3. Missing document: write NOT FOUND and name the document that would prove it. Document exists but is expired, an estimate or in conflict with another file: write NEEDS CHECK and give the reason in one sentence. If a document is missing and another file also conflicts, write NOT FOUND and name the conflict in the reason. A question with several parts gets the status of its weakest part.

People data stays aggregated: no names, no individual records.
```

**Change the date every time you start work.** Claude checks every expiry date against it.

3. When the next questionnaire arrives, start a new chat in the Project, attach the questionnaire
   and send the prompt below.
4. Treat every NOT FOUND as a to-do item. It names the document you should collect next.
5. **A person checks and signs every answer** before it leaves the company. Claude prepares the
   answers, and you decide.
6. Keep people data aggregated: totals only, with no names and no individual records.

Your prompt for the next questionnaire (replace the part in brackets):

```
Answer the questionnaire from [customer or bank name] in the attached file.
Return one table with exactly one row per question: # | Question | Answer | Source file and line | Status (OK, NEEDS CHECK or NOT FOUND).
Before any total, count the months in code.
Then list every NOT FOUND with the document that would close it.
```
