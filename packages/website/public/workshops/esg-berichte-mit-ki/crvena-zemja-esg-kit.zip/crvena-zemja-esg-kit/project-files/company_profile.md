# Company profile: Vinarija Crvena Zemja DOO
Fictional training data. Every company, person and document is invented.

- Family winery in Kavadarci municipality, North Macedonia, in the Tikveš wine region.
- NACE: 11.02 Manufacture of wine from grape. Sites: one cellar and bottling site in Kavadarci municipality, plus 40 ha of own vineyards nearby.
- Products: bottled still wine (Vranec, Kratošija, Smederevka), about 550,000 bottles a year.
- Vineyards: 40 ha of our own. 12 ha farmed under organic rules (see organic_certificate_vineyard.txt).
- The vineyards are not irrigated. Water is used only in the cellar and for bottling.
- People: 42 employees on average in 2025, plus 18 seasonal day workers at harvest (not employees).
- Turnover 2025: 95.0 million MKD. Small enterprise.
- Sales 2025: exports 74% of revenue (Germany 31%, Nordvik Vin AB (Sweden) 22%, Poland 17%, other 4%). Domestic 26%.
- Energy: all electricity from the grid, supplier Lumivolt Snabduvanje DOOEL. No PV yet. No on-site generation.
- Every electricity invoice uses one flat fictional tariff of 9.50 MKD/kWh (not a real price list).
- Tank cooling peaks in September and October.
- No GHG inventory has been prepared.
- Planned: 150 kWp rooftop PV, loan of 8,550,000 MKD requested from Banka Povardarie AD Skopje, an EBRD-style green credit line.
