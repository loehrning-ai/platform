# EU rules on green claims
Fictional training data. Every company, person and document is invented. Exception: this file summarises real EU law.
Teaching summary, not legal advice.

Directive (EU) 2024/825 applies since 27 Sept 2026 to claims made to consumers in the EU, through
national laws (check national law). It covers a non-EU producer's words on an EU shelf or website.
North Macedonia is not in the EU (it is a candidate country). Germany and Poland are.

Banned:
1. Generic claims such as "eco-friendly" or "green" without recognised excellent environmental
   performance (for example the EU Ecolabel).
2. "Climate neutral", "reduced" or "positive" impact claims for a product based on carbon offsets.
3. Sustainability labels not based on a certification scheme or set by a public authority.
4. Claims about the whole product or company that are true for only one aspect.
5. Claims about future environmental performance (for example "we will run on solar") without
   clear, public, verifiable commitments in a detailed and realistic implementation plan checked
   by an independent expert.

Safe pattern: specific, measured, sourced, dated, true for the whole product it is attached to.
If no file proves a safe version of a claim, the safe rewrite is "Drop it".

Fines: for widespread breaches in coordinated EU enforcement, the maximum fine must be at least 4%
of annual turnover in the countries concerned (Directive (EU) 2019/2161).

Legend for our checks:
RED = our files contradict the claim, or it is a banned practice.
AMBER = possibly true, but our files cannot prove it.
GREEN = specific and proven by a cited file.
