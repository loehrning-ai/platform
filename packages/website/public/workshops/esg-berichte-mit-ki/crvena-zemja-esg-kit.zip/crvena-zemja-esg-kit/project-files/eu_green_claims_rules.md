# EU rules on green claims
Fictional training data. Every company, person and document is invented. Exception: this file summarises real EU law.
Teaching summary, not legal advice.

Directive (EU) 2024/825 applies from 27 Sept 2026 to claims made to consumers in the EU, through
national laws (check national law). It covers a non-EU producer's words on an EU shelf or website.
North Macedonia is not in the EU (it is a candidate country). Germany and Poland are.
- Germany: in force since 27 Sept 2026 (BGBl. 2026 I Nr. 43).
- Poland: the national law was signed on 15 Oct 2026 and applies only from 27 Sept 2027. Until
  then, misleading green claims are already illegal under the general rules on unfair commercial
  practices (Unfair Commercial Practices Directive, through Polish law), and the Polish regulator
  UOKiK can act.
Treat both markets the same: use the safe pattern everywhere.

Banned in all cases (EU blacklist, Annex I of the Unfair Commercial Practices Directive):
1. Generic claims such as "eco-friendly" or "green" without recognised excellent environmental
   performance (for example the EU Ecolabel). Annex I, point 4a.
2. "Climate neutral", "reduced" or "positive" impact claims for a product based on carbon offsets.
   Annex I, point 4c.
3. Sustainability labels not based on a certification scheme or set by a public authority. Point 2a.
4. Claims about the whole product or company that are true for only one aspect. Point 4b.

Not on the blacklist, but misleading unless backed (judged case by case):
5. Claims about future environmental performance (for example "we will run on solar"). They are
   misleading (Art. 6(2)(d) of the Unfair Commercial Practices Directive) unless backed by a
   detailed, realistic plan with targets, regularly checked by an independent expert.

Safe pattern: specific, measured, sourced, dated, true for the whole product it is attached to.
If no file proves a safe version of a claim, the safe rewrite is "Drop it".

Fines: for widespread cross-border breaches, the national maximum fine must be at least 4% of
annual turnover in the countries concerned (or at least EUR 2 million where turnover is unknown).
This is a cap, not a minimum fine (Directive (EU) 2019/2161).

Legend for our checks:
RED = our files contradict the claim, or it is a banned practice.
AMBER = possibly true, but our files cannot prove it.
GREEN = specific and proven by a cited file.
