# VSME Basic Module: the 11 headings
Fictional training data. Every company, person and document is invented. Exception: this file summarises a real EU standard.

EU voluntary sustainability standard for SMEs (VSME). Since 24 Sept 2026 it is set by Commission
Delegated Regulation (EU) 2026/1560, which replaced Recommendation (EU) 2025/1710. Voluntary, no
assurance needed. Teaching summary, not the official text.

| # | Heading | Asks for, in short |
|---|---|---|
| B1 | Basis for preparation | module chosen, individual or consolidated report, legal form, NACE, balance sheet total, turnover, employees, country, location and geolocation of sites; sustainability certificates or labels (issuer, date, rating) |
| B2 | Practices, policies and future initiatives for transitioning towards a more sustainable economy | practices, policies (and whether they are public), future initiatives, targets. "No" is a valid answer |
| B3 | Energy and greenhouse gas emissions | total energy in MWh, electricity and fuels (renewable / non-renewable where obtainable); Scope 1 and location-based Scope 2 in tCO2e (Scope 2 = kWh x a published grid-average emission factor) |
| B4 | Pollution of air, water and soil | only if the law (or an environmental management system) already makes us report pollutant emissions: those emissions. Otherwise B4 does not apply; our environmental permit shows which |
| B5 | Biodiversity | our sites in or near (overlapping or next to) a biodiversity-sensitive area, with the area's name |
| B6 | Water | total water withdrawal (water consumption only if a process consumes a lot of water) |
| B7 | Resource use, circular economy and waste management | circular practices; total waste, hazardous and not; share sent to recycling or reuse; mass of key materials if significant |
| B8 | Workforce, General characteristics | employees (headcount or FTE) by contract type and gender; by country if more than one |
| B9 | Workforce, Health and safety | employees only: recordable work accidents (death or more than 3 days off work), rate (accidents / hours worked x 200,000), fatalities |
| B10 | Workforce, Remuneration, collective bargaining and training | pay at or above minimum wage (yes/no), share of employees covered by collective agreements, average training hours per employee; gender pay gap only if the law already requires us to report it |
| B11 | Convictions and fines for corruption and bribery | number of convictions and total fines for corruption and bribery |

What changed in 2026, compared with the 2025 Recommendation:
- B3 no longer asks for GHG intensity.
- The employee turnover rate moved from B8 to the Comprehensive Module (C5).
- B5 asks only which sites are in or near a sensitive area, with the area's name. It no longer
  asks for land-use figures.
- B10 asks for the gender pay gap only if the law already requires it. Training hours are no
  longer split by gender.
- "If applicable" rule: if you leave a disclosure out, readers take it to mean "this does not
  apply to us". So never leave a real gap blank: say what is missing.
The free EFRAG Excel template v1.3.0 (June 2026) still follows the 2025 Recommendation. An update
for Regulation (EU) 2026/1560 is due in Q4 2026:
https://www.efrag.org/en/vsme-digital-template-and-xbrl-taxonomy
