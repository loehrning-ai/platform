# Rules for environmental claims to consumers
Fictional training data. Exception: this file summarises real EU law. Teaching aid, not legal advice.

Directive (EU) 2024/825 amends the Unfair Commercial Practices Directive (2005/29/EC).
Member states apply it since 27.09.2026, Germany through its Act against Unfair Competition
(UWG). It covers claims to consumers in the EU, including from a producer outside the EU
whose label stands on a German shelf.

Always banned, with or without evidence (Annex I of Directive 2005/29/EC):
- No. 2a: a sustainability label that is neither based on a certification scheme nor set by a
  public authority.
- No. 4a: a generic environmental claim such as "environmentally friendly" or "green" without recognised
  excellent environmental performance, for example the EU Ecolabel.
- No. 4b: an environmental claim about the whole product or the whole company that is true for only a part.
- No. 4c: the claim that a product is climate neutral, reduced or positive because of offsetting.
- No. 10a: presenting a legal requirement as a distinctive feature of your own offer.

Not on the list, but misleading without a plan (Art. 6(2)(d)): claims about future
environmental performance, such as "solar powered from 2027". Allowed only with clear, public and
verifiable commitments in a detailed, realistic implementation plan with measurable,
time-bound targets that independent experts check regularly.

In Germany this applied before: whoever advertises "climate neutral" must explain in the ad itself
whether reduction or offsetting is meant (Federal Court of Justice, 27.06.2024, I ZR 98/23).

How to check a claim:
1. If an item on the ban list applies, it is dropped.
2. Otherwise the evidence check. Only COVERED for everything the claim stands on may be sent.
Safe wording: specific, measured, with source and date, true for exactly what it stands on.
If no file carries a safe wording: "Drop."
