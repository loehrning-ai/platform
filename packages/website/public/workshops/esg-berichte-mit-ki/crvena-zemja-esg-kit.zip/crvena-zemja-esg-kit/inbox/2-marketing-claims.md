# Draft claims for the autumn launch
Fictional training data. Every company, person and document is invented.

From: marketing. For German and Polish shelves (labels, shelf cards) and our website.

| # | Claim | Where |
|---|---|---|
| 1 | "Climate-neutral wine" | back label, all wines |
| 2 | "Eco-friendly winery" | website home page |
| 3 | "Certified organic vineyards" | shelf card, all wines |
| 4 | "Solar-powered winery" | website, about us |
| 5 | "We cut our electricity use by 12% in 2025" | website news |
| 6 | "This bottle weighs only 395 g and is made with 60% recycled glass" | back label of Vranec Tikveš 2024 only |
| 7 | "In 2025 our whole winery used 4,630 m3 of water, measured on 12 monthly bills" | website, sustainability page |
