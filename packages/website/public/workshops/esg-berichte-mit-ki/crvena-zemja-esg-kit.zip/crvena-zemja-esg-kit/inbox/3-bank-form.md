# Банка Повардарие АД Скопје
Fictional training data. Every company, person and document is invented.

## Образец за еколошка и социјална проверка и за зелена подобност
(Environmental & Social Screening and Green Eligibility Form)

Клиент: Винарија Црвена Земја ДОО. Кредит: 8.550.000 ден. за фотонапонски систем од 150 kWp на покривот,
кредитна линија за зелено финансирање по урнек на ЕБОР (измислена). Modelled on the screening that
banks on-lending EBRD funds must do (EBRD ESR 9, October 2024).

Пополнете го секое поле. Означете ја секоја проценка. (Fill in every field. Mark every estimate.)

F1. Глоби за животна средина, работни односи и БЗР, 2023-2025 (environmental, labour, H&S fines)
F2. Потрошувачка на електрична енергија во 2025 година, MWh (electricity baseline 2025)
F3. Проценето годишно фотонапонско производство и удел во потрошувачката (expected PV output per year, share of consumption)
F4. Едноставен рок на поврат, години (simple payback, years) =
    инвестиција / (проценето годишно производство во kWh x тековна цена во ден./kWh)
    Едноставна формула на банката, не инвестициска анализа. (Bank's formula, not an investment case.)
F5. Просечен број на вработени и несреќи при работа 2025 (average headcount, work accidents)
F6. Важечки сертификати и ревизии (оцена, датум на следната ревизија) (valid certificates and audits)

Training note: 9.50 MKD/kWh on the client's invoices is a fictional flat tariff.
