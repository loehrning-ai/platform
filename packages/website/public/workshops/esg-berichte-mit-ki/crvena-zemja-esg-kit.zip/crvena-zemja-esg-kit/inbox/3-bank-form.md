# Banka Povardarie AD Skopje: Environmental & Social Screening and Green Eligibility Form
Fictional training data. Every company, person and document is invented.

Client: Vinarija Crvena Zemja DOO. Loan: 8,550,000 MKD for a 150 kWp rooftop PV system, from an
EBRD-style green credit line (fictional). Modelled on the screening that banks on-lending EBRD
funds must do (EBRD ESR 9, October 2024).

Fill in every field. Mark every estimate.

F1. Environmental, labour and health-and-safety fines, 2023-2025
F2. Electricity consumption 2025, MWh
F3. Estimated annual PV output, and share of consumption
F4. Simple payback of the investment, years =
    investment / (estimated annual output in kWh × current price in MKD/kWh)
    The bank's simple formula, not an investment case.
F5. Average headcount and work accidents, 2025
F6. Valid certificates and audits (rating, date of next audit)

Training note: 9.50 MKD/kWh on the client's invoices is a fictional flat tariff.
