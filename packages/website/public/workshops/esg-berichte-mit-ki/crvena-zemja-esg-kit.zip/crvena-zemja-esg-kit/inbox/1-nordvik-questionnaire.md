# Supplier Sustainability Questionnaire 2026
Fictional training data. Every company, person and document is invented.

From: Nordvik Vin AB, Gothenburg, Sweden (wine importer). To: Vinarija Crvena Zemja DOO.
We supply Systembolaget and are preparing a Vinmonopolet tender (Norway, EEA, not EU).
Based on the Basic Module of the EU voluntary sustainability standard for SMEs (VSME).
Reporting year 2025. Please return by Friday 23 October 2026.

Scoring rules:
- Answers without a supporting document receive no credit.
- Certificates must be valid on the submission date.
- Energy data must cover the full reporting year (95% coverage).

| # | VSME | Question |
|---|---|---|
| Q1 | B3 | Electricity consumption 2025 in MWh, and the renewable share (%) |
| Q2 | B3 | Scope 1 and location-based Scope 2 emissions 2025 in tCO2e |
| Q3 | B8 | Average headcount 2025 by contract type and gender |
| Q4 | B9 | Recordable work accidents and fatalities 2025 |
| Q5 | B11 | Convictions or fines for corruption or bribery in 2025 |
| Q6 | (none) | Glass weight of each 0.75 l still wine you plan to sell under NOK 250. Vinmonopolet rule since 1 Jan 2026: still wine under NOK 250 must be in glass bottles of at most 420 g per 0.75 l (sparkling exempt). Products that fail are dismissed. |
| Q7 | (none) | Valid certificates and audits, with expiry or next-audit dates |
| Q8 | B6 | Water withdrawn 2025 in m3 |
