# Draft: environmental claims for the autumn launch
Fictional training data. Every company, person and document is invented.

From: Marketing. For labels and shelf cards in Germany and for our website.

| No | Claim | Where |
|---|---|---|
| 1 | "Climate neutral wine" | back label, all wines |
| 2 | "Eco-friendly winery" | website, home page |
| 3 | "Certified organic vineyards" | shelf card, all wines |
| 4 | "Solar powered winery" | website, about us |
| 5 | "In 2025 we used 12 % less electricity" | website, news |
| 6 | "This bottle weighs only 395 g and is 60 % recycled glass" | back label, Vranec Tikveš 2024 only |
| 7 | "In 2025 the whole winery withdrew 4,630 m³ of water, measured on 12 monthly bills" | website, sustainability page |
