# Supplier sustainability questionnaire 2026
Fictional training data. Every company, person and document is invented.

From: Nordvik Vin AB, Gothenburg, Sweden (wine importer). To: Vinarija Crvena Zemja DOO.
We supply Systembolaget and are preparing a Vinmonopolet tender (Norway, EEA, not EU).
Based on the Basic Module of the EU voluntary sustainability standard for SMEs (VSME).
Reporting year 2025. Return by 23.10.2026.

Assessment rules:
- Answers without evidence are not counted.
- Certificates must be valid on the day of submission.
- Energy data must cover the full reporting year (95 % coverage).

| No | VSME | Question |
|---|---|---|
| Q1 | B3 | Electricity use 2025 in MWh and renewable share (%) |
| Q2 | B3 | Scope 1 and location-based Scope 2 2025 in tCO2e |
| Q3 | B8 | Average employees 2025 by contract type and gender |
| Q4 | B9 | Recordable work accidents and fatalities 2025 |
| Q5 | B11 | Convictions or fines for corruption or bribery 2025 |
| Q6 | (none) | Glass weight of every 0.75 l still wine you plan to sell below 250 NOK. Vinmonopolet rule since 1.1.2026: still wine below 250 NOK must be in bottles of at most 420 g per 0.75 l (sparkling wine excepted). Vinmonopolet does not accept products that fail. |
| Q7 | (none) | Valid certificates and audits, with expiry date or date of the next audit |
| Q8 | B6 | Water withdrawal 2025 in m³ |
