# Banka Povardarie AD Skopje
Fictional training data. Every company, person and document is invented.

## Environmental and social review and green eligibility form

Client: Vinarija Crvena Zemja DOO. Loan: 8,550,000 MKD for a 150 kWp rooftop PV system,
from an EBRD-style green credit line (fictional).

Please complete every field. Mark every estimate.

F1. Environmental, labour and health-and-safety fines, 2023 to 2025
F2. Electricity use 2025, full year, in MWh
F3. Expected PV yield per year and its share of consumption
F4. Simple payback in years =
    investment / (expected annual yield in kWh × current price in MKD/kWh)
    The bank's simple formula, not an investment appraisal.
F5. Average employees and work accidents 2025
F6. Valid certificates and audits (rating, date of the next audit)

Note for the exercise: 9.50 MKD/kWh on the client's invoices is a fictional flat tariff.
