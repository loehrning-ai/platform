# Company profile: Vinăria Valea Sturzilor SRL
Fictional training data. Every company, person and document is invented.

- Family winery in Hîncești district, Moldova, in the Codru wine region.
- NACE: 11.02 Manufacture of wine from grape. Sites: one cellar and bottling site in Hîncești district, plus 40 ha of own vineyards nearby.
- Products: bottled still wine (Fetească Neagră, Rară Neagră, Fetească Albă), about 550,000 bottles a year.
- Vineyards: 40 ha of our own. 12 ha farmed under organic rules (see organic_certificate_vineyard.txt).
- The vineyards are not irrigated. Water is used only in the cellar and for bottling.
- People: 42 employees on average in 2025, plus 18 seasonal day workers at harvest (not employees).
- Turnover 2025: 38.0 million lei. Small enterprise.
- Sales 2025: exports 74% of revenue (Romania 31%, Nordvik Vin AB (Sweden) 22%, Poland 17%, other 4%). Domestic 26%.
- Energy: all electricity from the grid, supplier Lumivolt Furnizare SRL. No PV yet. No on-site generation.
- Every electricity invoice uses one flat fictional tariff of 3.80 lei/kWh (not the real ANRE price).
- Tank cooling peaks in September and October.
- No GHG inventory has been prepared.
- Planned: 150 kWp rooftop PV, loan of 3,420,000 lei requested from BC Banca Merișor S.A., an EU4Business-EBRD-style credit line.
