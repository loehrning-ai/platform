# VSME Basic Module: the 11 headings
Fictional training data. Every company, person and document is invented. Exception: this file summarises a real EU standard.

EU voluntary sustainability standard for SMEs (VSME). Since 24 Sept 2026 it is set by Commission
Delegated Regulation (EU) 2026/1560, which replaced Recommendation (EU) 2025/1710. Voluntary, no
assurance needed. Teaching summary, not the official text.

| # | Heading | Asks for, in short |
|---|---|---|
| B1 | Basis for preparation | module used, legal form, NACE, country, sites, turnover, employees, certificates or labels |
| B2 | Practices, policies and future initiatives for transitioning towards a more sustainable economy | practices, policies, future initiatives (climate, water, circularity, workforce, conduct) |
| B3 | Energy and greenhouse gas emissions | total energy in MWh (renewable / non-renewable where obtainable); Scope 1 and location-based Scope 2 (kWh x official grid-average factor) in tCO2e |
| B4 | Pollution of air, water and soil | pollutant emissions, if already reported by law |
| B5 | Biodiversity | sites in or near biodiversity-sensitive areas |
| B6 | Water | total water withdrawal |
| B7 | Resource use, circular economy and waste management | circular practices; total waste, hazardous and not; share recycled |
| B8 | Workforce, General characteristics | employees (headcount or FTE) by contract type and gender; by country if more than one |
| B9 | Workforce, Health and safety | recordable work accidents, rate, fatalities |
| B10 | Workforce, Remuneration, collective bargaining and training | pay vs minimum wage, gender pay gap, collective bargaining, training hours |
| B11 | Convictions and fines for corruption and bribery | convictions and fines for corruption and bribery |

2026 changes: B3 no longer asks for GHG intensity. Employee turnover rate moved from B8 to the
Comprehensive Module (C5). Free EFRAG Excel template (v1.3.0):
https://www.efrag.org/en/vsme-digital-template-and-xbrl-taxonomy
