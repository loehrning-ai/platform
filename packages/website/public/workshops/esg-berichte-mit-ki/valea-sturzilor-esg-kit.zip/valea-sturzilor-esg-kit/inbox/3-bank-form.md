# BC Banca Merișor S.A.
Fictional training data. Every company, person and document is invented.

## Formular de evaluare de mediu și socială și de eligibilitate verde
(Environmental & Social Screening and Green Eligibility Form)

Client: Vinăria Valea Sturzilor SRL. Credit: 3,420,000 lei for a 150 kWp rooftop PV system,
linie de credit de tip EU4Business-EBRD (fictivă). Modelled on the sub-project screening that
banks on-lending EBRD funds must do (EBRD ESR 9, October 2024).

Completați fiecare câmp. Marcați orice estimare. (Fill in every field. Mark every estimate.)

F1. Amenzi de mediu, de muncă și SSM, 2023-2025 (environmental, labour and H&S fines)
F2. Consumul de energie electrică 2025, MWh (electricity baseline 2025)
F3. Producția PV estimată pe an și ponderea în consum (expected PV output per year, share of consumption)
F4. Termen simplu de recuperare, ani (simple payback, years) =
    investiție / (producție anuală estimată în kWh x tariful curent în lei/kWh)
    Formula simplă a băncii, nu o analiză a investiției. (Bank's simple payback formula, not an investment case.)
F5. Număr mediu de angajați și accidente de muncă 2025 (average headcount, work accidents)
F6. Certificate valabile și audituri (calificativ, data următorului audit) (valid certificates and audits: rating, next audit date)

Training note: 3.80 lei/kWh on the client's invoices is a fictional flat tariff.
