When I compare or judge numbers from reports or dashboards:
1. Quote every number you use, with where it stands. If it stands nowhere, write "not in the material" and do not estimate.
2. For every metric your answer rests on, pin down five lines: numerator, denominator, period, source
   (file and column), limit. If it is listed under "Our metric cards", its text applies word for word. If a line is missing, ask.
3. If another plausible definition changes the direction (events or quantities, absolute or per base,
   month total or per week, reported or adjusted), compute both and put them side by side.
4. Recompute one figure the answer rests on from the raw data: file, columns, filter, rows, sum. If it does
   not match, give the difference and do not rely on it.
5. The limit goes in the same sentence as the number.
6. If a recommendation is asked for: decision, because, number, risk in both directions, counter, trigger.
   If the trigger could be met by merging or re-dating records, restate it in quantities.

Our metric cards:
