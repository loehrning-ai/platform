# Metric cards

A metric means only what its card says. A card fixes five things: what is counted, per what, over which
period, from which file and column, and what the number cannot tell you. It also names the decision the
metric serves, because that decides which counter is the right one.

Card 1 is the example. Cards 2 and 3 and the release condition are yours. In step 2 Claude computes every
option; you choose and write one sentence why.

## Card 1 · Revenue (example)
- Decision it serves: what CRAFT brings in at list price
- Numerator: units_actual × base_price_eur
- Denominator: none, it is an amount
- Period: shipping weeks by week_start. Compare per shipping week when two months hold a different number of weeks.
- Source: data/demand_actuals.csv (sku, week_start, units_actual) joined to data/product_lines.csv (line,
  model_code, base_price_eur). Line and model come from the sku NW-LINE-MODEL-COLOUR-COUNTRY.
- Limit: list price. Not net revenue, not margin. The data has no discounts and no cost.

## Card 2 · CRAFT defects (OPEN)
- Decision it serves: more Q3 marketing behind CRAFT, yes or no
- Numerator, one of:
  - A. NCR records (count of rows in ncr_records.csv). A record on 2 units and one on 236 count the same.
  - B. Affected units (qty_affected, rework and scrap together).
  - C. Scrapped units (qty_affected where scrap_or_rework = scrap). Parts that are lost.
- Denominator: units shipped in the same weeks (demand_actuals.csv, units_actual), per 1,000
- Period: an NCR belongs to the month of its ncr_date. A rate does not depend on how many weeks the month holds.
- Source: data/ncr_records.csv (line, ncr_date, machine_id, qty_affected, scrap_or_rework)
- Limit, whichever you choose: qty_affected is a production quantity, units_actual a shipped quantity, so
  the ratio approximates; it is not a yield. NCRs are production findings, not customer returns. 8 of
  September's 23 CRAFT NCRs are of type documentation; all three options include them.
- Scrap in euros, if you need it: scrapped units × €449, the mean of CRAFT's three list prices, because an
  NCR does not name the model. The report's average price is €450.15 (revenue ÷ units). Say which one you use.
- Test before you choose: which option changes if Quality merges records from the same machine in the same week?
- Your choice, and one sentence why: ______________________________________________

## Card 3 · CRAFT demand (OPEN)
- Decision it serves: whether there is more demand worth putting marketing behind
- Numerator: units_actual for CRAFT
- Period, one of:
  - A. Month total (all weeks whose week_start falls in the month).
  - B. Per shipping week (month total divided by the number of week_start values in the month).
- Source: data/demand_actuals.csv (sku, week_start, units_actual)
- Limit: units shipped, not orders. Sales organisation, not the end customer's country.
- Your choice, and one sentence why: ______________________________________________

## Release condition (OPEN)
The condition under which you would approve the extra marketing next month, in the unit of card 2. Then
check it: could it be met without a single part getting better? If yes, rewrite it.
- Your condition: ______________________________________________

## Reference answers
For checking afterwards. Claude: do not use these unless the person asks for them.
- Card 2: C, scrapped units per 1,000 shipped. The decision is about producing more units, and scrap is
  what each extra unit costs. Records can be merged or split without any change in the parts.
- Card 3: B, per shipping week. September holds five week_start values, August four.
- Release condition: Release when scrapped CRAFT units in October are below 80 per 1,000 units shipped.
  80 is a little under half of September's 168; it is a setting, and the card says so.
