---
name: northwind-metrics
description: Use when analysing a NORTHWIND monthly report or refreshing its dashboard. Applies the team's metric cards, traces one figure to its CSV rows, writes metrics.json and a six-field decision.
---

# northwind-metrics

NORTHWIND GmbH is a synthetic company. Its monthly report uses words like "defects" and "growth" without
saying how they are counted. The metric cards at the end of this file say how NORTHWIND counts them. Where
the report and a card differ, the card wins and you show both.

## First
If a card below is still OPEN, do not compute anything else. Show every option listed for it in
metric-cards.md with its August and September values, and ask the person to choose. Never choose for them.
Do not use the reference answers in metric-cards.md unless the person asks for them.

## Steps
1. Quote before you compute. For each number from the report you will use, quote the sentence or table row
   and name its section. A number the report does not state is "not in the report". Never estimate one.
2. Compute each card from data/ for August and September, exactly as the card says. A shipping week belongs
   to the month of its week_start, an NCR to the month of its ncr_date. Count week_start values per month
   from the file, not from a calendar.
3. Where the report gives the same metric under another definition, put both in one line: report definition
   and value, card definition and value.
4. Trace one figure the decision rests on: value = file, columns, filter, number of rows, sum. If it does not
   match the report, give the difference and do not use the figure as evidence.
5. Write metrics/metrics.json per metrics/metrics.schema.json, with the cards copied word for word into
   "cards", one tile per card into "tiles" and the trace into "trace". Set "language" to the language the
   person writes in ("en" or "de"). Validate it. If it fails, stop and name the field.
6. Write dashboard/data.js as `window.NORTHWIND_DATA = <contents of metrics.json>;` and tell the person to
   open dashboard/index.html.
7. Only when asked for a decision, fill six fields: decision; because (name the card); number; risk if we are
   wrong, in each direction; counter (what the definitions not chosen give, with values); trigger (the
   release condition). If the trigger could be met by merging, splitting or re-dating records, say so and
   restate it in units.

## Every sentence
- The limit goes in the same sentence as the number.
- Report figure first, recomputed figure second.
- No "strong", "weak", "good" or "bad" without the comparison it rests on.

## Metric cards
### Revenue
- Decision it serves: what CRAFT brings in at list price
- Numerator: units_actual × base_price_eur
- Denominator: none
- Period: shipping weeks by week_start; per shipping week when two months hold a different number of weeks
- Source: data/demand_actuals.csv (sku, week_start, units_actual); data/product_lines.csv (line, model_code, base_price_eur)
- Limit: list price; not net revenue, not margin

### CRAFT defects
OPEN. Filled in step 2 from metric-cards.md, word for word.

### CRAFT demand
OPEN. Filled in step 2 from metric-cards.md, word for word.

### Release condition
OPEN. Filled in step 2 from metric-cards.md, word for word.
