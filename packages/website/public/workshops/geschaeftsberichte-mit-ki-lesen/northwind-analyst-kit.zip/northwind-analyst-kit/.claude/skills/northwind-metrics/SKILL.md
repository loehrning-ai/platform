---
name: northwind-metrics
description: >-
  Read NORTHWIND's monthly performance report and turn it into structured metrics (revenue by line,
  defects, marketing spend, escalations, the line-to-interrogate flag) written to metrics/metrics.json,
  then explain them using NORTHWIND's own metric definitions and reading rules. Use whenever the user asks to
  analyze the NORTHWIND monthly report, pull this month's numbers, or build/refresh the dashboard.
---

# northwind-metrics — how NORTHWIND reads its month

You are the analyst for **NORTHWIND GmbH** (a synthetic Berlin consumer-electronics maker). This Skill
holds **NORTHWIND's own definitions and reading rules**, so every month's analysis is consistent — whoever runs
it, whatever the numbers are.

> **This Skill is half-written on purpose.** The *procedure* below is done. The **metric definitions**
> and **reading rules** have two worked examples and the rest left blank. Complete them from
> `worksheet.md` (a business person can do this in plain language — no code), then run the Skill. What you
> write here is exactly what you'd write for your own company. Once every slot is filled, delete this
> note and the "filled in as examples" lines — the Skill is then complete.

## What to do when this Skill runs

1. **Extract this month's numbers from the report — don't invent them.** Read the report you're given
   (this month: `reports/2023-09-monthly-report.md`) and pull its figures into `metrics/metrics.json`
   following `metrics/metrics.schema.json`: totals (§1), revenue by line (§2) — with each line's price
   range from `data/product_lines.csv` — defects by line (§3),
   marketing by channel (§4), open P1/P2 escalations with their IDs (§5), the caveats from §7 (what this
   data can't tell you), and the **CRAFT flag** — the line to interrogate, with its `line`, `units`,
   `revenue_eur`, `ncr_count`, `price_range_eur` (from `data/product_lines.csv`, not the report), and
   the two highest-price / highest-defect booleans, which document the flag's evidence. If the report
   doesn't state a number, leave it out and say so — never estimate.
2. **Validate** `metrics/metrics.json` against `metrics/metrics.schema.json`. If it doesn't match, stop and
   say what's off.
3. **Verify against source (the trust check).** Pick at least one number and confirm it in the matching CSV
   in `data/` (e.g. an escalation ID in `exec_escalations.csv`, or a line's units in `demand_actuals.csv`).
   State which number you checked and that it matched.
4. **Explain, applying the reading rules below.** Lead with what changed and the one decision on the table.
5. **Build the dashboard:** write `dashboard/data.js` as `window.NORTHWIND_DATA = <contents of metrics.json>;`
   then open `dashboard/index.html`. (This is the "fill the template" step — you do it, no API key.)

## NORTHWIND's metric definitions (what the numbers mean HERE)

*Two metric definitions are filled in as examples (Revenue, Units) — plus the CRAFT flag below. Complete the three `→ YOUR TURN:` slots from `worksheet.md`.*

- **Revenue (reported)** = Σ(units sold this month × the model's list price), rolled up per line. This is
  **list-price contribution, NOT true gross margin** (the data has no per-SKU cost). Always say so.
- **Units** = units sold this month, per line. Compare month-over-month (MoM) against the prior month.
- **Defects** = → YOUR TURN: _write what "defects" means for NORTHWIND. (Hint from the worksheet: the NCR
  count and units affected, by production line; it's a quality signal, not customer returns.)_
- **Marketing spend** = → YOUR TURN: _write what marketing means here. (Hint: campaign budgets by
  channel; not cleanly attributable to one product line.)_
- **Escalations** = → YOUR TURN: _write what an escalation is. (Hint: open P1/P2 items by severity and
  owning team.)_
- **The line to interrogate ("CRAFT flag")** = the line with **both** the highest list prices **and** the
  most defects this month → the line to question before scaling, instead of celebrating its revenue.

## Reading rules (NORTHWIND's "how we analyze" recipe)

*Two are filled in as examples. Complete the three `→ YOUR TURN:` slots from `worksheet.md`, in your own words.*

1. **Never read a line by revenue alone** — always pair its revenue with its defects and its MoM units.
2. **Every recommendation states the cost of being wrong** (warranty/rework exposure, or lost premium
   revenue if you cut the line).
3. → YOUR TURN: _add a reading rule (e.g. how to compare against the prior month or a target)._
4. → YOUR TURN: _add a reading rule (e.g. what to do with the highest-defect + highest-price line)._
5. → YOUR TURN: _add a reading rule about **naming what the data can't answer** (margin, customer
   returns by line) instead of faking it._

## The decision this month
CRAFT earns premium revenue on low volume but carries the most defects. The report frames the call as
**rework the line first** vs **put more Q3 marketing behind it** — back your answer with the number, state
the cost of being wrong, and name what the data can't tell you.
