---
name: northwind-metrics
description: >-
  Read NORTHWIND's monthly performance report and turn it into structured metrics (revenue by line,
  defects, marketing spend, escalations, the line-to-interrogate flag) written to metrics/metrics.json,
  then explain them using NORTHWIND's own metric definitions and reading rules. Use whenever the user asks to
  analyze the NORTHWIND monthly report, pull this month's numbers, or build/refresh the dashboard.
---

# northwind-metrics — how NORTHWIND reads its month

You are the analyst for **NORTHWIND GmbH** (a synthetic Berlin consumer-electronics maker). This Skill
holds **NORTHWIND's own definitions and reading rules**, so every month's analysis is consistent — whoever runs
it, whatever the numbers are.

> **This Skill is half-written on purpose.** The *procedure* below is done. The **metric definitions**
> and **reading rules** have two worked examples and the rest left blank. Complete them from
> `worksheet.md` (a business person can do this in plain language — no code), then run the Skill. What you
> write here is exactly what you'd write for your own company. Once every slot is filled, delete this
> note and the "filled in as examples" lines — the Skill is then complete.

## What to do when this Skill runs

1. **Extract this month's numbers from the report — don't invent them.** Read the report you're given
   (this month: `reports/2023-09-monthly-report.md`) and pull its figures into `metrics/metrics.json`
   following `metrics/metrics.schema.json`: totals (§1), revenue by line (§2) — with each line's price
   range from `data/product_lines.csv` — defects by line (§3),
   marketing by channel (§4), open P1/P2 escalations with their IDs (§5), the caveats from §7 (what this
   data can't tell you), and the **CRAFT flag** — the line to interrogate, with its `line`, `units`,
   `revenue_eur`, `ncr_count`, `price_range_eur` (from `data/product_lines.csv`, not the report), and
   the two highest-price / highest-defect booleans, which document the flag's evidence. If the report
   doesn't state a number, leave it out and say so — never estimate.
2. **Compute the `insights` block from the CSVs — this is the part the report cannot give you.**
   The report states the month; these five joins state what it means. Read the raw feeds in `data/`,
   not the report, and write the results into `insights`:
   - **`normalized_growth`** — count the distinct `week_start` buckets per month in
     `demand_actuals.csv`. If the two months have a different number of shipping weeks, the report's
     month-over-month figure is not like-for-like. Report both: the headline, and units per shipping
     week. Do this per line as well as company-wide (reading rule 3).
   - **`cost_of_quality`** — `ncr_records.csv` carries `qty_affected` and `scrap_or_rework`. Scrapped
     units are a total loss; value them at the line's average `base_price_eur` from
     `product_lines.csv`. This converts "23 NCRs" into money, which is the only form a budget
     conversation accepts. Also express each line's scrap as a percentage of that line's own revenue.
   - **`defect_rate_by_line`** — NCR count ÷ units shipped × 1,000 (reading rule 3). Raw counts
     flatter high-volume lines.
   - **`flagged_line_breakdown`** — group the flagged line's NCRs by `machine_id` and by `ncr_type`.
     One machine means a repair; many machines mean a line programme. That difference changes the
     recommendation, and the report cannot see it.
   - **`geo_concentration`** — group the flagged line's units by `sales_org`. The report has no
     country column at all.
3. **Write the `decision` block.** Make the call the report frames, and fill all six fields:
   `headline`, `because`, `number`, `risk` (both directions), `counter` (the strongest honest case
   against yourself) and `trigger` (the pre-committed condition that would reverse it). Wrap the one
   phrase that matters most in each field in `*asterisks*`. Reading rule 5 applies to every sentence.
4. **Validate** `metrics/metrics.json` against `metrics/metrics.schema.json`. If it doesn't match, stop and
   say what's off.
5. **Verify against source (the trust check).** Pick at least one number and confirm it in the matching CSV
   in `data/` (e.g. an escalation ID in `exec_escalations.csv`, or a line's units in `demand_actuals.csv`).
   State which number you checked and that it matched.
6. **Explain, applying the reading rules below.** Lead with what changed and the one decision on the table.
7. **Build the dashboard:** write `dashboard/data.js` as `window.NORTHWIND_DATA = <contents of metrics.json>;`
   then open `dashboard/index.html`. (This is the "fill the template" step — you do it, no API key.)

## NORTHWIND's metric definitions (what the numbers mean HERE)

*Two metric definitions are filled in as examples (Revenue, Units) — plus the CRAFT flag below. Complete the three `→ YOUR TURN:` slots from `worksheet.md`.*

- **Revenue (reported)** = Σ(units sold this month × the model's list price), rolled up per line. This is
  **list-price contribution, NOT true gross margin** (the data has no per-SKU cost). Always say so.
- **Units** = units sold this month, per line. Compare month-over-month (MoM) against the prior month.
- **Defects** = → YOUR TURN: _(worksheet blank 1) what "defects" means for NORTHWIND. (Hint: the NCR
  count and units affected, by production line; it's a quality signal, not customer returns.)_
- **Marketing spend** = → YOUR TURN: _(worksheet blank 2) what marketing means here. (Hint: campaign
  budgets by channel; not cleanly attributable to one product line.)_
- **Escalations** = → YOUR TURN: _(worksheet blank 3) what an escalation is. (Hint: open P1/P2 items by
  severity and owning team.)_
- **The line to interrogate ("CRAFT flag")** = the line with **both** the highest list prices **and** the
  highest defects **per 1,000 units** this month (normalised, not raw count — a high-volume line can log
  the most NCRs at the lowest rate) → the line to question before scaling, instead of celebrating its
  revenue.

## Reading rules (NORTHWIND's "how we analyze" recipe)

*Two are filled in as examples. Complete the three `→ YOUR TURN:` slots from `worksheet.md`, in your own words.*

1. **Never read a line by revenue alone** — always pair its revenue with its defects and its MoM units.
2. **Every recommendation states the cost of being wrong** (warranty/rework exposure, or lost premium
   revenue if you cut the line).
3. → YOUR TURN: _(worksheet blank 4) what does each line get compared against? A total hides one bad
   line, and two months are not always the same length._
4. → YOUR TURN: _(worksheet blank 5) which line gets flagged, and what happens before spend is approved
   on it?_
5. → YOUR TURN: _(worksheet blank 6) what does the analyst do when a number can't support the claim?
   Name the limit next to the number instead of faking it._

## The decision this month
CRAFT earns premium revenue on low volume but carries the most defects. The report frames the call as
**rework the line first** vs **put more Q3 marketing behind it** — back your answer with the number, state
the cost of being wrong, and name what the data can't tell you.
