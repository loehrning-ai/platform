# NORTHWIND · Monthly Performance Report · September 2023 (FY24 Q2)

*Prepared for the NORTHWIND leadership team. All figures are list-price contribution from the September data;
see §6 for what the numbers do and don't mean. NORTHWIND is a fully synthetic company.*

## 1. Headline
September delivered **€21.69M (€21,687,544)** of list-price revenue on **139,056 units**, up **~26%** on August
(€17.23M / 110,373 units). A strong close to FY24 Q2. Growth was broad: all seven shipping
lines grew units month-over-month. The one thing that needs a decision is not the top line. It is **CRAFT**,
our premium kitchen line, which is our **second-largest revenue line on one of the lowest volumes** and carries
**the most quality defects of any line**.

## 2. Revenue by line (list-price contribution)
| Line | Family | Units | Revenue | Avg price | MoM units |
|------|--------|------:|--------:|----------:|----------:|
| AURA | AUDIO | 42,197 | €7,962,953 | €188.71 | +26.1% |
| **CRAFT** | **KITCHEN** | **9,162** | **€4,124,238** | **€450.15** | **+22.4%** |
| ECHO | AUDIO | 19,256 | €3,162,514 | €164.24 | +28.5% |
| NEST | SMARTHOME | 16,770 | €2,212,590 | €131.94 | +24.5% |
| BREW | KITCHEN | 31,244 | €2,068,796 | €66.21 | +27.9% |
| PULSE | WEARABLES | 15,479 | €1,910,901 | €123.45 | +20.7% |
| BEAM | SMARTHOME | 4,948 | €245,552 | €49.63 | +33.4% |

AURA leads on volume and revenue. **CRAFT is the story**: only 9,162 units (the second-lowest volume),
yet **€4.12M revenue**, because its average price (€450) is 2.4× AURA's. Premium revenue, thin volume.

Price bands differ sharply by line. **CRAFT lists at €199 to €699**, the widest and highest band we sell,
against AURA €89 to €399, ECHO €79 to €219, NEST €39 to €219, PULSE €59 to €199, BREW €49 to €89 and BEAM
€19 to €89. CRAFT's €450 average sits high in its band, which is exactly why its €4.12M lands on one of the
company's thinnest volumes (only BEAM ships fewer units).

## 3. Quality: defects by line (NCR feed)
| Line | NCRs (Sep) | Units affected | NCRs per 1,000 units |
|------|-----------:|---------------:|---------------------:|
| **CRAFT** | **23** | 2,832 | **2.51** |
| NEST | 19 | 1,769 | 1.13 |
| AURA | 18 | 2,456 | 0.43 |
| PULSE | 11 | 1,321 | 0.71 |

August: CRAFT 24 NCRs, 3.21 per 1,000 units.

**CRAFT has the most non-conformance records this month** (23), and it also had the most in August (24).
This is not a one-month blip. On a line that ships only ~9k units, that defect intensity is high.

## 4. Marketing
Campaign budgets on the books total **€2.03M** across all periods. They are set per campaign and cannot be
attributed to one product line or one month.

## 5. The decision on the table
**CRAFT: rework the line first, or put more Q3 marketing behind it now?** CRAFT earns **€4.12M** on just
**9,162 units** at a **€450 average price**, and carries **the most defects two months running**.

**The VP of Sales is pushing for more spend:** *"CRAFT is our premium line: €4.12M on one of our thinnest
volumes, and units up 22.4 % on August. And quality is already turning: CRAFT's defects fell from 3.21 to
2.51 per 1,000 units. No other line improved. Let's move more of Q3's marketing budget behind it now."*

Quality's view: CRAFT logged 23 NCRs in September and 24 in August, the most of any line in both months.
More demand for CRAFT means more CRAFT production. Decide which comes first: rework or marketing.

## 6. What this report can't tell you
- **No true gross margin.** "Revenue" here is units × list price. The data has no per-SKU cost, so CRAFT's
  real profitability is unknown. Its high price is not the same as high margin.
- **Defects are not customer returns.** The NCR feed is *production* quality by line; there is no order to
  line link to measure customer returns per line. Treat NCRs as a leading quality signal, not a returns rate.
- **Marketing isn't per-line.** Budgets are campaign-level and not cleanly month- or line-attributable.
- **The month-over-month comparison isn't like-for-like.** September's slice holds five weekly buckets;
  August's holds four. Per week, units grew **+0.8%** and revenue **+0.7%**, so most of the headline
  **+26%** is the extra week, not demand. Treat MoM totals as directional and compare per-week, or
  compare the same number of weeks.
