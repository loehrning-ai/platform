# NORTHWIND · Monthly Performance Report · August 2023 (FY24 Q2)

*Prior-month baseline for the September review. Figures are list-price contribution from the August data;
same caveats as §6 of the September report apply. NORTHWIND is a fully synthetic company.*

## 1. Headline
August delivered **€17.23M** of list-price revenue on **110,373 units**, a solid mid-Q2 month ahead of the
September push. AURA led; **CRAFT** already stood out as the highest-priced line carrying the **most quality
defects (24 NCRs)**, a flag we said we'd watch into September.

## 2. Revenue by line (list-price contribution)
| Line | Family | Units | Revenue | Avg price |
|------|--------|------:|--------:|----------:|
| AURA | AUDIO | 33,471 | €6,292,609 | €188.00 |
| **CRAFT** | **KITCHEN** | **7,488** | **€3,301,112** | **€440.85** |
| ECHO | AUDIO | 14,989 | €2,468,211 | €164.67 |
| NEST | SMARTHOME | 13,467 | €1,781,853 | €132.31 |
| BREW | KITCHEN | 24,421 | €1,617,469 | €66.23 |
| PULSE | WEARABLES | 12,829 | €1,573,871 | €122.68 |
| BEAM | SMARTHOME | 3,708 | €198,522 | €53.54 |

## 3. Quality: defects by line (NCR feed)
| Line | NCRs (Aug) | Units affected |
|------|-----------:|---------------:|
| **CRAFT** | **24** | 2,324 |
| NEST | 12 | 1,587 |
| AURA | 11 | 1,779 |
| PULSE | 9 | 1,099 |

CRAFT already carries the most defects. **The September report should confirm whether this is chronic.**

## 4. Marketing
Campaign budgets on the books (all periods) total **€2.03M**, led by webinar, paid search, and trade
show. (Campaign-level and multi-period; not cleanly per-line or per-month, see the September report §6.)

## 5. Watch into September
CRAFT's price-vs-defect profile. If the defect load repeats in September, it becomes a decision, not a note.

## 6. Caveats
Same as the September report: list-price revenue (not gross margin), NCRs are production quality (not
customer returns), marketing budgets are not per-line.
