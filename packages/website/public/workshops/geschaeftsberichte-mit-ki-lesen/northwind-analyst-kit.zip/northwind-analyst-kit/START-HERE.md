# Start here

NORTHWIND's September report asks for more marketing money behind CRAFT, its premium kitchen line. The VP
of Sales backs the request with two numbers: CRAFT units grew 22.4 %, and CRAFT defects fell from 3.21 to
2.51 per 1,000 units. Both are computed correctly. Neither says how it was counted.

A metric means only what its card says. Pin down numerator, denominator and period, trace one figure to its
rows, then decide.

In this kit you write those definitions down as metric cards, have Claude apply them through a Skill, trace
one figure to its rows and make the call. About an hour. NORTHWIND and all its data are synthetic.

You need the Claude desktop app with Claude Code (included in Pro and Max) and this folder, unzipped. No code,
no API key. Without Claude Code, see "Without Claude Code" at the end.

## Setup (2 minutes)
1. Unzip. Open the folder that has this file at its top level. If there is a folder of the same name inside,
   go one level in. Claude finds the Skill only from the right folder.
2. In the Claude desktop app, open Code and choose this folder.
3. Claude asks before it reads or writes a file. Allow it.

## What is in the folder
| Path | What it is | Step |
|---|---|---|
| `reports/2023-09-monthly-report.md` | The report under review. §5 is the VP's argument. | 1 |
| `reports/2023-08-monthly-report.md` | The month before. | 2 |
| `data/ncr_records.csv` | 127 non-conformance records (NCRs): date, machine, type, units affected, scrap or rework. | 2 |
| `data/demand_actuals.csv` | 2,115 weekly shipment rows: week_start, sku, sales_org, units_actual. | 2, 3 |
| `data/product_lines.csv` | 23 models with list price. | 3 |
| `data/company-backstory.md` | Who NORTHWIND is. | 1 |
| `metric-cards.md` | Your worksheet: one card filled in, two open, one release condition. | 2 |
| `.claude/skills/northwind-metrics/` | The Skill Claude runs. Hidden folder; leave it where it is. | 3, 4 |
| `metrics/metrics.schema.json` | The shape of the numbers the Skill writes. | 4 |
| `dashboard/` | Empty until step 4. | 4 |
| `claude/kennzahlen-steckbrief/` | The same method without NORTHWIND, for your own reports. | 5 |
| `project-instructions.md` | The same method as project instructions, for claude.ai Projects. | after |

## Step 1 · Read the argument (5 min)
> Read data/company-backstory.md and reports/2023-09-monthly-report.md. List every number the VP uses in §5
> to argue for more CRAFT marketing, with the section it comes from and whether the report says how it was
> counted. Do not judge them yet.

Expected: €4.12M revenue (§2), units +22.4 % on August (§2), defects 3.21 → 2.51 per 1,000 units (§3).
The report says how none of the three was counted.

Before you look at the data, write down your answer: did CRAFT's quality get better, stay the same or get
worse in September? In the room we vote.

## Step 2 · Pin the definitions down (15 min)
> Open metric-cards.md. For each card marked OPEN, compute every option listed there for August and
> September from the files in data/. One line per option: August, September, files and columns used.
> Do not choose for me.

Expected:

| Card | Option | Aug | Sep |
|---|---|---|---|
| Defects | A. NCR records per 1,000 units shipped | 3.21 | 2.51 |
| Defects | B. Affected units per 1,000 units shipped | 310 | 309 |
| Defects | C. Scrapped units per 1,000 units shipped | 123 | 168 |
| Demand | A. Month total, units | 7,488 | 9,162 |
| Demand | B. Per shipping week, units | 1,872 | 1,832 |

Month total: +22.4 %. Per shipping week: −2.1 %. August holds four week_start values, September five.

Test the defect options before you choose:
> Suppose Quality merged September's CRAFT NCRs from the same machine in the same week into one record.
> What would each defect option show?

Expected: 17 records instead of 23, so option A falls to 1.86 per 1,000. B and C do not move. Not one part
changed.

Then choose:
> My choices: Defects = <option>, because <one sentence>. Demand = <option>, because <one sentence>.
> Release condition = <condition>. Write the three into the northwind-metrics Skill under "Metric cards",
> word for word, and show me only that section.

## Step 3 · Run the Skill and trace one figure (10 min)
> Use my northwind-metrics Skill on reports/2023-09-monthly-report.md. Then trace CRAFT revenue €4,124,238
> to its rows: file, columns, filter, number of rows, sum.

Expected: 95 rows in demand_actuals.csv (sku starts with NW-CRAFT-, week_start 2023-09-02 to 2023-09-30).
Three models: E1 €449 × 3,258, E2 €699 × 2,973, G1 €199 × 2,931. Sum €4,124,238. The trace also shows what
"revenue" means here: units × list price. No discounts, no cost.

## Step 4 · Dashboard and decision (15 min)
> Write the dashboard data and tell me to open it. Then make the call on CRAFT in the Skill's six decision
> fields. In "counter", give the values the definitions I did not choose would produce.

Expected: every tile shows its value and a "Counted as" line from your cards. With scrapped units and
per-week demand the call is rework first: scrap rose from 123 to 168 per 1,000 units shipped (1,539 units,
€691,011 at the average list price of €449) and demand per shipping week fell 2.1 %. With NCR records and
month totals the same data supports the VP. The decision names the card it rests on.

## Step 5 · One metric of your own (10 min)
> Open claude/kennzahlen-steckbrief/SKILL.md. Ask me about one metric from my own monthly report, one field at a
> time: decision, numerator, denominator, period, source, limit, trigger. Write the card into
> claude/kennzahlen-steckbrief/references/steckbriefe.md. I describe the metric. I do not paste company data.

The Skill's text is German with an English word list; Claude answers in your language. Read a Skill before
you install it. This one is short plain text.

## Install the Skill outside this folder
Zip the `kennzahlen-steckbrief` folder so the folder itself sits at the top of the zip, or download the same
file from loehrning.ai/skills/kennzahlen-steckbrief.zip. Then:

### claude.ai and the desktop app

1. In “Settings”, “Capabilities”, turn on “Code execution and file creation” (“Create and edit files” in the new layout).
2. Open claude.ai/customize/skills.
3. Choose “+”, then “Create skill”, then “Upload a skill”, and pick the zip file.
4. Turn the skill on.

On Team and Enterprise an admin can turn user skills off.

### Claude Code

For all projects: `unzip kennzahlen-steckbrief.zip -d ~/.claude/skills/`

For this repository only: `unzip kennzahlen-steckbrief.zip -d .claude/skills/`

SKILL.md then sits in skills/kennzahlen-steckbrief/ (global or in the repository). Type /kennzahlen-steckbrief or just ask.

With the same claude.ai login, Claude Code (v2.1.273 or later) loads the skills you turned on in claude.ai by itself; do not unzip them there a second time. With an API key or Bedrock: unzip.

### Project instructions

1. Open claude.ai/projects and choose “New Project”.
2. On the right, open “Set project instructions”, paste the text, choose “Save instructions”.
3. Add the kit files to the project knowledge with “+”.

Projects work on every plan, up to five on Free.

## Next month
Put the October report into reports/ and repeat steps 3 and 4. The cards stay; the numbers change.

## If something does not match
- Different values in step 2: ask "Which rows did you include? Show the filter." The usual cause is a week
  assigned to the wrong month.
- Claude picks a definition for you: "Do not choose. Show all options side by side."
- The Skill does not run: say "use my northwind-metrics Skill".
- The dashboard stays empty: check that dashboard/data.js was written, then ask again.

## Without Claude Code
claude.ai Projects work on every plan, Free included. Create a project, paste the text of
project-instructions.md into its instructions, and upload both reports and the three CSVs as project
knowledge. Steps 1, 2, 3 and 5 work in the chat. Step 4 has no dashboard there; ask for the six decision
fields as text. In step 5 Claude writes the metric card as text in the chat; copy it into the project
instructions under "Our metric cards".
