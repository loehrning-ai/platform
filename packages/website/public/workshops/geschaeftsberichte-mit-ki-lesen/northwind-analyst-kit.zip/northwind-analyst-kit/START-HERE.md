# Start here — build your AI analyst

You'll turn one company's monthly report into a **metrics Skill you author**, a **dashboard that fills
itself**, and **one decision** — all in the Claude desktop app, on your subscription. **No API key. No
coding.**

> The course's authoritative overview (what it is, the full curriculum, constraints, file map) lives in
> the top-level `README.md` of the course folder. This page is your hands-on run.

---

## Get set up (2 minutes — do this first)

1. **Unzip the kit somewhere you can find it** (Desktop or Documents). On Windows, right-click →
   *Extract All*. **Open the folder that has this `START-HERE.md` at the top level** — if you see a
   folder *inside* a folder with the same name, go one level in. (Getting this wrong is the #1 stumble:
   Claude finds your Skill only when it's looking at the right folder.)
2. **Open the Claude desktop app** and switch to the **Claude Code** surface. Point it at the folder you
   just unzipped (Code tab → open a folder — or drag the unzipped folder onto the app window). No terminal
   needed — it's a panel in the app.
3. **Claude will ask permission** the first time it reads a file, writes one, or opens the dashboard — a
   little *"Allow?"* prompt. **Click Allow.** That's expected every time; it's Claude asking before it
   touches your folder.
4. **Peek at the empty dashboard once:** double-click `dashboard/index.html`. It's blank on purpose —
   that's the page your numbers will fill in prompt 4.

There's a hidden folder called `.claude` in the kit — that's your Skill. You don't need to open it; just
don't drag files out of this folder one by one (that can leave the Skill behind).

---

## The five prompts

Send these in order. After each, read what Claude did before moving on. (Full copies in `PROMPTS.md`.)

### 1 · Ground it
> "Read `data/company-backstory.md` and `reports/2023-09-monthly-report.md`. In two sentences: who is
> NORTHWIND, and what decision is this month's report building toward?"

*What to expect:* Claude learns the company and surfaces the **CRAFT** question — a premium line with the
most defects. This is your "company brain."
*If it doesn't match:* if Claude talks about a different company or can't find the files, you opened the
wrong folder (see setup step 1).

### 2 · Author your metrics Skill
First open `worksheet.md` and skim it. Then:
> "Open `worksheet.md`. Ask me the blanks one at a time, I'll answer in plain English. Then complete the
> **northwind-metrics** Skill (`.claude/skills/northwind-metrics/SKILL.md`) from my answers: fill in the blank
> metric definitions and reading rules, matching the worked examples (Revenue, Units), plus the CRAFT
> flag. Show me the finished Skill."

*What to expect:* Claude asks you what "defects", "marketing", and "escalations" mean for NORTHWIND and how to
read the month. You answer from the worksheet's hints — **in your own words**. Claude writes your answers
into the Skill. **You just taught Claude how this company reads its numbers.** (Already filled the
worksheet yourself? Just say "use my worksheet answers to complete the Skill.")
*If it doesn't match:* if Claude writes code or asks for an API key, re-prompt: "just fill in the Skill's
markdown definitions from my plain-language answers."

### 3 · Run your Skill on the report
*(First, the contrast — optional but worth it.)* Ask once **without** your Skill:
> "Don't use any Skill for this one. With your own eyes, eyeball the report: how did NORTHWIND do this month?"

Notice it's a generic summary; everyone in the room gets a slightly different one. Now run **your** Skill:
> "Now use my **northwind-metrics** Skill on `reports/2023-09-monthly-report.md`: extract this month's numbers
> into `metrics/metrics.json` following my reading rules, and verify one number against the source CSV in
> `data/`. Show me total revenue and units, revenue and defects by line, and the one line to interrogate."

*What to expect:* your Skill's **CRAFT flag** fires — €4.12M on 9,162 units, the most defects — and
Claude names which CSV number it checked. Same report, but now it's read *your* way, consistently.
*If it doesn't match:* if a number looks off, that's the lesson working — ask "which file and column did
that come from?" and check it yourself.

### 4 · Build the dashboard
> "Build the dashboard from this month's metrics and open it."

*What to expect:* the empty dashboard you saw at the start fills with the real numbers — revenue by line,
defects, marketing, open escalations, and "the call on the table." **You** told Claude *what* you wanted;
your Skill carried the *how*. No key, no code.
*If it doesn't open:* just double-click `dashboard/index.html` in your file browser.

### 5 · Make the call
The report's VP of Sales wants to pour more Q3 budget into CRAFT. **Decide for yourself first** (rework
first, or put more Q3 marketing behind it?), then:
> "The VP of Sales wants more Q3 marketing budget behind CRAFT. Using my Skill's reading rules and this
> month's numbers, make the call: rework CRAFT first, or put more Q3 marketing behind it? Give the number that backs it,
> the cost of being wrong, and what this data can't tell us. Then argue the opposite as hard as you can."

*What to expect:* a cited, defensible call that disagrees with an authority using the numbers — plus the
honest caveats (no true margin, defects ≠ customer returns). **That's the whole point: a decision, not a
prettier report.**
*If it doesn't match:* if Claude sits on the fence or won't disagree with the VP, push it: "Pick one —
rework first, or put more Q3 marketing behind it — and commit. Give the single number that decides it, then argue the other side."

---

### Do it again next month
Drop the new month's report into `reports/` and re-run prompts 3–5 — swap the report filename in prompt 3
(and the month in prompt 5 if it has moved on) for the new one. Same Skill, your definitions, fresh numbers. **That's
the living system** — you built it once, it repeats.

*Want to try it right now?* Run prompt 3 against `reports/2023-08-monthly-report.md` — the prior month is
already in the kit. Your Skill fires the same way and still flags CRAFT (24 NCRs). Two things come back thinner, and both are correct.
August is the **earliest month in the data**, so there's no prior month to compare against — the MoM
column shows `—`. And August's report is a leaner document than September's: it doesn't state
escalation status, so your Skill's verify rule sends it to `data/exec_escalations.csv`, where all four
August items are already RESOLVED — Open P1/P2 shows 0. A good analyst notices where the data starts
and stops, and where a source is simply thinner.

### Case 2 — leave the sandbox (in the session, or at home)
NORTHWIND is synthetic; the recipe isn't. Open **`meta-quarterly/TASK.md`** and run the same motion on
**Meta's real, public Q2 2026 results**: Claude fetches the public earnings release live, you define six metrics in
plain English, extract the quarter, and — the advanced step — have Claude *design* a one-page
dashboard from scratch instead of filling a template. Revenue +28%, operating income −8%: a real
CRAFT pattern, with a real call on the table.

### Make it yours
Swap NORTHWIND's backstory and report for your own company's, redo the worksheet with *your* metrics, and run
the same five prompts. The blank `your-company-skill/` folder is your starting template.

---

### Something's off?
- **The Skill isn't triggering** — say it explicitly: "use my northwind-metrics Skill."
- **You clicked Deny by accident** — re-send the prompt and click **Allow**.
- **`metrics/metrics.json` is missing** — re-run prompt 3.
- **The dashboard is blank after prompt 4** — check `dashboard/data.js` got written, then re-send "build the dashboard."
