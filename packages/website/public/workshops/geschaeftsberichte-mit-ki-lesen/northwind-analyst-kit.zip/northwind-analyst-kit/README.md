# NORTHWIND analyst kit

A one-hour exercise: pin down what a report's numbers mean, have Claude apply your definitions, trace one
figure to its rows, decide. Start with START-HERE.md.

A metric means only what its card says. Pin down numerator, denominator and period, trace one figure to its
rows, then decide.

NORTHWIND GmbH, its people and all data are synthetic. No real company is described.
Steps 1 to 5 need Claude Code (Pro or Max). The Skill in kennzahlen-steckbrief/ works on every plan with
Skills; START-HERE.md also describes a route through claude.ai Projects, Free plan included.

Made by loehrning.ai.
