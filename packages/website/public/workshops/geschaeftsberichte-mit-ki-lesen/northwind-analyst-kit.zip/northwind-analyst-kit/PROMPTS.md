# Prompt library

Copy-paste these into the Claude desktop app (Claude Code surface), pointed at this folder. On your
subscription — **no API key, no coding**. Read `START-HERE.md` first for setup and what to expect.

## The five prompts

**1 · Ground it**
```
Read data/company-backstory.md and reports/2023-09-monthly-report.md. In two sentences: who is NORTHWIND, and
what decision is this month's report building toward?
```

**2 · Author your metrics Skill** (open `worksheet.md` first)
```
Open worksheet.md. Ask me the blanks one at a time, I'll answer in plain English. Then complete the
northwind-metrics Skill (.claude/skills/northwind-metrics/SKILL.md) from my answers: fill in the blank metric
definitions and reading rules, matching the worked examples (Revenue, Units), plus the CRAFT flag. Show
me the finished Skill.
```

**3 · Run your Skill on the report**
```
Use my northwind-metrics Skill on reports/2023-09-monthly-report.md: extract this month's numbers into
metrics/metrics.json following my reading rules, and verify one number against the source CSV in data/.
Show me total revenue and units, revenue and defects by line, and the one line to interrogate.
```

**4 · Build the dashboard**
```
Build the dashboard from this month's metrics and open it.
```

**5 · Make the call**
```
The VP of Sales wants more Q3 marketing budget behind CRAFT. Using my Skill's reading rules and this
month's numbers, make the call: rework CRAFT first, or put more Q3 marketing behind it? Give the number that backs it, the
cost of being wrong, and what this data can't tell us. Then argue the opposite as hard as you can.
```

## The contrast (before prompt 3 — worth 60 seconds)
Ask the metrics question once **without** the Skill, then with it — compare the two answers.
```
Don't use any Skill for this one. With your own eyes, eyeball the report: how did NORTHWIND do this month?
```
Generic, and different for everyone. Then run prompt 3: your reading rules fire, the same way, every time.

## Three harder ones (once your Skill works)
These go past extracting numbers: the first two make Claude check work a human did, the third has it
write a small program. Same folder, same Skill, still no code from you.

**A · Audit the report against its own data**
```
Take nothing in reports/2023-09-monthly-report.md on trust. Recompute every figure in it from the CSVs in
data/, then show me a table with four columns: the report's number, your number, the file and rows you
used, and whether they match. Flag anything that does not.
```

**B · Break the headline**
```
The report leads with +26% revenue month over month. Before I repeat that number to a board, check whether
August and September are even comparable. Recompute the comparison the fairest way you can from
data/demand_actuals.csv, show your working, and tell me how much of the +26% survives.
```
*(September holds five weekly buckets, August four. Per week, units grew +0.8%.)*

**C · Ask for a tool, not an answer**
```
Build me dashboard/whatif.html: a one-page tool with two sliders, CRAFT price change and CRAFT defect
rate, that recomputes CRAFT revenue and re-runs my Skill's flag rule live as I drag them. Read the
starting numbers from metrics/metrics.json. Plain HTML, CSS and JavaScript in one file, no libraries, and
open it when it is done.
```

## Trust / pressure-test prompts (use any time)
```
For every number in your last answer, show me exactly which file and column it came from. Which did you
infer rather than read?
```
```
Argue the opposite recommendation as convincingly as you can. What would have to be true for it to win?
```

## Bonus — repeat it next month
*(Add the new report file to `reports/` first.)*
```
Here's next month's report in reports/. Re-run my northwind-metrics Skill and rebuild the dashboard, then tell
me what changed vs. this month and whether the CRAFT decision still holds.
```

## Case 2 — a real company: Meta's latest quarter (in the session)
The full task, its three prompts (M1 fetch · M2 define + extract · M3 generate the dashboard), and
the honest limits live in **`meta-quarterly/TASK.md`**. Same recipe, real public numbers, fetched
live from the SEC filing — nothing to download.

## Bonus — connect live data (Claude Connectors, still no API key) — watch, don't run
*(This one only works if the file is in your own Drive — it's a demo of where next month's report could
come from, not a step to run today.)*
```
Connect to my Google Drive, find the latest NORTHWIND monthly report, bring it in, and run my northwind-metrics
Skill on it.
```
