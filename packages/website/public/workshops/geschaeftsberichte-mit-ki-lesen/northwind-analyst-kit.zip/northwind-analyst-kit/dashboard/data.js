/* This file is written by your northwind-metrics Skill (prompt: "build the dashboard").
   It starts empty on purpose — the dashboard shows "no data" until your Skill fills it. */
window.NORTHWIND_DATA = null;
