# Worksheet — teach the Skill how YOUR company reads its numbers

Answer in plain language. This is what Claude turns into your metrics Skill.

**1 · What do we track each month?**
→ YOUR TURN: _(list your handful of metrics — e.g. revenue, units, quality, spend, open issues)_

**2 · Where does each number come from, and what does it mean HERE?**
Write one plain sentence per metric — including any honest limits (e.g. "revenue = list price, not margin").
- → YOUR TURN: _______________________________________________________________________________
- → YOUR TURN: _______________________________________________________________________________
- → YOUR TURN: _______________________________________________________________________________

**3 · How do we analyze it? (reading rules)**
The judgment your team applies — e.g. "never read a line by revenue alone", "compare to last month".
- → YOUR TURN: _______________________________________________________________________________
- → YOUR TURN: _______________________________________________________________________________

**4 · What can this data NOT tell us?** (these become the dashboard's honesty caveats)
- → YOUR TURN: _______________________________________________________________________________

**5 · What decision does the month feed?**
→ YOUR TURN: _(the one call this report should help you make)_
