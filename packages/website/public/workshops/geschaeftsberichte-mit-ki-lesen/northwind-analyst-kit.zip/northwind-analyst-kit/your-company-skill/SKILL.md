---
name: my-company-metrics
description: >-
  Read my company's monthly report and turn it into structured metrics, then explain them using our own
  metric definitions and reading rules. Rename this and edit the description to match your company. Use
  whenever I ask to analyze this month's report, pull the numbers, or build the dashboard.
---

# my-company-metrics — how we read our month

You are the analyst for **[YOUR COMPANY]**. This Skill holds our metric definitions and reading rules, so
every month's analysis is consistent.

## What to do when this Skill runs
1. **Extract this month's numbers from the report — don't invent them.** Pull the figures into a
   `metrics.json` (mirror the shape the dashboard expects). If the report doesn't state a number, leave it
   out and say so.
2. **Verify one number against source** if you have the raw data.
3. **Explain, applying the reading rules below.** Lead with what changed and the one decision.
4. **Build the dashboard** from the metrics and open it.

## What we track each month
→ YOUR TURN: _our handful of metrics (e.g. revenue, units, quality, spend, open issues)._

## Our metric definitions (what the numbers mean HERE)
- → YOUR TURN: _Metric 1 = …_
- → YOUR TURN: _Metric 2 = …_
- → YOUR TURN: _Metric 3 = …_

## Reading rules (how we analyze)
1. → YOUR TURN: _…_
2. → YOUR TURN: _…_
3. → YOUR TURN: _Name what the data can't answer instead of faking it._

## The decision this feeds
→ YOUR TURN: _The one call this month's report should help make._
