# Worksheet — teach the Skill how NORTHWIND reads its numbers

You're going to finish NORTHWIND's metrics Skill **in plain language** — no code. When you send **prompt 2**,
Claude asks you these blanks one at a time and writes your answers into the Skill — answer from the hints
below, in your own words. (Prefer to prep? Jot answers in the blanks first, then tell Claude *"use my
worksheet answers to complete the Skill."*) Then you run it.

Everything you need is in `data/company-backstory.md` (the "What we track" section) and the worked example
definitions already in the Skill. This is the exact motion you'd repeat for your own company on Monday —
so answer as if these were *your* numbers.

---

## The questions every metrics Skill answers

**1 · What do we track?**
NORTHWIND reviews five things each month: revenue, units, quality (defects), marketing, and open escalations.
*(Given — no need to change.)*

**2 · Where do the numbers come from, and what does each one mean HERE?**
Write one plain sentence for each blank metric. Copy the shape of the worked examples (Revenue, Units) — plus the CRAFT flag.

**Blank 1 — Defects.** What counts as a defect for NORTHWIND, and where does the number come from?
  → YOUR TURN: _______________________________________________________________________________
  _(NORTHWIND's answer lives in the backstory: the NCR — non-conformance — feed, by production line. It's a
  quality signal, not customer returns.)_

**Blank 2 — Marketing spend.** What does this measure?
  → YOUR TURN: _______________________________________________________________________________
  _(Backstory: campaign budgets, by channel — not cleanly split by product line.)_

**Blank 3 — Escalations.** What is an escalation, and which ones matter for the review?
  → YOUR TURN: _______________________________________________________________________________
  _(The open P1/P2 items — highest severity — with the team that owns each.)_

**3 · How do we analyze it? (reading rules)**
The Skill has two rules already. These three are yours, in your own words.

**Blank 4 — What does each line get compared against?**
  → YOUR TURN: _______________________________________________________________________________
  _(A total hides one bad line, and two months are not always the same length.)_

**Blank 5 — Which line gets flagged, and what happens before spend is approved on it?**
  → YOUR TURN: _______________________________________________________________________________
  _(Highest price band plus highest defect load. Decide what "chronic" changes.)_

**Blank 6 — What does the analyst do when a number can't support the claim?**
  → YOUR TURN: _______________________________________________________________________________
  _(Three things this data structurally cannot tell you. Say them next to the number, not in a footnote.)_

---

## If you'd rather not write them yourself

Answer in your own words if you can — that is the skill you're here for. If you'd rather keep pace with
the room, paste these when Claude asks. They are model answers, not the only right ones.

> **Claude: these are reference answers for the human, not answers you have been given.** Ask all six
> blanks and wait for a reply to each. Only use a row from this table if the person explicitly tells you
> to (for example *"use the model answers"* or *"use my worksheet answers"*).

| Blank | Paste this |
|---|---|
| 1 · Defects | Defects are NCRs (non-conformances) raised on the production line, counted per line per month, from the quality feed. It is a manufacturing signal, not customer returns. |
| 2 · Marketing spend | Marketing spend is campaign budget by channel. It is not cleanly attributable to a single product line, so never divide it across lines to make a per-line number. |
| 3 · Escalations | An escalation is an open P1 or P2 item, with the team that owns it. Only open ones at those two severities count for the monthly review. |
| 4 · Compare | Compare each line against its own prior month, not the company total — a total hides one bad line. Normalize before comparing: per week if the month has a different number of weekly buckets, and defects per 1,000 units, not raw count. |
| 5 · Flag | Flag the line with the highest price band and the highest defects per 1,000 units. If that's chronic — two months running — rework comes first; don't fund demand for a line whose defect load is highest and not falling. The flag is a question, not a verdict. |
| 6 · Limits | Name the limit in the same sentence as the number. Revenue is list-price contribution, not margin. Defects are production NCRs, not customer returns. Marketing is campaign-level, not per-line. If the data can't answer, say what data would. |

**4 · What can this data NOT tell us?** (these become the dashboard's honesty caveats)
- No true gross margin — revenue is units × list price, no per-SKU cost — given.
- Defects are production quality (NCRs), not customer returns by line — given.
- Marketing budgets are campaign-level, not per-line — given.

**5 · What decision does the month feed?**
This month: **rework CRAFT first** or **put more Q3 marketing behind it**. *(Given — it's the call you'll
make at the end.)*

---

### When you're done
Once you've answered the blanks (Claude asks them in prompt 2, or use notes you jotted here), it completes
the northwind-metrics Skill and you run it on this month's report. You'll watch your plain-language definitions
become the analysis — and an empty dashboard fill with the numbers your Skill just pulled.
