# Start here — the guided run

Open this folder in the **Claude desktop app (Claude Code surface)** with a paid **Claude Pro or Max
subscription**. Product availability and sign-in behavior can change. Then send these **four prompts in
order**. After each, read what Claude did before moving on. (Full copies in `PROMPTS.md`.)

---

## 1 · Ground it
> "Read `data/company-backstory.md` and both files in `reports/`. In two sentences, tell me who NORDA is
> and what decision this month's report is building toward."

*What to expect:* Claude learns the company and surfaces the CRAFT question. This is the "company brain."

## 2 · Compute the metrics (run the Skill)
> "Use the **norda-metrics** skill to compute this month's numbers. Run its script, then show me: total
> revenue and units, revenue and defects by line, and the three things that matter most — following the
> skill's reading rules."

*What to expect:* Claude runs `.claude/skills/norda-metrics/compute_metrics.mjs`, writes
`metrics/metrics.json`, and explains it (never guessing the arithmetic). You should see CRAFT flagged:
€4.1M on 9,162 units, the most defects.

## 3 · Build the dashboard
> "Populate the dashboard: write `dashboard/data.js` from `metrics/metrics.json` (as
> `window.NORDA_DATA = …`), then open `dashboard/index.html` so I can see it."

*What to expect:* a loehrning-styled dashboard with the real numbers — revenue by line, defects by line,
marketing, escalations, and "the call on the table." This is the tool template Claude filled in — no key.

## 4 · Make the call
> "Make the decision: should NORDA **rework CRAFT** or **reallocate its marketing budget** for Q3? Give the
> number that backs it, the cost of being wrong, and state clearly what this data can't tell us."

*What to expect:* a cited, defensible recommendation — with the honesty caveats (no true margin, defects
≠ customer returns). That's the whole point: a decision, not a prettier report.

---

### Do it again next month
Drop in a new month of data and re-run prompts 2–4. If your Claude plan, workspace policy, region, and
connector permissions support Google Drive or email, you can instead connect an approved source and grant
access only to the required files. Connector availability and accessible file types vary. Same skill,
same definitions, fresh numbers. **That's the living system** — you built it once, it repeats itself.

### Make it yours
Swap NORDA's backstory and metric definitions for your own company (edit `data/company-backstory.md` and
the skill), point it at your own report, and run the same four prompts.
