---
name: norda-metrics
description: >-
  Compute NORDA Werke's monthly performance metrics (revenue by line, defects, marketing spend,
  escalations, the CRAFT flag) from the kit's data/ CSVs and write metrics/metrics.json — then read
  and explain them using NORDA's metric definitions. Use whenever the user asks to analyze the NORDA
  monthly report, compute this month's numbers, or build/refresh the dashboard.
---

# norda-metrics — how this company reads its month

You are the analyst for **NORDA Werke GmbH** (synthetic Augsburg consumer-electronics maker). This Skill
holds NORDA's metric definitions and the exact way to compute them, so every analysis is consistent.

## What to do when this Skill runs

1. **Compute — do not do the arithmetic by hand.** Run the deterministic script:
   ```
   node .claude/skills/norda-metrics/compute_metrics.mjs
   ```
   It reads `data/*.csv` and writes `metrics/metrics.json`. Report month = **September 2023 (FY24 Q2)**,
   prior month = August 2023 (for month-over-month).
2. **Validate** `metrics/metrics.json` against `metrics/metrics.schema.json`. If it doesn't match, stop
   and say what's off — never invent numbers.
3. **Read the context.** Skim `reports/2023-09-monthly-report.md` (and the August one for MoM) for the
   qualitative story behind the numbers.
4. **Explain, applying the reading rules below.** Lead with what changed and the one decision.
5. **To build the dashboard:** write `dashboard/data.js` as `window.NORDA_DATA = <contents of metrics.json>;`
   then open `dashboard/index.html`. (This is the "populate the template" step — Claude does it, no key.)

## NORDA's metric definitions (what the numbers mean HERE)

- **Revenue (reported)** = Σ(units sold this month × the model's `base_price_eur`), rolled SKU → line →
  family. This is **list-price contribution**, NOT true gross margin (the data has no per-SKU COGS). Say so.
- **Units** = units_actual from `demand_actuals.csv`, filtered to the month. MoM = vs. August.
- **Defects** = NCR count and units affected **by production line**, this month, from `ncr_records.csv`.
  This is the *quality* feed, not customer returns (there is no order→line link in the data). Say so.
- **Marketing spend** = campaign budgets by channel from `campaign_master.csv`. Budgets are campaign-level
  and not cleanly attributable to a single product line.
- **Escalations** = open items by severity (P1/P2/P3) and owner from `exec_escalations.csv`.
- **The CRAFT flag** = the line with both the highest list prices and the most defects this month → the
  line to interrogate before scaling.

## Reading rules (the "how we analyze" recipe)

1. **Never read a line by revenue alone.** Always pair revenue with its defects and its MoM units.
2. **Highest-defect + highest-price line ⇒ interrogate it**, don't celebrate its revenue.
3. **Compare to target and the prior month**, per line — company totals hide a single bad line.
4. **Every recommendation states the cost of being wrong** (e.g. warranty/rework exposure, or lost
   premium revenue if you cut the line).
5. **Flag what the data can't answer** — margin, customer returns-by-line — instead of faking it.

## The decision this month
CRAFT earns premium revenue on low volume but carries the most defects. Recommend **rework the line** or
**reallocate its marketing budget** for Q3 — with the number that backs the call and the caveats above.
