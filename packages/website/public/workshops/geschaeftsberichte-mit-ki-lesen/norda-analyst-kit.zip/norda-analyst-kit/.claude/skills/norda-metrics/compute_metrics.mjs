#!/usr/bin/env node
/* norda-metrics · compute_metrics.mjs
 * Deterministic metric computation for the NORDA Analyst Kit.
 * Reads ../../../data/*.csv, writes ../../../metrics/metrics.json.
 * Node stdlib only — no deps, no network, no API key. Claude Code runs this so the
 * numbers are exact and reproducible; the Skill (SKILL.md) orchestrates + explains.
 *
 * Usage (from the kit root):  node .claude/skills/norda-metrics/compute_metrics.mjs
 * Report month = September 2023 (FY24 Q2); August 2023 used for month-over-month.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const KIT = join(HERE, '..', '..', '..');            // kit root
const DATA = join(KIT, 'data');
const OUT = join(KIT, 'metrics', 'metrics.json');

const MONTH = process.argv[2] || '2023-09';   // report month (override: node compute_metrics.mjs 2023-08)
const PRIOR = (() => {                         // prior month (MoM), computed from MONTH
  const [y, m] = MONTH.split('-').map(Number);
  const d = m === 1 ? [y - 1, 12] : [y, m - 1];
  return `${d[0]}-${String(d[1]).padStart(2, '0')}`;
})();

// --- minimal RFC-4180-ish CSV parser (handles quoted fields with commas) ---
function parseCSV(text) {
  const rows = [];
  let row = [], field = '', inQ = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQ) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else inQ = false; }
      else field += c;
    } else {
      if (c === '"') inQ = true;
      else if (c === ',') { row.push(field); field = ''; }
      else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
      else if (c === '\r') { /* skip */ }
      else field += c;
    }
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows.filter(r => r.length > 1 || (r.length === 1 && r[0] !== ''));
}
function readTable(name) {
  const rows = parseCSV(readFileSync(join(DATA, name), 'utf8'));
  const head = rows[0];
  return rows.slice(1).map(r => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}
const round = (n, d = 0) => { const p = 10 ** d; return Math.round(n * p) / p; };
const eur = n => round(n);

// --- product master: (line|model_code) -> {family, price}; line -> family ---
const products = readTable('product_lines.csv');
const price = new Map();      // "LINE|MODEL" -> base_price
const lineFamily = new Map(); // LINE -> family
for (const p of products) {
  price.set(`${p.line}|${p.model_code}`, Number(p.base_price_eur));
  lineFamily.set(p.line, p.family);
}
const priceRange = {};        // LINE -> {min,max}
for (const p of products) {
  const v = Number(p.base_price_eur), l = p.line;
  priceRange[l] = priceRange[l] || { min: v, max: v };
  priceRange[l].min = Math.min(priceRange[l].min, v);
  priceRange[l].max = Math.max(priceRange[l].max, v);
}

// --- demand actuals: units + revenue by line, MONTH and PRIOR ---
const demand = readTable('demand_actuals.csv');
function salesByLine(monthPrefix) {
  const byLine = {};
  for (const d of demand) {
    if (!d.week_start || !d.week_start.startsWith(monthPrefix)) continue;
    const parts = d.sku.split('-');            // NW-LINE-MODEL-VARIANT-REGION
    const line = parts[1], model = parts[2];
    const units = Number(d.units_actual) || 0;
    const unitPrice = price.get(`${line}|${model}`) ?? 0;
    byLine[line] = byLine[line] || { line, family: lineFamily.get(line) || '?', units: 0, revenue_eur: 0 };
    byLine[line].units += units;
    byLine[line].revenue_eur += units * unitPrice;
  }
  return byLine;
}
const sep = salesByLine(MONTH);
const aug = salesByLine(PRIOR);
const revenue_by_line = Object.values(sep)
  .map(r => ({
    line: r.line, family: r.family, units: r.units, revenue_eur: eur(r.revenue_eur),
    avg_price_eur: r.units ? round(r.revenue_eur / r.units, 2) : 0,
    price_range_eur: priceRange[r.line] ? [priceRange[r.line].min, priceRange[r.line].max] : null,
    units_mom_pct: aug[r.line] && aug[r.line].units ? round((r.units - aug[r.line].units) / aug[r.line].units * 100, 1) : null,
  }))
  .sort((a, b) => b.revenue_eur - a.revenue_eur);
const totals = {
  revenue_eur: eur(revenue_by_line.reduce((s, r) => s + r.revenue_eur, 0)),
  units: revenue_by_line.reduce((s, r) => s + r.units, 0),
};

// --- quality: NCRs by line for MONTH ---
const ncr = readTable('ncr_records.csv');
const q = {};
for (const n of ncr) {
  if (!n.ncr_date || !n.ncr_date.startsWith(MONTH)) continue;
  q[n.line] = q[n.line] || { line: n.line, ncr_count: 0, qty_affected: 0 };
  q[n.line].ncr_count += 1;
  q[n.line].qty_affected += Number(n.qty_affected) || 0;
}
const quality_by_line = Object.values(q).sort((a, b) => b.ncr_count - a.ncr_count);

// --- marketing: spend by channel (all shipped campaigns) ---
const camp = readTable('campaign_master.csv');
const chan = {};
let mkt_total = 0;
for (const c of camp) {
  const b = Number(c.budget_eur) || 0;
  chan[c.channel] = (chan[c.channel] || 0) + b;
  mkt_total += b;
}
const marketing = {
  total_budget_eur: eur(mkt_total),
  by_channel: Object.entries(chan).map(([channel, spend_eur]) => ({ channel, spend_eur: eur(spend_eur) }))
    .sort((a, b) => b.spend_eur - a.spend_eur),
};

// --- escalations: MONTH, by severity + open P1/P2 ---
const esc = readTable('exec_escalations.csv');
const sev = {};
const openP12 = [];
for (const e of esc) {
  if (!e.raised_on || !e.raised_on.startsWith(MONTH)) continue;
  sev[e.severity] = (sev[e.severity] || 0) + 1;
  if ((e.severity === 'P1' || e.severity === 'P2')) {
    openP12.push({ id: e.escalation_id, severity: e.severity, title: e.title, owner_team: e.owner_team, status: e.status });
  }
}
const escalations = { by_severity: sev, open_p1_p2: openP12 };

// --- the CRAFT flag: highest price line AND highest defects ---
const maxPriceLine = Object.entries(priceRange).sort((a, b) => b[1].max - a[1].max)[0][0];
const topDefectLine = quality_by_line[0]?.line;
const craftRow = revenue_by_line.find(r => r.line === 'CRAFT');
const craft_flag = {
  line: 'CRAFT',
  highest_price_line: maxPriceLine === 'CRAFT',
  highest_defect_line: topDefectLine === 'CRAFT',
  price_range_eur: priceRange.CRAFT ? [priceRange.CRAFT.min, priceRange.CRAFT.max] : null,
  ncr_count: q.CRAFT ? q.CRAFT.ncr_count : 0,
  units: craftRow ? craftRow.units : 0,
  revenue_eur: craftRow ? craftRow.revenue_eur : 0,
  reason: 'CRAFT carries the highest list prices and the most quality defects this month — interrogate before scaling.',
};

const metrics = {
  company: 'NORDA Werke GmbH',
  month: MONTH, prior_month: PRIOR, currency: 'EUR',
  generated_note: 'Deterministic output of norda-metrics/compute_metrics.mjs — figures computed from data/, not estimated.',
  totals, revenue_by_line, quality_by_line, marketing, escalations, craft_flag,
  caveats: [
    'Revenue is list-price contribution (units x base price), NOT true gross margin — the data has no per-SKU COGS.',
    'Defects/returns come from the manufacturing quality (NCR) feed by production line, NOT customer returns — there is no order->line item link in the data.',
    'Marketing budgets are campaign-level and not cleanly attributable to a single product line.',
  ],
};

writeFileSync(OUT, JSON.stringify(metrics, null, 2) + '\n');
console.log(`metrics.json written: €${totals.revenue_eur.toLocaleString()} revenue, ${totals.units.toLocaleString()} units, ${quality_by_line.length} lines with defects.`);
console.log(`CRAFT: highest price=${craft_flag.highest_price_line}, highest defects=${craft_flag.highest_defect_line}, ${craft_flag.ncr_count} NCRs, ${craft_flag.units} units, €${craft_flag.revenue_eur.toLocaleString()}.`);
