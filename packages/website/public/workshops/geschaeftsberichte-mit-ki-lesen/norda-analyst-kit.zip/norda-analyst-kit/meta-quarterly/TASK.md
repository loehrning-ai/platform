# Case 2 — the same recipe on a real company

You just built an analyst for NORDA — a synthetic company. Now leave the sandbox: **Meta Platforms'
latest quarterly results are public**, filed with the SEC on July 29, 2026. Same five questions, same
motion — real numbers, fetched live. Nothing in this folder ships pre-filled: Claude fetches the
public filing, and every artifact here is created by your run.

> **Why this works with no downloads:** US-listed companies file earnings releases with the SEC, and
> those filings are public web pages. Claude (in the app, on your subscription) can fetch a URL you
> give it. Your company's own reports won't be on the SEC — but they'll be in a folder, like NORDA's.
> The recipe is identical either way.

## The three prompts

**M1 · Fetch and ground** — the real-world version of prompt 1:

```
Fetch Meta's Q2 2026 earnings press release from
https://www.sec.gov/Archives/edgar/data/1326801/000162828026050596/meta-06302026xexhibit991.htm
In three sentences: how did the quarter look on the surface, and what tension sits underneath?
```

*Expect:* revenue up 28% — and operating income down 8%. The CRAFT pattern, on a real company: a
strong headline with a question underneath.

**M2 · Define and extract** — prompts 2 + 3, compressed:

```
Define with me, in plain English, six metrics for reading a Meta quarter: total revenue, revenue by
segment (Family of Apps / Reality Labs), operating income and margin, capital expenditures, free
cash flow, and daily active people. For each, note one thing it can NOT tell us (watch the one-off
charges, and remember this is a quarter, not a month). Then extract this quarter's values with
year-over-year change into meta-quarterly/meta-metrics.json — and verify one figure against the
release's own financial tables (for example: the two segments must sum to total revenue).
```

*Expect:* your definitions, then the extraction — and the verification move you learned on NORDA,
now against a real filing. If Claude can't state a number from the release, it should say so, never
estimate.

**M3 · Build the dashboard** — the advanced step. For NORDA, the dashboard was a template we gave
you. This time there is no template — Claude designs the page:

```
Design and build a one-page dashboard for these figures at meta-quarterly/meta-dashboard.html —
flat, print-like, in the same visual spirit as the NORDA one (cream paper, one accent color, ledger
tables, no external libraries) — and open it. Lead with the one question this quarter puts on the
table, and include a "what this data can't tell you" note: no capex split by segment, one-off
charges distort the year-over-year, and a quarter has no monthly resolution.
```

*Expect:* a generated one-pager. It will differ per person — that's the point of this step:
template-filling is repeatable (NORDA); generation is flexible (this). For a monthly process you
want the template; for a one-off case study, generation is fine.

## The call on the table

The quarter's entire operating cash flow (~$31.9B) went back out as capital expenditure (~$31.1B) —
free cash flow was under $1B. Revenue is accelerating; margin fell 12 points. **Is $31B a quarter of
AI infrastructure a bet compounding, or a leak?** Make the call the way you did for CRAFT: the
number that backs it, the cost of being wrong, what the data can't tell you — then argue the
opposite. (Hint an honest analyst finds: $3.58B of this quarter's costs are one-off legal and
severance charges. Price them out before you judge the trend.)

## Honest limits

- This is **public GAAP reporting** — no capex split by segment, no product-level profitability.
- **One-off charges** ($2.40B legal, $1.18B severance) sit inside this quarter's costs — every
  year-over-year delta lies unless you state them.
- A **quarter is not a month** — the NORDA cadence was monthly; public companies give you four
  reads a year, plus guidance.
- Fetched pages can change; the SEC filing is the stable, citable source. Always name your source.
