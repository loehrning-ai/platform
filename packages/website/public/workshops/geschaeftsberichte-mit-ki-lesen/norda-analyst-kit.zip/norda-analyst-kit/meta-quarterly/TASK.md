# Case 2 — the same recipe on a real company

You just built an analyst for NORDA — a synthetic company. Now leave the sandbox: **Meta Platforms'
latest quarterly results are public**, filed with the SEC on July 29, 2026. Same five questions, same
motion — real numbers, fetched live. Nothing in this folder ships pre-filled: Claude fetches the
public filing, and every artifact here is created by your run.

> **Why this works with no downloads:** US-listed companies publish their quarterly earnings release
> publicly — as a newswire press release and as an SEC filing. Claude (in the app, on your
> subscription) can fetch a public URL you give it. Your company's own reports won't be public — but
> they'll be in a folder, like NORDA's. The recipe is identical either way.
>
> **Claude will ask permission to fetch from the internet** the first time — click **Allow**, exactly
> like the file dialogs in case 1.

## The three prompts

**M1 · Fetch and ground** — the real-world version of prompt 1:

```
Fetch Meta's Q2 2026 earnings press release from
https://www.prnewswire.com/news-releases/meta-reports-second-quarter-2026-results-302838214.html
In three sentences: how did the quarter look on the surface, and what tension sits underneath?
```

*Expect:* revenue up 28% — and operating income down 8%. The CRAFT pattern, on a real company: a
strong headline with a question underneath.

> **If the fetch comes back blocked or empty,** the same release is filed with the SEC at
> `https://www.sec.gov/Archives/edgar/data/1326801/000162828026050596/meta-06302026xexhibit991.htm`
> — but the SEC blocks undeclared automated traffic, so ask for it explicitly:
> *"fetch it with curl using a User-Agent of `<your name> <your email>`"*. That is the SEC's own
> stated fair-access rule, and it is a good habit to see: **public does not mean unconditional** —
> a source can require you to identify yourself.

**M2 · Define and extract** — prompts 2 + 3, compressed:

```
Define with me, in plain English, six metrics for reading a Meta quarter: total revenue, revenue by
segment (Family of Apps / Reality Labs), operating income and margin, capital expenditures, free
cash flow, and daily active people. For each, note one thing it can NOT tell us (watch the one-off
charges, and remember this is a quarter, not a month). Then extract this quarter's values with
year-over-year change into meta-quarterly/meta-metrics.json — and verify one figure against the
release's own financial tables (for example: the two segments must sum to total revenue).
```

*Expect:* your definitions, then the extraction — and the verification move you learned on NORDA,
now against a real filing. If Claude can't state a number from the release, it should say so, never
estimate.

**M3 · Build the dashboard** — the advanced step. For NORDA, the dashboard was a template we gave
you. This time there is no template — Claude designs the page:

```
Design and build a one-page dashboard for these figures at meta-quarterly/meta-dashboard.html —
flat, print-like, in the same visual spirit as the NORDA one (cream paper, one accent color, ledger
tables, no external libraries) — and open it. Lead with the one question this quarter puts on the
table, and include a "what this data can't tell you" note: no capex split by segment, one-off
charges distort the year-over-year, and a quarter has no monthly resolution.
```

*Expect:* a generated one-pager. It will differ per person — that's the point of this step:
template-filling is repeatable (NORDA); generation is flexible (this). For a monthly process you
want the template; for a one-off case study, generation is fine.

## The call on the table

The quarter's entire operating cash flow (~$31.9B) went back out as capital expenditure (~$31.1B) —
free cash flow was under $1B. Revenue is accelerating; margin fell 12 points. **Is $31B a quarter of
AI infrastructure a bet compounding, or a leak?** Make the call the way you did for CRAFT: the
number that backs it, the cost of being wrong, what the data can't tell you — then argue the
opposite. (Hint an honest analyst finds: $3.58B of this quarter's costs are one-off legal and
severance charges. Price them out before you judge the trend.)

## Honest limits

- This is **public GAAP reporting** — no capex split by segment, no product-level profitability.
- **One-off charges** ($2.40B legal, $1.18B severance) sit inside this quarter's costs — every
  year-over-year delta lies unless you state them.
- A **quarter is not a month** — the NORDA cadence was monthly; public companies give you four
  reads a year, plus guidance.
- Fetched pages can change; the SEC filing is the stable, citable source. Always name your source.

---

## Going further (advanced — in the session if there's time, otherwise the best homework here)

**M4 · The forward test.** Case 1 taught you to write the reading down so it repeats. The public-company
version of that is to hold management to its own forward statements — every release contains claims about
the future, and almost nobody writes down in advance how they'll check them.

```
From the CFO outlook in this release, extract every forward-looking commitment as a checkable claim:
the Q3 revenue range, the full-year expense range, the full-year capex range, the tax-rate range, and
the statement about full-year operating income versus last year. For each, write (a) the number or
range, (b) what result next quarter would confirm it, and (c) what result would falsify it. Save it as
meta-quarterly/forward-test.md — a scorecard I can re-run against the next release.
```

You have just written next quarter's homework, in advance, out of this quarter's document. That file is
`SKILL.md` one level up: guidance is the only part of a report that can be *proven wrong later*.

**M5 · The steelman, priced.** The sharpest move in the whole workshop:

```
This quarter's costs include $2.40B of legal charges and $1.18B of severance. Recompute operating income
and margin excluding both, and compare that adjusted figure year-over-year. Then tell me which reading is
more honest for judging the business — the reported −8%, or the adjusted number — and why. Argue the case
you did NOT pick as convincingly as you can.
```

Do the arithmetic yourself before you read the answer. It changes the story: strip the one-offs and
operating income *grew*. So neither "profit fell 8%" nor "+28%, everything's fine" is an honest read —
one-offs explain part of the margin compression, and the rest is deliberate AI-infrastructure spend,
which is the actual thing to have an opinion about.

**That is the same instinct as case 1.** There, a +26% headline was mostly a fifth week in the month.
Here, a −8% headline is partly a one-off legal charge. Same move — *name what distorts the comparison
before you judge the trend* — on a synthetic company and then on one whose numbers move markets. That
transfer is the whole point of the workshop.
