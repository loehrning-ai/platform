/* Populated by Claude Code from metrics/metrics.json — the dashboard reads this. */
window.NORDA_DATA = {
  "company": "NORDA Werke GmbH",
  "month": "2023-09",
  "prior_month": "2023-08",
  "currency": "EUR",
  "generated_note": "Deterministic output of norda-metrics/compute_metrics.mjs — figures computed from data/, not estimated.",
  "totals": {
    "revenue_eur": 21687544,
    "units": 139056
  },
  "revenue_by_line": [
    {
      "line": "AURA",
      "family": "AUDIO",
      "units": 42197,
      "revenue_eur": 7962953,
      "avg_price_eur": 188.71,
      "price_range_eur": [
        89,
        399
      ],
      "units_mom_pct": 26.1
    },
    {
      "line": "CRAFT",
      "family": "KITCHEN",
      "units": 9162,
      "revenue_eur": 4124238,
      "avg_price_eur": 450.15,
      "price_range_eur": [
        199,
        699
      ],
      "units_mom_pct": 22.4
    },
    {
      "line": "ECHO",
      "family": "AUDIO",
      "units": 19256,
      "revenue_eur": 3162514,
      "avg_price_eur": 164.24,
      "price_range_eur": [
        79,
        219
      ],
      "units_mom_pct": 28.5
    },
    {
      "line": "NEST",
      "family": "SMARTHOME",
      "units": 16770,
      "revenue_eur": 2212590,
      "avg_price_eur": 131.94,
      "price_range_eur": [
        39,
        219
      ],
      "units_mom_pct": 24.5
    },
    {
      "line": "BREW",
      "family": "KITCHEN",
      "units": 31244,
      "revenue_eur": 2068796,
      "avg_price_eur": 66.21,
      "price_range_eur": [
        49,
        89
      ],
      "units_mom_pct": 27.9
    },
    {
      "line": "PULSE",
      "family": "WEARABLES",
      "units": 15479,
      "revenue_eur": 1910901,
      "avg_price_eur": 123.45,
      "price_range_eur": [
        59,
        199
      ],
      "units_mom_pct": 20.7
    },
    {
      "line": "BEAM",
      "family": "SMARTHOME",
      "units": 4948,
      "revenue_eur": 245552,
      "avg_price_eur": 49.63,
      "price_range_eur": [
        19,
        89
      ],
      "units_mom_pct": 33.4
    }
  ],
  "quality_by_line": [
    {
      "line": "CRAFT",
      "ncr_count": 23,
      "qty_affected": 2832
    },
    {
      "line": "NEST",
      "ncr_count": 19,
      "qty_affected": 1769
    },
    {
      "line": "AURA",
      "ncr_count": 18,
      "qty_affected": 2456
    },
    {
      "line": "PULSE",
      "ncr_count": 11,
      "qty_affected": 1321
    }
  ],
  "marketing": {
    "total_budget_eur": 2032716,
    "by_channel": [
      {
        "channel": "webinar",
        "spend_eur": 617833
      },
      {
        "channel": "paid_search",
        "spend_eur": 436519
      },
      {
        "channel": "trade_show",
        "spend_eur": 394140
      },
      {
        "channel": "paid_social",
        "spend_eur": 319030
      },
      {
        "channel": "linkedin",
        "spend_eur": 145963
      },
      {
        "channel": "content",
        "spend_eur": 119230
      }
    ]
  },
  "escalations": {
    "by_severity": {
      "P3": 6,
      "P4": 4,
      "P2": 3,
      "P1": 1
    },
    "open_p1_p2": [
      {
        "id": "ESC-00091",
        "severity": "P2",
        "title": "ECHO battery swelling reports — PL",
        "owner_team": "Finance",
        "status": "CLOSED_WONTFIX"
      },
      {
        "id": "ESC-00217",
        "severity": "P2",
        "title": "Thout Groep bill-to/ship-to mismatch spike",
        "owner_team": "Sales",
        "status": "RESOLVED"
      },
      {
        "id": "ESC-00296",
        "severity": "P1",
        "title": "Morgan Ltd escalation — late delivery of FLOW for GB",
        "owner_team": "Ops",
        "status": "RESOLVED"
      },
      {
        "id": "ESC-00337",
        "severity": "P2",
        "title": "Phishing campaign targeting DE sales team",
        "owner_team": "Finance",
        "status": "CLOSED_WONTFIX"
      }
    ]
  },
  "craft_flag": {
    "line": "CRAFT",
    "highest_price_line": true,
    "highest_defect_line": true,
    "price_range_eur": [
      199,
      699
    ],
    "ncr_count": 23,
    "units": 9162,
    "revenue_eur": 4124238,
    "reason": "CRAFT carries the highest list prices and the most quality defects this month — interrogate before scaling."
  },
  "caveats": [
    "Revenue is list-price contribution (units x base price), NOT true gross margin — the data has no per-SKU COGS.",
    "Defects/returns come from the manufacturing quality (NCR) feed by production line, NOT customer returns — there is no order->line item link in the data.",
    "Marketing budgets are campaign-level and not cleanly attributable to a single product line."
  ]
}
;
