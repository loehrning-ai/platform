# Prompt library

Copy-paste these into the Claude desktop app (Claude Code surface), pointed at this folder. On your
subscription — no API key.

## The four core prompts

**1 · Ground it**
```
Read data/company-backstory.md and both files in reports/. In two sentences, tell me who NORDA is and what
decision this month's report is building toward.
```

**2 · Compute the metrics (run the Skill)**
```
Use the norda-metrics skill to compute this month's numbers. Run its script, then show me: total revenue
and units, revenue and defects by line, and the three things that matter most — following the skill's
reading rules. Don't estimate any number the script can compute.
```

**3 · Build the dashboard**
```
Populate the dashboard: write dashboard/data.js from metrics/metrics.json (as window.NORDA_DATA = …), then
open dashboard/index.html so I can see it.
```

**4 · Make the call**
```
Make the decision: should NORDA rework CRAFT or reallocate its marketing budget for Q3? Give the number
that backs it, the cost of being wrong, and state clearly what this data can't tell us.
```

## Trust / pressure-test prompts (use any time)
```
For every number in your last answer, show me exactly which file and column it came from. Which did you
infer rather than read?
```
```
Argue the opposite recommendation as convincingly as you can. What would have to be true for it to win?
```

## Bonus — repeat it next month
```
Here's next month's data in data/. Re-run the norda-metrics skill and rebuild the dashboard, then tell me
what changed vs. this month and whether the CRAFT decision still holds.
```

## Bonus — connect live data (Claude Connectors, still no API key)
```
Connect to my Google Drive, find the latest NORDA monthly data file, bring it in, and run the norda-metrics
skill on it.
```
