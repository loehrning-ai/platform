# Prompt library

Copy-paste these into the Claude desktop app (Claude Code surface), pointed at this folder. On your
subscription — **no API key, no coding**. Read `START-HERE.md` first for setup and what to expect.

## The five prompts

**1 · Ground it**
```
Read data/company-backstory.md and reports/2023-09-monthly-report.md. In two sentences: who is NORDA, and
what decision is this month's report building toward?
```

**2 · Author your metrics Skill** (open `worksheet.md` first)
```
Open worksheet.md. Ask me the blanks one at a time — I'll answer in plain English. Then complete the
norda-metrics Skill (.claude/skills/norda-metrics/SKILL.md) from my answers: fill in the blank metric
definitions and reading rules, matching the worked examples (Revenue, Units) — plus the CRAFT flag. Show
me the finished Skill.
```

**3 · Run your Skill on the report**
```
Use my norda-metrics Skill on reports/2023-09-monthly-report.md: extract this month's numbers into
metrics/metrics.json following my reading rules, and verify one number against the source CSV in data/.
Show me total revenue and units, revenue and defects by line, and the one line to interrogate.
```

**4 · Build the dashboard**
```
Build the dashboard from this month's metrics and open it.
```

**5 · Make the call**
```
The VP of Sales wants more Q3 marketing budget behind CRAFT. Using my Skill's reading rules and this
month's numbers, make the call — rework CRAFT first, or put more Q3 marketing behind it? Give the number that backs it, the
cost of being wrong, and what this data can't tell us. Then argue the opposite as hard as you can.
```

## The contrast (before prompt 3 — worth 60 seconds)
Ask the metrics question once **without** the Skill, then with it — compare the two answers.
```
Don't use any Skill for this one — with your own eyes, eyeball the report: how did NORDA do this month?
```
Generic, and different for everyone. Then run prompt 3: your reading rules fire, the same way, every time.

## Trust / pressure-test prompts (use any time)
```
For every number in your last answer, show me exactly which file and column it came from. Which did you
infer rather than read?
```
```
Argue the opposite recommendation as convincingly as you can. What would have to be true for it to win?
```

## Bonus — repeat it next month
*(Add the new report file to `reports/` first.)*
```
Here's next month's report in reports/. Re-run my norda-metrics Skill and rebuild the dashboard, then tell
me what changed vs. this month and whether the CRAFT decision still holds.
```

## Case 2 — a real company: Meta's latest quarter (in the session)
The full task, its three prompts (M1 fetch · M2 define + extract · M3 generate the dashboard), and
the honest limits live in **`meta-quarterly/TASK.md`**. Same recipe, real public numbers, fetched
live from the SEC filing — nothing to download.

## Bonus — connect live data (Claude Connectors, still no API key) — watch, don't run
*(This one only works if the file is in your own Drive — it's a demo of where next month's report could
come from, not a step to run today.)*
```
Connect to my Google Drive, find the latest NORDA monthly report, bring it in, and run my norda-metrics
Skill on it.
```
