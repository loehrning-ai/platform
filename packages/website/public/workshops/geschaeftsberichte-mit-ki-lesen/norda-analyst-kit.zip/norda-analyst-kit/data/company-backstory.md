# NORDA Werke GmbH — company backstory

*This is the context that turns Claude into NORDA's analyst. In the Claude desktop app you'd paste this
into a Project (the "company brain"); here it lives in the kit so Claude Code can read it directly.
NORDA is fully synthetic — no real company, no NDA.*

## Who we are
NORDA Werke GmbH is a **family-owned consumer-electronics maker in Augsburg, Germany**, ~850 staff,
~**€180M** revenue (FY24). We design and manufacture our own products and sell across the **EU, UK, and
Switzerland** through roughly **150 resellers** plus a direct channel. Our fiscal year runs **April 1 →
March 31** (so September = FY24, Q2).

## What we make — 4 families, 8 lines
- **Audio:** **AURA** (premium speakers, €89–399), **ECHO** (smart speakers, €79–219)
- **SmartHome:** **NEST** (thermostats/hubs/sensors, €39–219), **BEAM** (smart lighting, €19–89)
- **Wearables:** **PULSE** (bands/watch, €59–199), **FLOW** (smart ring, €249)
- **Kitchen:** **CRAFT** (premium espresso + grinder, €199–699), **BREW** (kettles/scales, €49–89)

CRAFT is our newest premium bet — high price, high expectations, quality still being proven.

## How we run the month
Each month leadership reviews a performance report: revenue and units by line, quality (defects),
marketing, and open escalations — and decides where to push, fix, or pull back. We care about **decisions,
not dashboards**: a number matters only if it changes what we do.

## What we track (and what we can't yet)
- We report **revenue as list-price contribution** (units × list price). We do **not** yet have per-SKU
  cost, so we cannot see true gross margin per line.
- Our **quality signal is the NCR (non-conformance) feed** by production line. We cannot yet tie customer
  returns to a specific product line.
- **Marketing budgets are campaign-level**, not cleanly split by product line.

Good analysis names these limits instead of pretending the data answers them.
