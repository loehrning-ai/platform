# NORDA Werke — Monthly Performance Report · August 2023 (FY24 Q2)

*Prior-month baseline for the September review. Figures are list-price contribution from the August data;
same caveats as §7 of the September report apply. NORDA is a fully synthetic company.*

## 1. Headline
August delivered **€17.23M** of list-price revenue on **110,373 units** — a solid start to Q2 ahead of the
September push. AURA led; **CRAFT** already stood out as the highest-priced line carrying the **most quality
defects (24 NCRs)**, a flag we said we'd watch into September.

## 2. Revenue by line (list-price contribution)
| Line | Family | Units | Revenue | Avg price |
|------|--------|------:|--------:|----------:|
| AURA | Audio | 33,471 | €6,292,609 | €188.01 |
| **CRAFT** | **Kitchen** | **7,488** | **€3,301,112** | **€440.86** |
| ECHO | Audio | 14,989 | €2,468,211 | €164.67 |
| NEST | SmartHome | 13,467 | €1,781,853 | €132.31 |
| BREW | Kitchen | 24,421 | €1,617,469 | €66.23 |
| PULSE | Wearables | 12,829 | €1,573,871 | €122.68 |
| BEAM | SmartHome | 3,708 | €198,522 | €53.54 |

## 3. Quality — defects by line (NCR feed)
| Line | NCRs (Aug) | Units affected |
|------|-----------:|---------------:|
| **CRAFT** | **24** | 3,048 |
| NEST | 12 | 1,402 |
| AURA | 11 | 1,533 |
| PULSE | 9 | 1,004 |

CRAFT already carries the most defects — **the September report should confirm whether this is chronic.** (It was: 23 NCRs again in September.)

## 4. Marketing
Campaign budgets in flight total **€2.03M**, led by webinar, paid search, and trade show. (Campaign-level;
not cleanly per-line — see the September report §7.)

## 5. Open escalations (P1 / P2)
- P1 — Morgan Ltd escalation: late delivery of FLOW for GB (Owner: Ops)
- P2 — ECHO battery swelling reports (Owner: Finance)
- P2 — Thout Groep bill-to/ship-to mismatch spike (Owner: Sales)
- P2 — Phishing campaign targeting DE sales team (Owner: Finance)

## 6. Watch into September
CRAFT's price-vs-defect profile. If the defect load repeats in September, it becomes a decision, not a note.

## 7. Caveats
Same as the September report: list-price revenue (not gross margin), NCRs are production quality (not
customer returns), marketing budgets are not per-line.
