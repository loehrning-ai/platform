# NORDA Werke — Monthly Performance Report · September 2023 (FY24 Q2)

*Prepared for the NORDA leadership team. All figures are list-price contribution from the September data;
see §7 for what the numbers do and don't mean. NORDA is a fully synthetic company.*

## 1. Headline
September delivered **€21.69M (€21,687,544)** of list-price revenue on **139,056 units** — up **~26%** on August
(€17.23M / 110,373 units), a strong close to FY24 Q2. Growth was broad: all seven shipping
lines grew units month-over-month. The one thing that needs a decision is not the top line — it's **CRAFT**,
our premium kitchen line, which is our **second-largest revenue line on one of the lowest volumes** and carries
**the most quality defects of any line**.

## 2. Revenue by line (list-price contribution)
| Line | Family | Units | Revenue | Avg price | MoM units |
|------|--------|------:|--------:|----------:|----------:|
| AURA | AUDIO | 42,197 | €7,962,953 | €188.71 | +26.1% |
| **CRAFT** | **KITCHEN** | **9,162** | **€4,124,238** | **€450.15** | **+22.4%** |
| ECHO | AUDIO | 19,256 | €3,162,514 | €164.24 | +28.5% |
| NEST | SMARTHOME | 16,770 | €2,212,590 | €131.94 | +24.5% |
| BREW | KITCHEN | 31,244 | €2,068,796 | €66.21 | +27.9% |
| PULSE | WEARABLES | 15,479 | €1,910,901 | €123.45 | +20.7% |
| BEAM | SMARTHOME | 4,948 | €245,552 | €49.63 | +33.4% |

AURA leads on volume and revenue. **CRAFT is the story**: only 9,162 units (the second-lowest volume),
yet **€4.12M revenue** — because its average price (€450) is 2.4× AURA's. Premium revenue, thin volume.

Price bands differ sharply by line. **CRAFT lists at €199–699** — the widest and highest band we sell —
against AURA €89–399, ECHO €79–219, NEST €39–219, PULSE €59–199, BREW €49–89, and BEAM €19–89. CRAFT's
€450 average sits high in its band, which is exactly why its €4.12M lands on one of the company's
thinnest volumes (only BEAM ships fewer units).

## 3. Quality — defects by line (NCR feed)
| Line | NCRs (Sep) | Units affected |
|------|-----------:|---------------:|
| **CRAFT** | **23** | 2,832 |
| NEST | 19 | 1,769 |
| AURA | 18 | 2,456 |
| PULSE | 11 | 1,321 |

**CRAFT has the most non-conformance records this month** (23), and it also had the most in August (24) —
this is not a one-month blip. On a line that ships only ~9k units, that defect intensity is high.

## 4. Marketing
Campaign budgets on the books (all periods) total **€2.03M (€2,032,716)**, led by **webinar (€617,833)**, **paid
search (€436,519)**, and **trade show (€394,140)**, then paid social (€319,030), LinkedIn (€145,963), and
content (€119,230). (Budgets are campaign-level and span multiple periods; they are not cleanly
attributable to a single product line or month — see §7. Channel figures are rounded to the nearest euro,
so they may not sum exactly to the total.)

## 5. Open escalations (P1 / P2)
- **ESC-00296 · P1 — Wide World Ltd escalation — FLOW launch-allocation slip for GB** (Owner: Ops · OPEN)
- ESC-00091 · P2 — ECHO battery swelling reports — PL (Owner: Quality · IN_PROGRESS)
- ESC-00217 · P2 — Wingtip Groep bill-to/ship-to mismatch spike (Owner: Sales · IN_PROGRESS)
- ESC-00337 · P2 — Phishing campaign targeting DE sales team (Owner: Legal · IN_PROGRESS)

Severity mix raised in September: **P1×1, P2×3, P3×6, P4×4** (14 total). The one P1 is a launch-allocation
slip on FLOW into GB (FLOW is still pre-launch — committed launch volume, not shipped orders). Note a
separate **quality** signal — ECHO battery
swelling — sitting outside the CRAFT story. (Each ID above resolves in `data/exec_escalations.csv` —
verify one yourself.)

## 6. The decision on the table
**CRAFT: rework the line first, or put more Q3 marketing behind it now?** CRAFT earns **€4.12M** on just
**9,162 units** at a **€450 average price**, and carries **the most defects two months running**.

**The VP of Sales is pushing hard for more spend:** *"CRAFT is our premium cash engine — €4.12M on our
thinnest volume proves the appetite is there. Let's move more of Q3's marketing budget behind it and push
volume while the margin-looking revenue is hot. The defects are a manufacturing problem to fix in parallel,
not a reason to slow the growth."*

That is one reading, and it comes from the person who owns the number. The quality feed tells another
story: **23 NCRs in September, 24 in August** — the most of any line, on a line shipping only ~9k units.
Funding more demand for a line whose defect load is already the highest risks scaling the returns and
rework right along with the revenue. **Cost of being wrong:** slow CRAFT too early and we lose our
highest-margin-looking revenue; pour budget behind it as-is and we fund a line that warranty and rework
costs eat. *This is the call you'll make — with the VP's argument on the table, not a blank page.*

## 7. What this report can't tell you
- **No true gross margin.** "Revenue" here is units × list price. The data has no per-SKU cost, so CRAFT's
  real profitability is unknown — its high price is not the same as high margin.
- **Defects ≠ customer returns.** The NCR feed is *production* quality by line; there is no order→line link
  to measure customer returns per line. Treat NCRs as a leading quality signal, not a returns rate.
- **Marketing isn't per-line.** Budgets are campaign-level and not cleanly month- or line-attributable.
- **The month-over-month comparison isn't like-for-like.** September's slice holds five weekly buckets;
  August's holds four. Per week, units grew **+0.8%** and revenue **+0.7%** — so most of the headline
  **+26%** is the extra week, not demand. Treat MoM totals as directional and compare per-week, or
  compare the same number of weeks. The CRAFT question does not depend on this: the flag is
  highest-price + most-defects, and defects **per 1,000 units** (CRAFT 2.51 vs NEST 1.13, PULSE 0.71,
  AURA 0.43) are unaffected by how many weeks the month held.
