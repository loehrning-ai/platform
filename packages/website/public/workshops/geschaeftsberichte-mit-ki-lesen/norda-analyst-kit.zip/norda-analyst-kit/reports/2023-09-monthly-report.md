# NORDA Werke — Monthly Performance Report · September 2023 (FY24 Q2)

*Prepared for the NORDA leadership team. All figures are list-price contribution from the September data;
see §7 for what the numbers do and don't mean. NORDA is a fully synthetic company.*

## 1. Headline
September delivered **€21.69M** of list-price revenue on **139,056 units** — up **~26%** on August
(€17.23M / 110,373 units), a strong close to the first half of FY24 Q2. Growth was broad: every product
line grew units month-over-month. The one thing that needs a decision is not the top line — it's **CRAFT**,
our premium kitchen line, which is our **second-largest revenue line on the smallest volume** and carries
**the most quality defects of any line**.

## 2. Revenue by line (list-price contribution)
| Line | Family | Units | Revenue | Avg price | MoM units |
|------|--------|------:|--------:|----------:|----------:|
| AURA | Audio | 42,197 | €7,962,953 | €188.71 | +26.1% |
| **CRAFT** | **Kitchen** | **9,162** | **€4,124,238** | **€450.15** | **+22.4%** |
| ECHO | Audio | 19,256 | €3,162,514 | €164.24 | +28.5% |
| NEST | SmartHome | 16,770 | €2,212,590 | €131.94 | +24.5% |
| BREW | Kitchen | 31,244 | €2,068,796 | €66.21 | +27.9% |
| PULSE | Wearables | 15,479 | €1,910,901 | €123.45 | +20.7% |
| BEAM | SmartHome | 4,948 | €245,552 | €49.63 | +33.4% |

AURA leads on volume and revenue. **CRAFT is the story**: only 9,162 units (the second-lowest volume),
yet **€4.12M revenue** — because its average price (€450) is 2.4× AURA's. Premium revenue, thin volume.

## 3. Quality — defects by line (NCR feed)
| Line | NCRs (Sep) | Units affected |
|------|-----------:|---------------:|
| **CRAFT** | **23** | 2,832 |
| NEST | 19 | 1,769 |
| AURA | 18 | 2,456 |
| PULSE | 11 | 1,321 |

**CRAFT has the most non-conformance records this month** (23), and it also had the most in August (24) —
this is not a one-month blip. On a line that ships only ~9k units, that defect intensity is high.

## 4. Marketing
Campaign budgets in flight total **€2.03M**, led by **webinar (€617,833)**, **paid search (€436,519)**,
and **trade show (€394,140)**, then paid social (€319,030), LinkedIn (€145,963), and content (€119,230).
(Budgets are campaign-level; they are not cleanly attributable to a single product line — see §7.)

## 5. Open escalations (P1 / P2)
- **P1 — Morgan Ltd escalation: late delivery of FLOW for GB** (Owner: Ops)
- P2 — ECHO battery swelling reports (Owner: Finance)
- P2 — Thout Groep bill-to/ship-to mismatch spike (Owner: Sales)
- P2 — Phishing campaign targeting DE sales team (Owner: Finance)

The one P1 is a logistics miss on FLOW into GB. Note a separate **quality** signal — ECHO battery
swelling — sitting outside the CRAFT story.

## 6. The decision on the table
**CRAFT: rework the line, or reallocate its marketing budget for Q3?** CRAFT earns **€4.12M** on just
**9,162 units** at a **€450 average price**, and carries **the most defects two months running**. Two
readings: (a) it's a premium cash engine worth *fixing* the quality on; (b) its defect load is eroding a
line we can't scale. **Recommendation to debate:** commission a CRAFT quality root-cause (the 23 NCRs)
**before** committing more marketing spend to it. **Cost of being wrong:** cut too early and we lose our
highest-margin-looking revenue; scale it as-is and we pour budget into a line that returns/reworks eat.

## 7. What this report can't tell you
- **No true gross margin.** "Revenue" here is units × list price. The data has no per-SKU cost, so CRAFT's
  real profitability is unknown — its high price is not the same as high margin.
- **Defects ≠ customer returns.** The NCR feed is *production* quality by line; there is no order→line link
  to measure customer returns per line. Treat NCRs as a leading quality signal, not a returns rate.
- **Marketing isn't per-line.** Budgets are campaign-level and not cleanly month- or line-attributable.
