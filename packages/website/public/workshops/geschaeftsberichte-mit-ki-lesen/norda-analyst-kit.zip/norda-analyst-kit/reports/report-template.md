# NORDA Werke — Monthly Performance Report · {MONTH} (FY{FY} {QUARTER})

> Reusable format (optional — a "draft next month's report" take-home extension, not part of the
> 60-minute session). This is the shape Claude drafts each month's report into. Fill every `{…}` from the data;
> never leave a placeholder. Keep numbers in the body traceable to `data/` (the `norda-metrics` Skill
> computes them).

## 1. Headline
{One paragraph: total revenue (list-price contribution) and units this month, the MoM move, and the single
most important thing the exec needs to know.}

## 2. Revenue by line
{Table: line · family · units · revenue (list-price) · avg price · MoM units %. Sorted by revenue.
Call out the top line and any line that is high-revenue-but-troubled.}

## 3. Quality (defects by line)
{Table: line · NCR count this month · units affected. Which line has the most, and whether that lines up
with a high-value line — the signal to interrogate.}

## 4. Marketing
{Spend by channel (campaign budgets in flight — note: not cleanly month-attributable). The biggest channels.}

## 5. Open escalations (P1 / P2)
{List: severity · title · owner. The ones that could change a decision this month.}

## 6. The decision on the table
{The one call this month, with the number that backs it and the cost of being wrong.}

## 7. What this report can’t tell you
{The honest caveats: no true gross margin (list-price only), defects are the quality/NCR feed not customer
returns, marketing budgets aren’t cleanly per-line. State them so no one over-reads the numbers.}
