# Worksheet — teach the Skill how NORDA reads its numbers

You're going to finish NORDA's metrics Skill **in plain language** — no code. When you send **prompt 2**,
Claude asks you these blanks one at a time and writes your answers into the Skill — answer from the hints
below, in your own words. (Prefer to prep? Jot answers in the blanks first, then tell Claude *"use my
worksheet answers to complete the Skill."*) Then you run it.

Everything you need is in `data/company-backstory.md` (the "What we track" section) and the worked example
definitions already in the Skill. This is the exact motion you'd repeat for your own company on Monday —
so answer as if these were *your* numbers.

---

## The questions every metrics Skill answers

**1 · What do we track?**
NORDA reviews five things each month: revenue, units, quality (defects), marketing, and open escalations.
*(Given — no need to change.)*

**2 · Where do the numbers come from, and what does each one mean HERE?**
Write one plain sentence for each blank metric. Copy the shape of the worked examples (Revenue, Units) — plus the CRAFT flag.

- **Defects** — what counts as a defect for NORDA, and where does the number come from?
  → YOUR TURN: _______________________________________________________________________________
  _(NORDA's answer lives in the backstory: the NCR — non-conformance — feed, by production line. It's a
  quality signal, not customer returns.)_

- **Marketing spend** — what does this measure?
  → YOUR TURN: _______________________________________________________________________________
  _(Backstory: campaign budgets, by channel — not cleanly split by product line.)_

- **Escalations** — what is an escalation, and which ones matter for the review?
  → YOUR TURN: _______________________________________________________________________________
  _(The open P1/P2 items — highest severity — with the team that owns each.)_

**3 · How do we analyze it? (reading rules)**
The Skill has two rules already. Add two or three more, in your own words. Ideas to phrase yourself:

- Comparing each line to the prior month or to target (not just company totals — a total hides one bad line).
  → YOUR TURN: _______________________________________________________________________________
- What to do with the line that has the highest price **and** the most defects.
  → YOUR TURN: _______________________________________________________________________________
- Naming what the data **can't** answer, instead of pretending it can.
  → YOUR TURN: _______________________________________________________________________________

**4 · What can this data NOT tell us?** (these become the dashboard's honesty caveats)
- No true gross margin — revenue is units × list price, no per-SKU cost — given.
- Defects are production quality (NCRs), not customer returns by line — given.
- Marketing budgets are campaign-level, not per-line — given.

**5 · What decision does the month feed?**
This month: **rework CRAFT first** or **put more Q3 marketing behind it**. *(Given — it's the call you'll
make at the end.)*

---

### When you're done
Once you've answered the blanks (Claude asks them in prompt 2, or use notes you jotted here), it completes
the norda-metrics Skill and you run it on this month's report. You'll watch your plain-language definitions
become the analysis — and an empty dashboard fill with the numbers your Skill just pulled.
