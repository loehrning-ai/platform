# NORDA Analyst Kit

Build a small **AI analyst** for a real business decision — entirely in the **Claude app**, on a
paid **Claude Pro or Max subscription**. No separate API key or usage-billed API service. No coding.

You are NORDA Werke's analyst for **September 2023**. In a few natural-language prompts you'll turn a
month of raw data into a metrics summary, a populated dashboard, and one board-level decision:
**should NORDA rework its premium CRAFT line, or reallocate its marketing budget?**

## What's in here
```
data/            5 CSVs (open in Excel) + the company backstory  ← this month's raw data
reports/         two monthly reports (August + September) + the reusable report template
.claude/skills/  the "norda-metrics" Skill — how NORDA computes its numbers (+ a deterministic script)
metrics/         metrics.json (computed) + its schema
dashboard/       a loehrning-styled dashboard that shows the numbers (open index.html)
START-HERE.md    ← do this: the guided run, 4 prompts
PROMPTS.md       copy-paste prompt library
```

## How to run it (no API key)
1. Install and open the **Claude desktop app**, sign in with a **Pro or Max subscription**, and switch
   to its **Claude Code** surface (or run `claude` in this folder from a terminal). Claude Code
   availability and sign-in behavior can change; use Anthropic's current setup documentation if the
   surface is not present.
2. Point it at **this folder**.
3. Follow **`START-HERE.md`** — four prompts, in order.

Claude does the intelligence; two small helpers keep it honest and offline:
- `.claude/skills/norda-metrics/compute_metrics.mjs` computes the numbers exactly (Node, no dependencies).
- `dashboard/index.html` renders them (static, opens via file://, no CDN).

## The two worlds (why there's no API key)
- **Claude is the brain** — this guided path requires a compatible paid subscription and Claude Code.
- **The dashboard is just a template Claude fills in.** We never run a separate AI service, so there's
  no key to buy. (Tim's full open-source report/dashboard generators are the "productized" version of the
  same idea — free to clone if you want to go further.)

*NORDA Werke is fully synthetic data — safe to share, no NDA.*
