# NORDA Analyst Kit

Build a small **AI analyst** for a real business decision — entirely in the **Claude app**, on your
**subscription**. No API key. No paid service. No coding.

You are NORDA Werke's analyst for **September 2023**. In five natural-language prompts you'll **author a
metrics Skill**, run it on the monthly report, watch an **empty dashboard fill itself**, and make one
board-level decision: **should NORDA rework its premium CRAFT line, or put more Q3 marketing behind it?**

## What's in here
```
data/            5 CSVs (open in Excel or Numbers) + the company backstory  ← this month's raw data
reports/         two monthly reports (August + September) + the reusable report template
worksheet.md     ← fill this in: how NORDA reads its numbers (feeds your Skill)
.claude/skills/  the "norda-metrics" Skill — ships half-written; you complete it
metrics/         the metrics schema (your Skill writes metrics.json here when you run it)
dashboard/       a loehrning-styled dashboard — starts empty, fills from your Skill (open index.html)
START-HERE.md    ← do this: setup + the guided run, 5 prompts
PROMPTS.md       copy-paste prompt library
meta-quarterly/  ← case 2: the same recipe on Meta's real, public quarterly results (fetched live)
your-company-skill/  a blank template to redo this for your own company
```

## How to run it (no API key, no coding)
1. Open the **Claude desktop app** and switch to its **Claude Code** surface. It runs on your **Pro/Max
   subscription** — no API key needed, and no terminal: it's a panel in the app.
2. Point it at **this folder** (the one with `START-HERE.md` at the top level).
3. Follow **`START-HERE.md`** — five prompts, in order.

Claude does the analysis. The kit carries no cleverness of its own. The only helper is a **template**:
`dashboard/index.html` renders your numbers (static, opens via `file://`, no CDN, no service). Your Skill
reads the report and fills it — no key to buy, nothing to install.

## The two worlds (why there's no API key)
- **Claude is the brain** — Projects, Skills, and Claude Code all run on your subscription.
- **The dashboard is just a template Claude fills in.** We never run a separate AI service, so there's no
  key to buy. This kit is the from-scratch, keyless version you can rebuild for your own company.

*Built by loehrning.ai × brainster — The AI Analyst workshop. NORDA Werke is fully synthetic data — safe
to share, no NDA.*
