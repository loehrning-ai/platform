# Your company, your Skill — the take-home template

You just did this for NORDA. Here's the blank version for **your** company. Same five prompts, your data.

1. Drop your latest monthly report (PDF, doc, or a pasted table) into this folder — or just have it open.
2. Fill in `worksheet.md` in plain language: what you track, what each number means at your company, what
   your data can't answer.
3. In the Claude desktop app (Claude Code surface), pointed at this folder, ask:
   *"Install `SKILL.md` as a Skill in this folder."* It moves the file into `.claude/skills/` so the Skill
   fires automatically.
4. Then say:
   *"Complete the metrics Skill from my worksheet answers, then run it on my report and build a dashboard
   from the numbers."*
5. Copy the NORDA dashboard (`../dashboard/index.html` + `data.js`) into this folder. It reads a
   `window.NORDA_DATA` object — your Skill writes it.

No API key, no coding — the same motion you just learned. Start with one report and one decision.
