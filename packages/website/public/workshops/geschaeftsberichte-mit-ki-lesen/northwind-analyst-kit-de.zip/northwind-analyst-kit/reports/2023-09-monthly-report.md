# NORTHWIND · Monatsbericht · September 2023 (GJ24 Q2)

*Für die Geschäftsleitung von NORTHWIND. Alle Zahlen sind Umsatz zum Listenpreis aus den Septemberdaten;
was die Zahlen bedeuten und was nicht, steht in §6. NORTHWIND ist eine vollständig erfundene Firma.*

## 1. Überblick
Der September brachte **21,69 Mio. € (21.687.544 €)** Umsatz zum Listenpreis bei **139.056 Stück**, ein Plus
von **rund 26 %** gegenüber August (17,23 Mio. € / 110.373 Stück). Ein starker Abschluss für Q2 des
Geschäftsjahres 24. Das Wachstum war breit: Alle sieben liefernden Linien steigerten ihre Stückzahl
gegenüber dem Vormonat. Entscheiden müssen wir nicht über die Gesamtzahl, sondern über **CRAFT**, unsere
Premium-Küchenlinie. Sie ist unsere **zweitgrößte Umsatzlinie bei einer der kleinsten Stückzahlen** und hat
**die meisten Qualitätsmängel aller Linien**.

## 2. Umsatz je Linie (zum Listenpreis)
| Linie | Familie | Stück | Umsatz | Ø Preis | Stück ggü. Vormonat |
|------|--------|------:|--------:|----------:|----------:|
| AURA | AUDIO | 42.197 | 7.962.953 € | 188,71 € | +26,1 % |
| **CRAFT** | **KITCHEN** | **9.162** | **4.124.238 €** | **450,15 €** | **+22,4 %** |
| ECHO | AUDIO | 19.256 | 3.162.514 € | 164,24 € | +28,5 % |
| NEST | SMARTHOME | 16.770 | 2.212.590 € | 131,94 € | +24,5 % |
| BREW | KITCHEN | 31.244 | 2.068.796 € | 66,21 € | +27,9 % |
| PULSE | WEARABLES | 15.479 | 1.910.901 € | 123,45 € | +20,7 % |
| BEAM | SMARTHOME | 4.948 | 245.552 € | 49,63 € | +33,4 % |

AURA führt bei Stück und Umsatz. **CRAFT ist die Geschichte**: nur 9.162 Stück (die zweitkleinste Menge),
aber **4,12 Mio. € Umsatz**, weil der Durchschnittspreis (450 €) das 2,4-Fache von AURA beträgt.
Premiumumsatz bei kleiner Menge.

Die Preisspannen unterscheiden sich stark. **CRAFT kostet 199 € bis 699 €**, die breiteste und höchste
Spanne, die wir verkaufen, gegenüber AURA 89 € bis 399 €, ECHO 79 € bis 219 €, NEST 39 € bis 219 €, PULSE
59 € bis 199 €, BREW 49 € bis 89 € und BEAM 19 € bis 89 €. Der CRAFT-Durchschnitt von 450 € liegt weit oben in
seiner Spanne. Deshalb landen seine 4,12 Mio. € auf einer der kleinsten Mengen der Firma (nur BEAM liefert
weniger Stück).

## 3. Qualität: Mängel je Linie (NCR-Meldungen)
| Linie | Meldungen (Sep) | Betroffene Stück | Meldungen je 1.000 Stück |
|------|-----------:|---------------:|---------------------:|
| **CRAFT** | **23** | 2.832 | **2,51** |
| NEST | 19 | 1.769 | 1,13 |
| AURA | 18 | 2.456 | 0,43 |
| PULSE | 11 | 1.321 | 0,71 |

August: CRAFT 24 Meldungen, 3,21 je 1.000 Stück.

**CRAFT hat in diesem Monat die meisten Qualitätsmeldungen** (23) und hatte auch im August die meisten (24).
Das ist kein Ausreißer eines Monats. Bei einer Linie mit nur rund 9.000 Stück ist diese Mängeldichte hoch.

## 4. Marketing
Die Kampagnenbudgets in den Büchern summieren sich über alle Perioden auf **2,03 Mio. €**. Sie gelten je
Kampagne und lassen sich keiner einzelnen Linie und keinem einzelnen Monat zuordnen.

## 5. Die Entscheidung
**CRAFT: erst die Linie nacharbeiten oder jetzt mehr Q3-Marketing dahinterstellen?** CRAFT bringt
**4,12 Mio. €** mit nur **9.162 Stück** zu einem **Durchschnittspreis von 450 €** und hat **zwei Monate in
Folge die meisten Mängel**.

**Der VP Sales drängt auf mehr Budget:** *„CRAFT ist unsere Premiumlinie: 4,12 Mio. € bei einer unserer
kleinsten Mengen, und die Stückzahl liegt 22,4 % über August. Und die Qualität dreht bereits: Bei CRAFT
fielen die Defekte von 3,21 auf 2,51 je 1.000 Stück. Keine andere Linie hat sich verbessert. Lasst uns jetzt
mehr vom Q3-Marketingbudget dahinterstellen.“*

Sicht der Qualitätssicherung: CRAFT hatte im September 23 Meldungen und im August 24, in beiden Monaten die
meisten aller Linien. Mehr Nachfrage nach CRAFT heißt mehr CRAFT-Produktion. Entscheidet, was zuerst
kommt: Nacharbeit oder Marketing.

## 6. Was dieser Bericht nicht sagen kann
- **Keine echte Bruttomarge.** „Umsatz“ heißt hier Stück mal Listenpreis. Die Daten haben keine Stückkosten,
  die echte Profitabilität von CRAFT ist also unbekannt. Ein hoher Preis ist keine hohe Marge.
- **Mängel sind keine Retouren.** Die NCR-Meldungen beschreiben die Qualität in der *Produktion* je Linie;
  es gibt keine Verknüpfung von Bestellung zu Linie, mit der sich Retouren je Linie messen ließen. Lies die
  Meldungen als frühes Qualitätssignal, nicht als Retourenquote.
- **Marketing gibt es nicht je Linie.** Die Budgets gelten je Kampagne und lassen sich nicht sauber einem
  Monat oder einer Linie zuordnen.
- **Der Vergleich mit dem Vormonat ist nicht gleichwertig.** Der September umfasst fünf Versandwochen, der
  August vier. Je Woche stieg die Stückzahl um **+0,8 %** und der Umsatz um **+0,7 %**. Der Großteil der
  **+26 %** im Überblick ist also die zusätzliche Woche, nicht Nachfrage. Lies Monatssummen als Richtung und
  vergleiche je Woche oder gleich viele Wochen.
