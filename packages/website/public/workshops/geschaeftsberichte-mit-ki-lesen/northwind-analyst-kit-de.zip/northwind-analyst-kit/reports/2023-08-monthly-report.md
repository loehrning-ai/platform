# NORTHWIND · Monatsbericht · August 2023 (GJ24 Q2)

*Vormonat als Vergleichsbasis für den Septemberbericht. Alle Zahlen sind Umsatz zum Listenpreis aus den
Augustdaten; es gelten dieselben Einschränkungen wie in §6 des Septemberberichts. NORTHWIND ist eine
vollständig erfundene Firma.*

## 1. Überblick
Der August brachte **17,23 Mio. €** Umsatz zum Listenpreis bei **110.373 Stück**, ein solider Monat mitten in
Q2 vor dem Septemberschub. AURA führte; **CRAFT** fiel schon jetzt als teuerste Linie mit den **meisten
Qualitätsmängeln (24 Meldungen)** auf. Das wollten wir bis in den September beobachten.

## 2. Umsatz je Linie (zum Listenpreis)
| Linie | Familie | Stück | Umsatz | Ø Preis |
|------|--------|------:|--------:|----------:|
| AURA | AUDIO | 33.471 | 6.292.609 € | 188,00 € |
| **CRAFT** | **KITCHEN** | **7.488** | **3.301.112 €** | **440,85 €** |
| ECHO | AUDIO | 14.989 | 2.468.211 € | 164,67 € |
| NEST | SMARTHOME | 13.467 | 1.781.853 € | 132,31 € |
| BREW | KITCHEN | 24.421 | 1.617.469 € | 66,23 € |
| PULSE | WEARABLES | 12.829 | 1.573.871 € | 122,68 € |
| BEAM | SMARTHOME | 3.708 | 198.522 € | 53,54 € |

## 3. Qualität: Mängel je Linie (NCR-Meldungen)
| Linie | Meldungen (Aug) | Betroffene Stück |
|------|-----------:|---------------:|
| **CRAFT** | **24** | 2.324 |
| NEST | 12 | 1.587 |
| AURA | 11 | 1.779 |
| PULSE | 9 | 1.099 |

CRAFT hat schon jetzt die meisten Mängel. **Der Septemberbericht sollte zeigen, ob das dauerhaft ist.**

## 4. Marketing
Die Kampagnenbudgets in den Büchern (alle Perioden) summieren sich auf **2,03 Mio. €**, vorn Webinare,
bezahlte Suche und Messen. (Je Kampagne und über mehrere Perioden; nicht sauber je Linie oder Monat, siehe
§6 des Septemberberichts.)

## 5. Im September beobachten
Das Verhältnis von Preis und Mängeln bei CRAFT. Wiederholt sich die Mängellast im September, wird daraus
eine Entscheidung und keine Notiz mehr.

## 6. Einschränkungen
Wie im Septemberbericht: Umsatz zum Listenpreis (keine Bruttomarge), Meldungen beschreiben die Qualität in
der Produktion (keine Retouren), Marketingbudgets gibt es nicht je Linie.
