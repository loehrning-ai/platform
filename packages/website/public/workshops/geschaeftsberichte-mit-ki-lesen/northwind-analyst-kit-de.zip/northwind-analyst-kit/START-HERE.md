# Hier anfangen

Der Septemberbericht von NORTHWIND will mehr Marketinggeld für CRAFT, die Premium-Küchenlinie. Der VP
Sales stützt den Antrag auf zwei Zahlen: Die CRAFT-Stückzahl wuchs um 22,4 %, und die CRAFT-Defekte fielen
von 3,21 auf 2,51 je 1.000 Stück. Beide Zahlen sind richtig gerechnet. Keine sagt, wie gezählt wurde.

Eine Kennzahl bedeutet nur, was ihr Steckbrief sagt. Erst Zähler, Nenner und Zeitraum festlegen, dann eine
Zahl bis zur Datenzeile prüfen, dann entscheiden.

In diesem Kit schreibst du diese Definitionen als Kennzahlen-Steckbriefe auf, lässt Claude sie über einen
Skill anwenden, verfolgst eine Zahl bis zu ihren Zeilen zurück und entscheidest. Etwa eine Stunde.
NORTHWIND und alle Daten sind erfunden.

Du brauchst die Claude-Desktop-App mit Claude Code (in Pro und Max enthalten) und diesen Ordner, entpackt.
Kein Code, kein API-Schlüssel. Ohne Claude Code: siehe „Ohne Claude Code“ am Ende.

Die Dateinamen und die Spaltennamen der CSVs bleiben englisch. Es sind Daten, und dieselben Prompts
funktionieren so auch im englischen Kit.

## Einrichten (2 Minuten)
1. Entpacken. Öffne den Ordner, in dem diese Datei ganz oben liegt. Liegt darin ein Ordner gleichen Namens,
   geh eine Ebene tiefer. Claude findet den Skill nur aus dem richtigen Ordner.
2. In der Claude-Desktop-App „Code“ öffnen und diesen Ordner wählen.
3. Claude fragt, bevor es eine Datei liest oder schreibt. Erlaube es.

## Was im Ordner liegt
| Pfad | Was es ist | Schritt |
|---|---|---|
| `reports/2023-09-monthly-report.md` | Der Bericht, um den es geht. §5 ist das Argument des VP. | 1 |
| `reports/2023-08-monthly-report.md` | Der Vormonat. | 2 |
| `data/ncr_records.csv` | 127 Qualitätsmeldungen (NCRs): Datum, Maschine, Art, betroffene Stück, Ausschuss oder Nacharbeit. | 2 |
| `data/demand_actuals.csv` | 2.115 Wochenzeilen Versand: week_start, sku, sales_org, units_actual. | 2, 3 |
| `data/product_lines.csv` | 23 Modelle mit Listenpreis. | 3 |
| `data/company-backstory.md` | Wer NORTHWIND ist. | 1 |
| `metric-cards.md` | Dein Arbeitsblatt: ein Steckbrief ausgefüllt, zwei offen, eine Freigabebedingung. | 2 |
| `.claude/skills/northwind-metrics/` | Der Skill, den Claude ausführt. Versteckter Ordner; lass ihn, wo er ist. | 3, 4 |
| `metrics/metrics.schema.json` | Die Form der Zahlen, die der Skill schreibt. | 4 |
| `dashboard/` | Leer bis Schritt 4. | 4 |
| `claude/kennzahlen-steckbrief/` | Dieselbe Methode ohne NORTHWIND, für deine eigenen Berichte. | 5 |
| `project-instructions.md` | Dieselbe Methode als Projektanweisungen für claude.ai-Projekte. | danach |

## Schritt 1 · Das Argument lesen (5 Min.)
> Lies data/company-backstory.md und reports/2023-09-monthly-report.md. Liste jede Zahl, mit der der VP in §5
> für mehr CRAFT-Marketing argumentiert, mit dem Abschnitt, aus dem sie stammt, und ob der Bericht sagt, wie
> sie gezählt wurde. Bewerte sie noch nicht.

Erwartet: 4,12 Mio. € Umsatz (§2), Stückzahl +22,4 % gegenüber August (§2), Defekte 3,21 → 2,51 je 1.000
Stück (§3). Bei keiner der drei sagt der Bericht, wie gezählt wurde.

Bevor du in die Daten schaust, schreib deine Antwort auf: Ist die Qualität von CRAFT im September besser
geworden, gleich geblieben oder schlechter geworden? Im Workshop stimmen wir ab.

## Schritt 2 · Die Definitionen festlegen (15 Min.)
> Öffne metric-cards.md. Rechne für jeden Steckbrief, der OFFEN ist, jede dort genannte Möglichkeit für
> August und September aus den Dateien in data/. Eine Zeile je Möglichkeit: August, September, verwendete
> Dateien und Spalten. Wähle nicht für mich.

Erwartet:

| Steckbrief | Möglichkeit | Aug | Sep |
|---|---|---|---|
| Defekte | A. Meldungen je 1.000 versandte Stück | 3,21 | 2,51 |
| Defekte | B. Betroffene Stück je 1.000 versandte Stück | 310 | 309 |
| Defekte | C. Verschrottete Stück je 1.000 versandte Stück | 123 | 168 |
| Nachfrage | A. Monatssumme, Stück | 7.488 | 9.162 |
| Nachfrage | B. Je Versandwoche, Stück | 1.872 | 1.832 |

Monatssumme: +22,4 %. Je Versandwoche: −2,1 %. Der August hat vier week_start-Werte, der September fünf.

Prüf die Defekt-Möglichkeiten, bevor du wählst:
> Angenommen, die Qualitätssicherung fasst die CRAFT-Meldungen im September von derselben Maschine in
> derselben Woche zu einer Meldung zusammen. Was zeigt dann jede Defekt-Möglichkeit?

Erwartet: 17 Meldungen statt 23, Möglichkeit A fällt auf 1,86 je 1.000. B und C bewegen sich nicht. Kein
einziges Teil hat sich geändert.

Dann wählen:
> Meine Wahl: Defekte = <Möglichkeit>, weil <ein Satz>. Nachfrage = <Möglichkeit>, weil <ein Satz>.
> Freigabebedingung = <Bedingung>. Schreib die drei wörtlich in den Skill northwind-metrics unter
> „Steckbriefe“ und zeig mir nur diesen Abschnitt.

## Schritt 3 · Den Skill ausführen und eine Zahl zurückverfolgen (10 Min.)
> Wende meinen Skill northwind-metrics auf reports/2023-09-monthly-report.md an. Verfolg dann den
> CRAFT-Umsatz von 4.124.238 € bis zu seinen Zeilen zurück: Datei, Spalten, Filter, Anzahl Zeilen, Summe.

Erwartet: 95 Zeilen in demand_actuals.csv (sku beginnt mit NW-CRAFT-, week_start 2023-09-02 bis 2023-09-30).
Drei Modelle: E1 449 € × 3.258, E2 699 € × 2.973, G1 199 € × 2.931. Summe 4.124.238 €. Die Prüfung zeigt
auch, was „Umsatz“ hier heißt: Stück mal Listenpreis. Keine Rabatte, keine Kosten.

## Schritt 4 · Dashboard und Entscheidung (15 Min.)
> Schreib die Dashboard-Daten und sag mir, dass ich es öffnen soll. Triff dann die Entscheidung zu CRAFT in
> den sechs Entscheidungsfeldern des Skills. Nenne unter „Gegenposition“ die Werte, die die Definitionen
> ergeben, die ich nicht gewählt habe.

Erwartet: Jede Kachel zeigt ihren Wert und eine Zeile „So gezählt“ aus deinen Steckbriefen. Mit
verschrotteten Stück und Nachfrage je Versandwoche lautet die Entscheidung: erst Nacharbeit. Der Ausschuss
stieg von 123 auf 168 je 1.000 versandte Stück (1.539 Stück, 691.011 € zum mittleren Listenpreis von 449 €),
und die Nachfrage je Versandwoche sank um 2,1 %. Mit Meldungen und Monatssumme stützen dieselben Daten den
VP. Die Entscheidung nennt den Steckbrief, auf dem sie beruht.

## Schritt 5 · Eine eigene Kennzahl (10 Min.)
> Öffne claude/kennzahlen-steckbrief/SKILL.md. Frag mich nach einer Kennzahl aus meinem eigenen Monatsbericht,
> ein Feld nach dem anderen: Entscheidung, Zähler, Nenner, Zeitraum, Quelle, Grenze, Auslöser. Schreib den
> Steckbrief in claude/kennzahlen-steckbrief/references/steckbriefe.md. Ich beschreibe die Kennzahl. Ich füge
> keine Firmendaten ein.

Lies einen Skill, bevor du ihn installierst. Dieser ist kurz und reiner Text.

## Den Skill außerhalb dieses Ordners installieren
Pack den Ordner `kennzahlen-steckbrief` in eine Zip-Datei, sodass der Ordner selbst oben in der Zip liegt,
oder lade dieselbe Datei unter loehrning.ai/skills/kennzahlen-steckbrief.zip. Dann:

### claude.ai und Desktop-App

1. Unter „Settings“, „Capabilities“ den Schalter „Code execution and file creation“ einschalten (im neuen Layout „Create and edit files“).
2. claude.ai/customize/skills öffnen.
3. „+“, dann „Create skill“, dann „Upload a skill“ und die ZIP-Datei wählen.
4. Den Skill einschalten.

Auf Team und Enterprise kann dein Admin eigene Skills abschalten.

### Claude Code

Für alle Projekte: `unzip kennzahlen-steckbrief.zip -d ~/.claude/skills/`

Nur für dieses Repository: `unzip kennzahlen-steckbrief.zip -d .claude/skills/`

Danach liegt SKILL.md in skills/kennzahlen-steckbrief/, global oder im Repository. Tippe /kennzahlen-steckbrief oder frag einfach.

Mit demselben claude.ai-Login lädt Claude Code (ab v2.1.273) deine in claude.ai eingeschalteten Skills selbst; dort nicht ein zweites Mal entpacken. Mit API-Key oder Bedrock: per unzip.

### Projektanweisungen

1. claude.ai/projects öffnen, „New Project“ wählen.
2. Rechts „Set project instructions“ öffnen, den Text einfügen, „Save instructions“.
3. Die Kit-Dateien über „+“ ins Projektwissen laden.

Projekte gibt es auf jedem Plan, auf Free bis zu fünf.

## Nächster Monat
Leg den Oktoberbericht nach reports/ und wiederhole Schritt 3 und 4. Die Steckbriefe bleiben, die Zahlen
ändern sich.

## Wenn etwas nicht passt
- Andere Werte in Schritt 2: Frag „Welche Zeilen hast du genommen? Zeig den Filter.“ Meist ist eine Woche
  dem falschen Monat zugeordnet.
- Claude wählt eine Definition für dich: „Wähle nicht. Zeig alle Möglichkeiten nebeneinander.“
- Der Skill läuft nicht: Sag „nutze meinen Skill northwind-metrics“.
- Das Dashboard bleibt leer: Prüf, ob dashboard/data.js geschrieben wurde, und frag dann noch einmal.

## Ohne Claude Code
claude.ai-Projekte gibt es auf jedem Plan, auch auf Free. Leg ein Projekt an, füg den Text aus
project-instructions.md in die Projektanweisungen ein und lade beide Berichte und die drei CSVs als
Projektwissen hoch. Schritt 1, 2, 3 und 5 gehen im Chat. Für Schritt 4 gibt es dort kein Dashboard; frag
nach den sechs Entscheidungsfeldern als Text. In Schritt 5 schreibt Claude im Chat den Steckbrief als Text;
kopier ihn in die Projektanweisungen unter „Unsere Steckbriefe“.
