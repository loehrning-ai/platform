/* This file is written by the northwind-metrics Skill in step 4.
   It starts empty on purpose: the dashboard shows "no data" until the Skill fills it. */
window.NORTHWIND_DATA = null;
