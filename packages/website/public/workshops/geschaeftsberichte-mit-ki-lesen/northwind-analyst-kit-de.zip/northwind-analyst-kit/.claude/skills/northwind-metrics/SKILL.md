---
name: northwind-metrics
description: Nutzen, wenn ein NORTHWIND-Monatsbericht ausgewertet oder sein Dashboard aktualisiert wird. Wendet die Steckbriefe an, prüft eine Zahl bis zur CSV-Zeile, schreibt metrics.json und eine Entscheidung.
---

# northwind-metrics

NORTHWIND GmbH ist eine erfundene Firma. Ihr Monatsbericht verwendet Wörter wie „Defekte“ und „Wachstum“,
ohne zu sagen, wie gezählt wird. Die Steckbriefe am Ende dieser Datei sagen, wie NORTHWIND zählt. Weichen
Bericht und Steckbrief ab, gilt der Steckbrief, und du zeigst beides.

## Zuerst
Ist ein Steckbrief unten noch OFFEN, rechne nichts anderes. Zeig jede Möglichkeit, die metric-cards.md
dafür nennt, mit ihrem Wert für August und September, und lass die Person wählen. Wähle nie für sie.
Nutze den Lösungsvorschlag in metric-cards.md nur, wenn die Person danach fragt.

## Ablauf
1. Zitieren, dann rechnen. Zitiere für jede Zahl aus dem Bericht, die du verwendest, den Satz oder die
   Tabellenzeile und nenne den Abschnitt. Eine Zahl, die der Bericht nicht nennt, ist „nicht im Bericht“.
   Schätze nie.
2. Rechne jeden Steckbrief aus data/ für August und September, genau wie er es sagt. Eine Versandwoche
   gehört zum Monat ihres week_start, eine Meldung zum Monat ihres ncr_date. Zähl die week_start-Werte je
   Monat aus der Datei, nicht aus einem Kalender.
3. Nennt der Bericht dieselbe Kennzahl mit einer anderen Definition, schreib beides in eine Zeile:
   Definition und Wert des Berichts, Definition und Wert des Steckbriefs.
4. Verfolg eine Zahl zurück, auf der die Entscheidung beruht: Wert = Datei, Spalten, Filter, Anzahl Zeilen,
   Summe. Passt sie nicht zum Bericht, nenn die Differenz und nutz die Zahl nicht als Beleg.
5. Schreib metrics/metrics.json nach metrics/metrics.schema.json, mit den Steckbriefen wörtlich unter
   „cards“, einer Kachel je Steckbrief unter „tiles“ und der Prüfung unter „trace“. Setz „language“ auf die
   Sprache, in der die Person schreibt („de“ oder „en“). Prüf die Datei gegen das Schema. Schlägt das fehl,
   hör auf und nenn das Feld.
6. Schreib dashboard/data.js als `window.NORTHWIND_DATA = <Inhalt von metrics.json>;` und sag der Person,
   dass sie dashboard/index.html öffnen soll.
7. Nur wenn nach einer Entscheidung gefragt wird, füll sechs Felder: Entscheidung; Weil (nenne den
   Steckbrief); Zahl; Risiko, falls wir irren, in beide Richtungen; Gegenposition (was die nicht gewählten
   Definitionen ergeben, mit Werten); Auslöser (die Freigabebedingung). Ließe sich der Auslöser durch
   Zusammenfassen, Aufteilen oder Umdatieren von Meldungen erreichen, sag das und formulier ihn in Stück.

## Jeder Satz
- Die Grenze steht im selben Satz wie die Zahl.
- Zuerst die Zahl aus dem Bericht, dann die nachgerechnete.
- Kein „stark“, „schwach“, „gut“ oder „schlecht“ ohne den Vergleich, auf dem es beruht.

## Steckbriefe
### Umsatz
- Entscheidung: was CRAFT zum Listenpreis einbringt
- Zähler: units_actual × base_price_eur
- Nenner: keiner
- Zeitraum: Versandwochen nach week_start; je Versandwoche, wenn zwei Monate unterschiedlich viele Wochen haben
- Quelle: data/demand_actuals.csv (sku, week_start, units_actual); data/product_lines.csv (line, model_code, base_price_eur)
- Grenze: Listenpreis; kein Nettoumsatz, keine Marge

### CRAFT-Defekte
OFFEN. Wird in Schritt 2 aus metric-cards.md wörtlich ausgefüllt.

### CRAFT-Nachfrage
OFFEN. Wird in Schritt 2 aus metric-cards.md wörtlich ausgefüllt.

### Freigabebedingung
OFFEN. Wird in Schritt 2 aus metric-cards.md wörtlich ausgefüllt.
