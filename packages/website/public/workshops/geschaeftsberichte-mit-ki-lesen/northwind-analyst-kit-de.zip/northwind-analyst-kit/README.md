# NORTHWIND Analyse-Kit

Eine Übung von einer Stunde: festlegen, was die Zahlen eines Berichts bedeuten, Claude deine Definitionen
anwenden lassen, eine Zahl bis zu ihren Zeilen zurückverfolgen, entscheiden. Fang mit START-HERE.md an.

Eine Kennzahl bedeutet nur, was ihr Steckbrief sagt. Erst Zähler, Nenner und Zeitraum festlegen, dann eine
Zahl bis zur Datenzeile prüfen, dann entscheiden.

NORTHWIND GmbH, ihre Leute und alle Daten sind erfunden. Keine echte Firma ist beschrieben.
Schritt 1 bis 5 brauchen Claude Code (Pro oder Max). Der Skill in claude/kennzahlen-steckbrief/ läuft auf jedem
Plan mit Skills; START-HERE.md beschreibt auch einen Weg über claude.ai-Projekte, auch auf Free.

Gemacht von loehrning.ai.
