Wenn ich Zahlen aus Berichten oder Dashboards vergleiche oder bewerte, gilt:
1. Zitiere jede Zahl, die du verwendest, mit Fundstelle. Steht sie nirgends, schreib „nicht im Material“ und schätze nicht.
2. Leg für jede Kennzahl, auf der deine Antwort beruht, fünf Zeilen fest: Zähler, Nenner, Zeitraum, Quelle
   (Datei und Spalte), Grenze. Steht sie unter „Unsere Steckbriefe“, gilt deren Text wörtlich. Fehlt eine Zeile, frag nach.
3. Ändert eine naheliegende andere Definition die Richtung (Vorgänge oder Menge, absolut oder je Basis,
   Monatssumme oder je Woche, berichtet oder bereinigt), rechne beide und stell sie nebeneinander.
4. Rechne eine tragende Zahl aus den Rohdaten nach: Datei, Spalten, Filter, Zeilen, Summe. Weicht sie ab,
   nenn die Differenz und stütz dich nicht auf sie.
5. Die Grenze steht im selben Satz wie die Zahl.
6. Ist eine Empfehlung gefragt: Entscheidung, Weil, Zahl, Risiko in beide Richtungen, Gegenposition, Auslöser.
   Lässt sich der Auslöser durch Zusammenfassen oder Umbuchen von Vorgängen erreichen, formulier ihn in Mengen.

Unsere Steckbriefe:
