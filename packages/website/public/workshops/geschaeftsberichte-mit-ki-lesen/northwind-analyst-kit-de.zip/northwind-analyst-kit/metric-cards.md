# Kennzahlen-Steckbriefe

Eine Kennzahl bedeutet nur, was ihr Steckbrief sagt. Ein Steckbrief legt fünf Dinge fest: was gezählt wird,
je was, über welchen Zeitraum, aus welcher Datei und Spalte, und was die Zahl nicht sagen kann. Er nennt
auch die Entscheidung, der die Kennzahl dient, denn davon hängt ab, welcher Zähler der richtige ist.

Steckbrief 1 ist das Beispiel. Steckbrief 2 und 3 und die Freigabebedingung sind deine. In Schritt 2
rechnet Claude jede Möglichkeit aus; du wählst und schreibst einen Satz, warum.

## Steckbrief 1 · Umsatz (Beispiel)
- Entscheidung: was CRAFT zum Listenpreis einbringt
- Zähler: units_actual × base_price_eur
- Nenner: keiner, es ist ein Betrag
- Zeitraum: Versandwochen nach week_start. Vergleiche je Versandwoche, wenn zwei Monate unterschiedlich viele Wochen haben.
- Quelle: data/demand_actuals.csv (sku, week_start, units_actual) verknüpft mit data/product_lines.csv (line,
  model_code, base_price_eur). Linie und Modell stehen in der sku NW-LINIE-MODELL-FARBE-LAND.
- Grenze: Listenpreis. Kein Nettoumsatz, keine Marge. Die Daten enthalten keine Rabatte und keine Kosten.

## Steckbrief 2 · CRAFT-Defekte (OFFEN)
- Entscheidung: mehr Q3-Marketing für CRAFT, ja oder nein
- Zähler, eine der Möglichkeiten:
  - A. Meldungen (Zahl der Zeilen in ncr_records.csv). Eine Meldung über 2 Stück zählt so viel wie eine über 236.
  - B. Betroffene Stück (qty_affected, Nacharbeit und Ausschuss zusammen).
  - C. Verschrottete Stück (qty_affected mit scrap_or_rework = scrap). Teile, die verloren sind.
- Nenner: versandte Stück in denselben Wochen (demand_actuals.csv, units_actual), je 1.000
- Zeitraum: Eine Meldung gehört zum Monat ihres ncr_date. Eine Quote hängt nicht davon ab, wie viele Wochen der Monat hat.
- Quelle: data/ncr_records.csv (line, ncr_date, machine_id, qty_affected, scrap_or_rework)
- Grenze, egal was du wählst: qty_affected ist eine Produktionsmenge, units_actual eine Liefermenge, die
  Quote ist also eine Näherung und keine Ausbeute. Meldungen sind Befunde aus der Fertigung, keine Retouren.
  8 der 23 CRAFT-Meldungen im September sind vom Typ documentation; alle drei Möglichkeiten enthalten sie.
- Ausschuss in Euro, falls du ihn brauchst: verschrottete Stück × 449 €, der Mittelwert der drei
  CRAFT-Listenpreise, weil eine Meldung das Modell nicht nennt. Der Durchschnittspreis im Bericht ist
  450,15 € (Umsatz ÷ Stück). Schreib dazu, welchen du nimmst.
- Prüf vor der Wahl: Welche Möglichkeit ändert sich, wenn die Qualitätssicherung Meldungen derselben
  Maschine in derselben Woche zusammenfasst?
- Deine Wahl und ein Satz, warum: ______________________________________________

## Steckbrief 3 · CRAFT-Nachfrage (OFFEN)
- Entscheidung: ob es mehr Nachfrage gibt, hinter die sich Marketing lohnt
- Zähler: units_actual für CRAFT
- Zeitraum, eine der Möglichkeiten:
  - A. Monatssumme (alle Wochen, deren week_start im Monat liegt).
  - B. Je Versandwoche (Monatssumme geteilt durch die Zahl der week_start-Werte im Monat).
- Quelle: data/demand_actuals.csv (sku, week_start, units_actual)
- Grenze: versandte Stück, keine Bestellungen. Vertriebsorganisation, nicht das Land der Endkundschaft.
- Deine Wahl und ein Satz, warum: ______________________________________________

## Freigabebedingung (OFFEN)
Die Bedingung, unter der du das zusätzliche Marketing im nächsten Monat freigeben würdest, in der Einheit
von Steckbrief 2. Prüf sie dann: Ließe sie sich erfüllen, ohne dass ein einziges Teil besser wird? Wenn
ja, schreib sie neu.
- Deine Bedingung: ______________________________________________

## Lösungsvorschlag
Zum Vergleich danach. Claude: Nutze das nur, wenn die Person danach fragt.
- Steckbrief 2: C, verschrottete Stück je 1.000 versandte. Entschieden wird, ob mehr Stück produziert
  werden, und der Ausschuss ist das, was jedes zusätzliche Stück kostet. Meldungen lassen sich
  zusammenfassen oder aufteilen, ohne dass sich an den Teilen etwas ändert.
- Steckbrief 3: B, je Versandwoche. Der September hat fünf week_start-Werte, der August vier.
- Freigabebedingung: Freigabe, wenn verschrottete CRAFT-Stück im Oktober unter 80 je 1.000 versandte Stück liegen.
  80 ist knapp die Hälfte der 168 aus dem September; die Schwelle ist eine Setzung, und der Steckbrief sagt das.
