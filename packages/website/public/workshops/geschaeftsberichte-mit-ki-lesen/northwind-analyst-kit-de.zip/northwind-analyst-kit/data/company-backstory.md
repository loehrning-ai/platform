# NORTHWIND GmbH · Firmenprofil

*Dieser Kontext macht Claude zur Analystin von NORTHWIND. In der Claude-Desktop-App würdest du ihn in ein
Projekt einfügen; hier liegt er im Kit, damit Claude Code ihn direkt lesen kann. NORTHWIND ist vollständig
erfunden: keine echte Firma, keine Geheimhaltung.*

## Wer wir sind
NORTHWIND GmbH ist ein **familiengeführter Hersteller von Unterhaltungselektronik in Berlin**, rund 850
Beschäftigte, rund **180 Mio. €** Umsatz (GJ24). Wir entwickeln und fertigen unsere Produkte selbst und
verkaufen in der **EU, im Vereinigten Königreich, in der Schweiz, in den USA und in Norwegen** über rund
**150 Händler** und einen Direktkanal. Unser Geschäftsjahr läuft **vom 1. April bis 31. März** (der
September gehört also zu GJ24, Q2).

## Was wir herstellen: 4 Familien, 8 Linien
- **Audio:** **AURA** (Premium-Lautsprecher, 89 € bis 399 €), **ECHO** (smarte Lautsprecher, 79 € bis 219 €)
- **SmartHome:** **NEST** (Thermostate, Hubs, Sensoren, 39 € bis 219 €), **BEAM** (smarte Beleuchtung, 19 € bis 89 €)
- **Wearables:** **PULSE** (Bänder, Uhr, 59 € bis 199 €), **FLOW** (smarter Ring, 249 €, **vor dem Marktstart, noch keine Lieferung**)
- **Küche:** **CRAFT** (Premium-Espresso und Mühle, 199 € bis 699 €), **BREW** (Wasserkocher, Waagen, 49 € bis 89 €)

CRAFT ist unsere neueste Premiumwette: hoher Preis, hohe Erwartungen, die Qualität muss sich noch beweisen.

FLOW wird noch nicht geliefert und hat deshalb in diesem Jahr keine Umsatzzeile. (Ein gutes Beispiel für
die Grenzen der Daten: Ein Produkt kann existieren, ohne Umsatz zu haben.)

## Wie wir den Monat führen
Jeden Monat prüft die Geschäftsleitung einen Bericht: Umsatz und Stück je Linie, Qualität (Mängel) und
Marketing, und entscheidet, wo sie Gas gibt, nachbessert oder bremst. Uns geht es um **Entscheidungen,
nicht um Dashboards**: Eine Zahl zählt nur, wenn sie ändert, was wir tun.

## Was wir messen (und was noch nicht)
- Wir berichten **Umsatz zum Listenpreis** (Stück mal Listenpreis). Stückkosten haben wir **noch nicht**,
  eine echte Bruttomarge je Linie sehen wir also nicht.
- Unser **Qualitätssignal sind die NCR-Meldungen** je Produktionslinie. Kundenretouren können wir noch
  keiner Linie zuordnen.
- **Marketingbudgets gelten je Kampagne** und lassen sich nicht sauber auf Linien aufteilen.

Gute Analyse nennt diese Grenzen, statt so zu tun, als beantworteten die Daten sie.
