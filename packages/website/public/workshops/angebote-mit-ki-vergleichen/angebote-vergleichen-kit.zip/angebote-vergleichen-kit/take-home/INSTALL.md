# In deinem eigenen Claude einrichten

Der Skill liegt in diesem Kit unter take-home/skill/angebote-vergleichen/SKILL.md. Zum Hochladen in claude.ai lädst du angebote-vergleichen.zip
von loehrning.ai/skills/angebote-vergleichen.zip oder von der Demo-Seite. Die Schritte folgen.

### claude.ai und Desktop-App

1. Unter „Settings“, „Capabilities“ den Schalter „Code execution and file creation“ einschalten (im neuen Layout „Create and edit files“).
2. claude.ai/customize/skills öffnen.
3. „+“, dann „Create skill“, dann „Upload a skill“ und die ZIP-Datei wählen.
4. Den Skill einschalten.

Auf Team und Enterprise kann dein Admin eigene Skills abschalten.

### Claude Code

Für alle Projekte: `unzip angebote-vergleichen.zip -d ~/.claude/skills/`

Nur für dieses Repository: `unzip angebote-vergleichen.zip -d .claude/skills/`

Danach liegt SKILL.md in skills/angebote-vergleichen/ (global oder im Repository). Tipp /angebote-vergleichen oder frag einfach.

Mit demselben claude.ai-Login lädt Claude Code (ab v2.1.273) deine in claude.ai eingeschalteten Skills selbst; dort nicht ein zweites Mal entpacken. Mit API-Key oder Bedrock: per unzip.

### Projektanweisungen

1. claude.ai/projects öffnen, „New Project“ wählen.
2. Rechts „Set project instructions“ öffnen, den Text einfügen, „Save instructions“.
3. Die Kit-Dateien über „+“ ins Projektwissen laden.

Projekte gibt es auf jedem Plan, auf Free bis zu fünf.

# Set it up in your own Claude

The skill sits in this kit under take-home/skill/angebote-vergleichen/SKILL.md. To upload it to claude.ai, download angebote-vergleichen.zip
from loehrning.ai/skills/angebote-vergleichen.zip or from the demo page. The steps follow.

### claude.ai and the desktop app

1. In “Settings”, “Capabilities”, turn on “Code execution and file creation” (“Create and edit files” in the new layout).
2. Open claude.ai/customize/skills.
3. Choose “+”, then “Create skill”, then “Upload a skill”, and pick the zip file.
4. Turn the skill on.

On Team and Enterprise an admin can turn user skills off.

### Claude Code

For all projects: `unzip angebote-vergleichen.zip -d ~/.claude/skills/`

For this repository only: `unzip angebote-vergleichen.zip -d .claude/skills/`

SKILL.md then sits in skills/angebote-vergleichen/ (global or in the repository). Type /angebote-vergleichen or just ask.

With the same claude.ai login, Claude Code (v2.1.273 or later) loads the skills you turned on in claude.ai by itself; do not unzip them there a second time. With an API key or Bedrock: unzip.

### Project instructions

1. Open claude.ai/projects and choose “New Project”.
2. On the right, open “Set project instructions”, paste the text, choose “Save instructions”.
3. Add the kit files to the project knowledge with “+”.

Projects work on every plan, up to five on Free.
